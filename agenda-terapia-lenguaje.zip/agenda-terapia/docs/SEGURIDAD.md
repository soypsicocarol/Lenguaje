# Seguridad y límites de una app sin servidor

La aplicación maneja datos de menores. Todo se guarda en el navegador del dispositivo (IndexedDB) y no se envía a ningún servicio.

## Qué protege

- **Bloqueo de interfaz**: PIN o contraseña (mínimo 4 caracteres). Se guarda como hash PBKDF2-SHA256 (150 000 iteraciones, sal aleatoria), nunca en texto plano.
  Bloqueo manual, bloqueo automático por inactividad (configurable) y al volver a la app tras ese tiempo. Tras 5 intentos fallidos hay esperas crecientes.
- **Respaldos cifrados**: AES-256-GCM con clave derivada por PBKDF2-SHA256 (250 000 iteraciones). El cifrado autenticado detecta archivos alterados.
- **Integridad**: todo respaldo lleva huella SHA-256; se valida estructura, versión y relaciones antes de tocar la base local.
- **Sin fugas**: sin analítica, sin telemetría, CSP `default-src 'self'; connect-src 'self'`. Los CSV y respaldos neutralizan fórmulas de hoja de cálculo.
- **WhatsApp**: solo se abre un enlace `wa.me` con texto que la usuaria revisa; el contenido del mensaje no se guarda.

## Qué NO protege (hay que saberlo)

1. **El PIN no cifra la base de datos.** Quien acceda al perfil del navegador con herramientas de desarrollo o al almacenamiento del teléfono desbloqueado podría leer los datos. El límite de intentos vive en el navegador y puede eludirse con DevTools.
2. **PIN olvidado = sin recuperación.** Solo se puede borrar todo y restaurar un respaldo.
3. **Pérdida de datos**: borrar datos del sitio/navegador, desinstalar la PWA o perder el dispositivo elimina la información si no hay respaldo. La app avisa si no hay respaldo reciente (7 días) y solicita almacenamiento persistente al navegador (no está garantizado).
4. **Dispositivo compartido**: otra persona con acceso al mismo perfil del navegador vería la pantalla de bloqueo, pero no está aislada a nivel de datos.
5. Una contraseña de respaldo olvidada es irrecuperable.

## Recomendaciones

- Usar un teléfono con bloqueo de pantalla y cifrado de almacenamiento activados (Android lo hace por defecto).
- Exportar un respaldo cifrado cada semana y guardarlo fuera del teléfono; **probar la restauración** en otro dispositivo antes de usar datos reales.
- No escribir información clínica en las notas: la app es administrativa.
- Mantener el navegador actualizado y no instalar extensiones no confiables en el perfil donde está la app.
