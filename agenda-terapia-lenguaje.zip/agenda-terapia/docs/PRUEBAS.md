# Criterios de aceptación (sección 14 del brief) y pruebas realizadas

Ejecutadas el 27/10/2026: **28/28 pruebas de lógica** (`npm test`) y **14/14 pruebas E2E** en Chromium (`npm run test:e2e`, repetidas 2 veces sin fallos).

| Criterio del brief | Cómo se probó | Resultado |
|---|---|---|
| Paciente: crear, editar, buscar, inactivar; persiste al reabrir | E2E (recarga la página) + lógica | Correcto |
| Recurrencia lunes y jueves 4 semanas | Lógica y E2E (fechas exactas, 8 citas, sin duplicados; también empezando en miércoles; guardar dos veces no duplica) | Correcto |
| Edición individual | Lógica y E2E (solo cambia una cita) | Correcto |
| Edición de futuras | Lógica y E2E (las anteriores no cambian; la serie se divide) | Correcto |
| Conflicto | Lógica y E2E (advertencia en vivo, confirmación explícita, "volver y cambiar"); bloqueos y vacaciones | Correcto |
| Asistencia sin contar doble | Lógica y E2E (realizada repetida + edición posterior = 1 consumo) | Correcto |
| Cancelación según regla | Lógica y E2E (por defecto no descuenta; con regla activa descuenta una vez; deshacer devuelve) | Correcto |
| Paquete de 8 → 7 una sola vez | Lógica y E2E | Correcto |
| Pago parcial y saldo | Lógica y E2E (20 − 5 = 15 pendiente) | Correcto |
| Ingresos = pagos recibidos, no futuras ni no cobradas | Lógica y E2E (cobrado 5,00; proyectado 20,00 separado) | Correcto |
| WhatsApp con número y mensaje prellenado, sin afirmar envío | E2E (intercepta la petición a `wa.me`, valida número y texto codificado) | Correcto |
| Sin conexión | E2E (`setOffline(true)`, recarga, crea registro, recarga de nuevo) | Correcto |
| Respaldo: exportar/importar en instalación de prueba | E2E (plano y cifrado, contenido idéntico, archivo alterado rechazado) + lógica (reemplazar y combinar) | Correcto |
| Protección: bloqueo, error de contraseña, confirmaciones | E2E (PIN, error, recarga bloqueada, PIN no en texto plano; confirmaciones de borrado/restauración) | Correcto |
| Exportación de reporte legible | E2E (CSV con fechas, moneda e importes) | Correcto |

## Pruebas adicionales de lógica
Pagos futuros rechazados; correcciones con motivo; monedas sin mezclar; cobros por período y paquete con pago; ajuste manual de paquete; eliminar cita devuelve sesión; sin paquete disponible; excluir/finalizar/extender serie; atomicidad ante fallo de almacenamiento; cifrado con contraseña incorrecta o archivo alterado; PIN con sal; CSV con fórmulas; fechas con cambio de horario.

## No probado
- Instalación real en un Android físico y el intent de WhatsApp en un teléfono con la app instalada (se probó la URL generada, no la apertura nativa).
- Safari/iOS (la app está pensada para Chrome/Android y escritorio; en iOS, Safari puede borrar datos de sitios sin uso: exportar respaldos).
- Rendimiento con volúmenes muy grandes (varios miles de citas): la app carga los datos en memoria.
