// Capa de almacenamiento local. Misma interfaz en IndexedDB (navegador) y en memoria (pruebas).
// Interfaz: getAll(store), get(store,id), batch(ops), clearAll().
// ops: {op:'put',store,rec} | {op:'delete',store,id} | {op:'clear',store}. Cada batch es atómico.

export const DB_NAME = 'agenda-terapia-lenguaje';
export const DB_VERSION = 1;
export const STORES = ['patients', 'appointments', 'series', 'blocks', 'payments', 'plans', 'packages', 'movements', 'settings'];

const INDICES = {
  appointments: [['patientId', 'patientId'], ['fecha', 'fecha'], ['seriesId', 'seriesId']],
  payments: [['patientId', 'patientId']],
  plans: [['patientId', 'patientId']],
  packages: [['patientId', 'patientId']],
  movements: [['packageId', 'packageId'], ['appointmentId', 'appointmentId']],
  series: [['patientId', 'patientId']],
};

export async function abrirIndexedDB() {
  if (typeof indexedDB === 'undefined') throw new Error('Este navegador no permite almacenamiento local (IndexedDB).');
  const db = await new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const d = req.result;
      for (const s of STORES) {
        if (!d.objectStoreNames.contains(s)) {
          const os = d.createObjectStore(s, { keyPath: 'id' });
          for (const [n, k] of INDICES[s] || []) os.createIndex(n, k);
        }
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error || new Error('No se pudo abrir la base local.'));
    req.onblocked = () => reject(new Error('La base local está bloqueada por otra pestaña abierta. Ciérrala e inténtalo de nuevo.'));
  });
  db.onversionchange = () => db.close();

  const req2p = (r) => new Promise((res, rej) => ((r.onsuccess = () => res(r.result)), (r.onerror = () => rej(r.error))));
  return {
    kind: 'indexeddb',
    getAll: (store) => req2p(db.transaction(store).objectStore(store).getAll()),
    get: (store, id) => req2p(db.transaction(store).objectStore(store).get(id)),
    batch(ops) {
      const names = [...new Set(ops.map((o) => o.store))];
      if (!names.length) return Promise.resolve();
      return new Promise((res, rej) => {
        const tx = db.transaction(names, 'readwrite');
        for (const o of ops) {
          const os = tx.objectStore(o.store);
          if (o.op === 'put') os.put(o.rec);
          else if (o.op === 'delete') os.delete(o.id);
          else if (o.op === 'clear') os.clear();
        }
        tx.oncomplete = () => res();
        tx.onerror = () => rej(tx.error);
        tx.onabort = () => rej(tx.error || new Error('Operación cancelada por el almacenamiento.'));
      });
    },
    clearAll() {
      return this.batch(STORES.map((s) => ({ op: 'clear', store: s })));
    },
    close: () => db.close(),
  };
}

export function crearMemoria() {
  const m = Object.fromEntries(STORES.map((s) => [s, new Map()]));
  const cp = (x) => JSON.parse(JSON.stringify(x));
  return {
    kind: 'memory',
    async getAll(store) {
      return [...m[store].values()].map(cp);
    },
    async get(store, id) {
      return m[store].has(id) ? cp(m[store].get(id)) : undefined;
    },
    async batch(ops) {
      for (const o of ops) if (!m[o.store]) throw new Error('Almacén desconocido: ' + o.store);
      for (const o of ops) {
        if (o.op === 'put') m[o.store].set(o.rec.id, cp(o.rec));
        else if (o.op === 'delete') m[o.store].delete(o.id);
        else if (o.op === 'clear') m[o.store].clear();
      }
    },
    async clearAll() {
      for (const s of STORES) m[s].clear();
    },
    close() {},
  };
}
