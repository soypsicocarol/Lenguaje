// Efectos económicos de cambiar el estado de una cita: descuento de paquete y
// obligación de pago por sesión. Es IDEMPOTENTE: se puede llamar cuantas veces se
// quiera con el mismo estado y no duplica nada, porque compara lo que "debería haber"
// con lo que "ya hay" y solo registra la diferencia.

import { today as todayFn, fmtDateNumeric } from '../core/dates.js';
import { netConsumption, packageSummary, pickPackage } from './packages.js';
import { estadoLabel } from './estados.js';

/**
 * @param t transacción abierta (con acceso a movements, packages, plans, payments)
 * @returns {Promise<string[]>} avisos para mostrar a la persona usuaria
 */
export async function syncBilling(t, appt, patient, settings, hoy = todayFn()) {
  const avisos = [];
  const regla = settings.reglasConsumo[appt.estado] || { descuenta: false, cobra: false };
  const modalidad = patient.modalidadCobro || 'sesion';
  const now = new Date().toISOString();

  if (modalidad === 'paquete') {
    const movs = await t.byIndex('movements', 'appointmentId', appt.id);
    const net = netConsumption(movs);
    const deseado = regla.descuenta ? 1 : 0;
    if (deseado > net) {
      const pkgs = await t.byIndex('packages', 'patientId', patient.id);
      const allMovs = [];
      for (const p of pkgs) allMovs.push(...(await t.byIndex('movements', 'packageId', p.id)));
      let pkg = null;
      const previo = movs.find((m) => m.packageId)?.packageId;
      if (previo) {
        const p = pkgs.find((x) => x.id === previo);
        if (p && packageSummary(p, allMovs, hoy).disponibles > 0 && p.estado !== 'anulado') pkg = p;
      }
      if (!pkg) pkg = pickPackage(pkgs, allMovs, appt.fecha, hoy);
      if (!pkg) {
        avisos.push('El paciente no tiene un paquete con sesiones disponibles (o está vencido): no se descontó ninguna sesión.');
      } else {
        await t.put('movements', {
          id: `pm_${appt.id}_${movs.length + 1}`,
          packageId: pkg.id,
          appointmentId: appt.id,
          tipo: 'consumo',
          delta: -1,
          fecha: appt.fecha,
          motivo: `Sesión del ${fmtDateNumeric(appt.fecha)} (${estadoLabel(appt.estado)})`,
          createdAt: now,
        });
      }
    } else if (deseado < net) {
      const pkgId = movs.find((m) => m.packageId)?.packageId;
      await t.put('movements', {
        id: `pm_${appt.id}_${movs.length + 1}`,
        packageId: pkgId,
        appointmentId: appt.id,
        tipo: 'devolucion',
        delta: 1,
        fecha: appt.fecha,
        motivo: `Devolución: la cita del ${fmtDateNumeric(appt.fecha)} pasó a "${estadoLabel(appt.estado)}"`,
        createdAt: now,
      });
      avisos.push('Se devolvió una sesión al paquete.');
    }
  }

  if (modalidad === 'sesion') {
    const obId = `ob_ses_${appt.id}`;
    const ob = await t.get('plans', obId);
    if (regla.cobra) {
      const tarifa = appt.tarifa ?? patient.tarifa ?? settings.tarifaDefault ?? 0;
      if (!ob) {
        if (tarifa > 0) {
          await t.put('plans', {
            id: obId,
            patientId: patient.id,
            tipo: 'sesion',
            appointmentId: appt.id,
            concepto: `Sesión del ${fmtDateNumeric(appt.fecha)}`,
            importe: tarifa,
            moneda: patient.moneda || settings.moneda,
            fechaInicio: appt.fecha,
            fechaFin: appt.fecha,
            estado: 'activa',
            historial: [{ at: now, tipo: 'creada' }],
            createdAt: now,
          });
        } else {
          avisos.push('El paciente no tiene tarifa definida: no se generó el importe de la sesión. Define la tarifa en su ficha.');
        }
      } else if (ob.estado === 'anulada') {
        await t.put('plans', {
          ...ob,
          estado: 'activa',
          motivoAnulacion: '',
          historial: [...(ob.historial || []), { at: now, tipo: 'reactivada' }],
        });
      }
    } else if (ob && ob.estado === 'activa') {
      await t.put('plans', {
        ...ob,
        estado: 'anulada',
        motivoAnulacion: `La cita pasó a "${estadoLabel(appt.estado)}" y ya no es una sesión cobrable.`,
        historial: [...(ob.historial || []), { at: now, tipo: 'anulada', motivo: appt.estado }],
      });
      const pagos = (await t.byIndex('payments', 'obligacionId', obId)).filter((p) => p.estado !== 'anulado');
      if (pagos.length) avisos.push('Esta sesión tenía pagos registrados: quedan como saldo a favor del paciente.');
    }
  }
  return avisos;
}
