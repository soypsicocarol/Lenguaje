// Recurrencia semanal (funciones puras, sin acceso a la base de datos).
//
// Una serie se define por: patientId, fechaInicio, dias [{dow, inicio, duracion}],
// y opcionalmente fechaFin o repeticiones (número de semanas).
//
// Regla de "número de semanas": se genera una ventana de 7 × n días que comienza en la
// fecha de inicio. Así cada día de la semana elegido aparece exactamente n veces,
// aunque la serie empiece a mitad de semana.
//
// Si no hay fecha final ni número de semanas, la serie es "abierta": se generan citas
// hasta un horizonte (por defecto 12 semanas) y se amplía al abrir la aplicación.

import { addDays, dow, isValidDate, isValidTime, toMin, DOW_NAMES } from '../core/dates.js';

export const MAX_WEEKS = 260;

export function validateSeries(s) {
  const e = [];
  if (!s.patientId) e.push('Selecciona un paciente.');
  if (!isValidDate(s.fechaInicio)) e.push('La fecha de inicio no es válida.');
  if (!Array.isArray(s.dias) || s.dias.length === 0) {
    e.push('Elige al menos un día de la semana.');
  } else {
    const seen = new Set();
    for (const d of s.dias) {
      if (!Number.isInteger(d.dow) || d.dow < 0 || d.dow > 6) {
        e.push('Día de la semana no válido.');
        continue;
      }
      const nombre = DOW_NAMES[d.dow];
      if (seen.has(d.dow)) e.push(`El ${nombre} está repetido dentro de la misma serie.`);
      seen.add(d.dow);
      if (!isValidTime(d.inicio)) e.push(`La hora del ${nombre} no es válida.`);
      if (!Number.isInteger(d.duracion) || d.duracion < 5 || d.duracion > 480) {
        e.push(`La duración del ${nombre} debe estar entre 5 y 480 minutos.`);
      } else if (isValidTime(d.inicio) && toMin(d.inicio) + d.duracion > 1440) {
        e.push(`La sesión del ${nombre} no puede pasar de la medianoche.`);
      }
    }
  }
  if (s.fechaFin) {
    if (!isValidDate(s.fechaFin)) e.push('La fecha final no es válida.');
    else if (isValidDate(s.fechaInicio) && s.fechaFin < s.fechaInicio) {
      e.push('La fecha final no puede ser anterior a la fecha de inicio.');
    }
  }
  if (s.repeticiones !== null && s.repeticiones !== undefined && s.repeticiones !== '') {
    const r = Number(s.repeticiones);
    if (!Number.isInteger(r) || r < 1 || r > MAX_WEEKS) e.push(`El número de semanas debe estar entre 1 y ${MAX_WEEKS}.`);
  }
  return e;
}

/** Fecha final efectiva (la más temprana entre fechaFin y semanas) o null si es abierta. */
export function resolveEnd(s) {
  let end = s.fechaFin || null;
  if (s.repeticiones) {
    const byWeeks = addDays(s.fechaInicio, 7 * Number(s.repeticiones) - 1);
    end = end ? (byWeeks < end ? byWeeks : end) : byWeeks;
  }
  return end;
}

export const isOpenSeries = (s) => resolveEnd(s) === null;

/** Todas las fechas teóricas de la serie, sin aplicar excepciones ni pausas. */
export function generateOccurrences(series, { horizon } = {}) {
  const closed = resolveEnd(series);
  const end = closed ?? horizon;
  if (!end) throw new Error('Una serie abierta necesita un horizonte de fechas.');
  const byDow = new Map(series.dias.map((d) => [d.dow, d]));
  const out = [];
  for (let f = series.fechaInicio; f <= end; f = addDays(f, 1)) {
    const d = byDow.get(dow(f));
    if (d) out.push({ fecha: f, inicio: d.inicio, duracion: d.duracion, dow: d.dow, clave: `${series.id}|${f}` });
  }
  return out;
}

export function isExcluded(series, fecha) {
  if ((series.excepciones || []).includes(fecha)) return true;
  return (series.pausas || []).some((p) => fecha >= p.desde && fecha <= p.hasta);
}

/** Fechas que realmente se crean: sin excepciones ni pausas (vacaciones). */
export function activeOccurrences(series, opts) {
  return generateOccurrences(series, opts).filter((o) => !isExcluded(series, o.fecha));
}
