// Respaldos: exportación versionada, cifrado opcional, validación, resumen y restauración
// (reemplazar o combinar). Nada se modifica hasta que la persona confirma, y antes de
// restaurar se guarda una copia interna de la base actual para poder revertir.

import { DATA_STORES } from '../core/db.js';
import { getDB, loadAll, setMeta, getMeta } from '../core/store.js';
import { mergeSettings, APP_VERSION } from '../core/defaults.js';
import { BackupError } from '../core/errors.js';
import { fromB64, randomBytes, sha256Hex, toB64 } from '../core/bytes.js';

export const BACKUP_FORMAT = 'agenda-terapia-backup';
export const BACKUP_ENC_FORMAT = 'agenda-terapia-backup-cifrado';
export const BACKUP_VERSION = 1;
export const BACKUP_KDF_ITER = 600000;

export const STORE_LABELS = {
  patients: 'pacientes',
  appointments: 'citas',
  series: 'series recurrentes',
  blocks: 'bloqueos',
  payments: 'pagos',
  plans: 'obligaciones de pago',
  packages: 'paquetes',
  movements: 'movimientos de paquetes',
};

const countsOf = (datos) => Object.fromEntries(DATA_STORES.map((s) => [s, (datos[s] || []).length]));

// ------------------------------------------------------------------ construir / cifrar

export async function buildBackup(data = null) {
  const all = data || (await loadAll());
  const datos = Object.fromEntries(DATA_STORES.map((s) => [s, all[s] || []]));
  const configuracion = all.settings;
  const checksum = await sha256Hex(JSON.stringify({ datos, configuracion }));
  return {
    formato: BACKUP_FORMAT,
    version: BACKUP_VERSION,
    appVersion: APP_VERSION,
    exportadoEn: new Date().toISOString(),
    contadores: countsOf(datos),
    checksum,
    datos,
    configuracion,
  };
}

async function aesKey(password, salt, iterations, usages) {
  const base = await crypto.subtle.importKey('raw', new TextEncoder().encode(password), 'PBKDF2', false, ['deriveKey']);
  return crypto.subtle.deriveKey({ name: 'PBKDF2', hash: 'SHA-256', salt, iterations }, base, { name: 'AES-GCM', length: 256 }, false, usages);
}

const AAD = new TextEncoder().encode(`${BACKUP_ENC_FORMAT}:${BACKUP_VERSION}`);

export function validateBackupPassword(pw) {
  if (typeof pw !== 'string' || pw.length < 8) return 'La contraseña del respaldo debe tener al menos 8 caracteres.';
  return null;
}

/** Cifra con AES-256-GCM; la clave se deriva con PBKDF2-SHA256 (600 000 iteraciones). */
export async function encryptBackup(backup, password) {
  const err = validateBackupPassword(password);
  if (err) throw new BackupError('password', err);
  const salt = randomBytes(16);
  const iv = randomBytes(12);
  const key = await aesKey(password, salt, BACKUP_KDF_ITER, ['encrypt']);
  const plain = new TextEncoder().encode(JSON.stringify(backup));
  const cipher = await crypto.subtle.encrypt({ name: 'AES-GCM', iv, additionalData: AAD }, key, plain);
  return {
    formato: BACKUP_ENC_FORMAT,
    version: BACKUP_VERSION,
    cifrado: 'AES-256-GCM',
    kdf: 'PBKDF2-SHA256',
    iteraciones: BACKUP_KDF_ITER,
    sal: toB64(salt),
    iv: toB64(iv),
    exportadoEn: backup.exportadoEn,
    datos: toB64(new Uint8Array(cipher)),
  };
}

async function decryptEnvelope(env, password) {
  if (!password) throw new BackupError('falta_password', 'Este respaldo está cifrado. Escribe su contraseña.');
  if (env.kdf !== 'PBKDF2-SHA256' || env.cifrado !== 'AES-256-GCM' || !env.sal || !env.iv || !env.datos) {
    throw new BackupError('formato', 'El archivo cifrado no tiene un formato reconocido.');
  }
  const iter = Number(env.iteraciones);
  if (!Number.isInteger(iter) || iter < 100000 || iter > 5000000) throw new BackupError('formato', 'Parámetros de cifrado no válidos.');
  try {
    const key = await aesKey(password, fromB64(env.sal), iter, ['decrypt']);
    const plain = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: fromB64(env.iv), additionalData: AAD }, key, fromB64(env.datos));
    return JSON.parse(new TextDecoder().decode(plain));
  } catch {
    throw new BackupError('password', 'La contraseña es incorrecta o el archivo está dañado.');
  }
}

// ------------------------------------------------------------------ leer / validar

/** Revisa ids únicos y relaciones entre registros. Devuelve lista de problemas. */
export function checkIntegrity(datos) {
  const problems = [];
  const ids = {};
  for (const s of DATA_STORES) {
    ids[s] = new Set();
    for (const r of datos[s] || []) {
      if (!r || typeof r.id !== 'string' || !r.id) {
        problems.push(`Hay un registro sin identificador en ${STORE_LABELS[s]}.`);
        continue;
      }
      if (ids[s].has(r.id)) problems.push(`Identificador repetido en ${STORE_LABELS[s]}.`);
      ids[s].add(r.id);
    }
  }
  const ref = (store, field, target, label) => {
    for (const r of datos[store] || []) {
      if (r[field] && !ids[target].has(r[field])) problems.push(`${label} apunta a un registro que no existe.`);
    }
  };
  ref('appointments', 'patientId', 'patients', 'Una cita');
  ref('appointments', 'seriesId', 'series', 'Una cita de serie');
  ref('series', 'patientId', 'patients', 'Una serie');
  ref('payments', 'patientId', 'patients', 'Un pago');
  ref('payments', 'obligacionId', 'plans', 'Un pago');
  ref('plans', 'patientId', 'patients', 'Una obligación');
  ref('packages', 'patientId', 'patients', 'Un paquete');
  ref('movements', 'packageId', 'packages', 'Un movimiento de paquete');
  return [...new Set(problems)];
}

/** Valida estructura, versión, integridad (checksum) y relaciones. Lanza BackupError. */
export async function validateBackup(obj) {
  if (!obj || typeof obj !== 'object' || obj.formato !== BACKUP_FORMAT) {
    throw new BackupError('formato', 'El archivo no es un respaldo de esta agenda.');
  }
  if (!Number.isInteger(obj.version) || obj.version < 1) throw new BackupError('formato', 'El respaldo no indica su versión.');
  if (obj.version > BACKUP_VERSION) {
    throw new BackupError('version', `El respaldo fue creado con una versión más nueva (${obj.version}). Actualiza la aplicación antes de restaurarlo.`);
  }
  if (!obj.datos || typeof obj.datos !== 'object') throw new BackupError('formato', 'El respaldo no contiene datos.');
  for (const s of DATA_STORES) {
    if (!Array.isArray(obj.datos[s])) throw new BackupError('formato', `Falta la sección "${STORE_LABELS[s]}" en el respaldo.`);
  }
  const expected = await sha256Hex(JSON.stringify({ datos: obj.datos, configuracion: obj.configuracion }));
  if (!obj.checksum || expected !== obj.checksum) {
    throw new BackupError('checksum', 'El archivo está dañado o fue modificado: la verificación de integridad no coincide. No se cambió nada.');
  }
  const problems = checkIntegrity(obj.datos);
  if (problems.length) throw new BackupError('integridad', `El respaldo tiene datos inconsistentes: ${problems.slice(0, 3).join(' ')} No se cambió nada.`);
  return obj;
}

/** Lee el texto de un archivo de respaldo (cifrado o no) y lo valida SIN tocar la base local. */
export async function parseBackupFile(text, password = '') {
  let obj;
  try {
    obj = JSON.parse(text);
  } catch {
    throw new BackupError('formato', 'No se puede leer el archivo: no es un respaldo válido.');
  }
  if (obj && obj.formato === BACKUP_ENC_FORMAT) obj = await decryptEnvelope(obj, password);
  return validateBackup(obj);
}

export const isEncryptedText = (text) => {
  try {
    return JSON.parse(text)?.formato === BACKUP_ENC_FORMAT;
  } catch {
    return false;
  }
};

// ------------------------------------------------------------------ plan de importación

const stable = (v) => {
  if (Array.isArray(v)) return `[${v.map(stable).join(',')}]`;
  if (v && typeof v === 'object') {
    return `{${Object.keys(v)
      .sort()
      .map((k) => `${JSON.stringify(k)}:${stable(v[k])}`)
      .join(',')}}`;
  }
  return JSON.stringify(v);
};

/** Compara la base actual con el respaldo: nuevos, idénticos y en conflicto. */
export function planImport(current, backup) {
  const stores = {};
  for (const s of DATA_STORES) {
    const local = new Map((current[s] || []).map((r) => [r.id, r]));
    const nuevos = [];
    const identicos = [];
    const conflictos = [];
    for (const r of backup.datos[s]) {
      const l = local.get(r.id);
      if (!l) nuevos.push(r.id);
      else if (stable(l) === stable(r)) identicos.push(r.id);
      else conflictos.push(r.id);
    }
    stores[s] = { total: backup.datos[s].length, nuevos, identicos, conflictos, locales: local.size };
  }
  const localCounts = countsOf(current);
  return {
    stores,
    actualVacia: Object.values(localCounts).every((n) => n === 0),
    contadoresActuales: localCounts,
    contadoresRespaldo: countsOf(backup.datos),
    totalConflictos: Object.values(stores).reduce((a, x) => a + x.conflictos.length, 0),
    totalNuevos: Object.values(stores).reduce((a, x) => a + x.nuevos.length, 0),
    exportadoEn: backup.exportadoEn,
    appVersion: backup.appVersion,
  };
}

// ------------------------------------------------------------------ aplicar

async function snapshotCurrent() {
  const data = await loadAll();
  await setMeta('preRestoreSnapshot', { guardadoEn: new Date().toISOString(), contadores: countsOf(data), data });
}

const ALL = [...DATA_STORES, 'settings', 'meta'];

/**
 * Reemplaza TODA la base local por el contenido del respaldo.
 * Antes guarda una copia interna para poder revertir.
 */
export async function restoreReplace(backup) {
  await snapshotCurrent();
  await getDB().tx(ALL, 'readwrite', async (t) => {
    for (const s of DATA_STORES) {
      await t.clear(s);
      for (const r of backup.datos[s]) await t.put(s, r);
    }
    await t.put('settings', { ...mergeSettings(backup.configuracion), key: 'main' });
  });
  return { modo: 'reemplazar', contadores: countsOf(backup.datos) };
}

/**
 * Combina el respaldo con la base actual SIN duplicar (por identificador).
 * Los registros nuevos se agregan; los idénticos se omiten; en los que difieren, la
 * persona elige explícitamente: conservar lo local o usar lo del respaldo.
 * La configuración local no se modifica. Los registros eliminados localmente que
 * existan en el respaldo volverán a aparecer (no hay registro de eliminaciones).
 */
export async function restoreMerge(backup, current, { enConflicto = 'local' } = {}) {
  if (enConflicto !== 'local' && enConflicto !== 'respaldo') throw new BackupError('formato', 'Elige cómo resolver los conflictos.');
  const plan = planImport(current, backup);
  await snapshotCurrent();
  const resumen = { agregados: 0, omitidos: 0, reemplazados: 0, conservadosLocal: 0 };
  await getDB().tx(ALL, 'readwrite', async (t) => {
    for (const s of DATA_STORES) {
      const info = plan.stores[s];
      const nuevos = new Set(info.nuevos);
      const conflictos = new Set(info.conflictos);
      for (const r of backup.datos[s]) {
        if (nuevos.has(r.id)) {
          await t.put(s, r);
          resumen.agregados++;
        } else if (conflictos.has(r.id)) {
          if (enConflicto === 'respaldo') {
            await t.put(s, r);
            resumen.reemplazados++;
          } else resumen.conservadosLocal++;
        } else resumen.omitidos++;
      }
    }
  });
  return { modo: 'combinar', ...resumen };
}

export async function getPreRestoreSnapshot() {
  return getMeta('preRestoreSnapshot');
}

/** Vuelve al estado anterior a la última restauración. */
export async function revertLastRestore() {
  const snap = await getMeta('preRestoreSnapshot');
  if (!snap) throw new BackupError('formato', 'No hay ninguna restauración que revertir.');
  await getDB().tx(ALL, 'readwrite', async (t) => {
    for (const s of DATA_STORES) {
      await t.clear(s);
      for (const r of snap.data[s] || []) await t.put(s, r);
    }
    await t.put('settings', { ...mergeSettings(snap.data.settings), key: 'main' });
    await t.put('meta', { key: 'preRestoreSnapshot', value: null });
  });
}

export async function recordBackup(info) {
  await setMeta('lastBackup', { ...info, fecha: new Date().toISOString() });
}

export const getLastBackup = () => getMeta('lastBackup');

export function backupFileName(cifrado, fecha = new Date()) {
  const p = (n) => String(n).padStart(2, '0');
  const stamp = `${fecha.getFullYear()}${p(fecha.getMonth() + 1)}${p(fecha.getDate())}-${p(fecha.getHours())}${p(fecha.getMinutes())}`;
  return `respaldo-agenda-${stamp}${cifrado ? '-cifrado' : ''}.json`;
}
