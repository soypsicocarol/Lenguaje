// Servicio de agenda: citas, series recurrentes, estados, reprogramación y bloqueos.
// Cada operación compuesta corre en UNA transacción (todo o nada).

import { getDB } from '../core/store.js';
import { newId } from '../core/ids.js';
import { mergeSettings } from '../core/defaults.js';
import { ConflictError, ValidationError } from '../core/errors.js';
import { addDays, isValidDate, isValidTime, toMin, today as todayFn } from '../core/dates.js';
import { ABIERTOS, ESTADO_KEYS, SOLO_PASADO, WA_ESTADOS } from './estados.js';
import { findConflicts, hasConflicts, occupies, validateBlock } from './conflicts.js';
import { activeOccurrences, resolveEnd, validateSeries } from './recurrence.js';
import { syncBilling } from './effects.js';

export { ConflictError, ValidationError };

const ALL = ['patients', 'appointments', 'series', 'blocks', 'plans', 'packages', 'movements', 'payments', 'settings'];

const loadSettingsTx = async (t) => mergeSettings(await t.get('settings', 'main'));

async function conflictsFor(t, cand, settings, ignoreId) {
  const appointments = await t.byIndex('appointments', 'fecha', cand.fecha);
  const blocks = await t.all('blocks');
  return findConflicts(cand, { appointments, blocks, horario: settings.horario, ignoreId });
}

export function validateAppointmentInput(input, patient, { nuevo = true, hoy = todayFn() } = {}) {
  const e = [];
  if (!patient) e.push('Selecciona un paciente.');
  else if (nuevo && patient.estado !== 'activo') e.push('El paciente está inactivo. Actívalo para programar citas.');
  if (!isValidDate(input.fecha)) e.push('La fecha no es válida.');
  if (!isValidTime(input.inicio)) e.push('La hora de inicio no es válida.');
  const dur = Number(input.duracion);
  if (!Number.isInteger(dur) || dur < 5 || dur > 480) e.push('La duración debe estar entre 5 y 480 minutos.');
  else if (isValidTime(input.inicio) && toMin(input.inicio) + dur > 1440) e.push('La sesión no puede pasar de la medianoche.');
  if ((input.notaAdministrativa || '').length > 500) e.push('La nota administrativa es demasiado larga (máx. 500 caracteres).');
  if (input.tarifa !== null && input.tarifa !== undefined && input.tarifa !== '' && !(Number(input.tarifa) >= 0)) {
    e.push('La tarifa de la cita no es válida.');
  }
  return e;
}

function newAppointment(base, now) {
  return {
    seriesId: null,
    serieClave: null,
    serieFecha: null,
    estado: 'programada',
    motivoCancelacion: '',
    notaAdministrativa: '',
    tarifa: null,
    whatsappEstado: 'pendiente',
    paraReprogramar: false,
    reprogramadaDe: null,
    reprogramadaA: null,
    createdAt: now,
    updatedAt: now,
    historial: [{ at: now, tipo: 'creada' }],
    ...base,
  };
}

// ---------------------------------------------------------------- citas individuales

export async function createAppointment(input, opts = {}) {
  return getDB().tx(ALL, 'readwrite', async (t) => {
    const settings = await loadSettingsTx(t);
    const patient = input.patientId ? await t.get('patients', input.patientId) : null;
    const errors = validateAppointmentInput(input, patient);
    if (errors.length) throw new ValidationError(errors);
    const cand = { fecha: input.fecha, inicio: input.inicio, duracion: Number(input.duracion) };
    const conflicts = await conflictsFor(t, cand, settings, null);
    if (hasConflicts(conflicts) && !opts.allowConflict) throw new ConflictError(conflicts);
    const now = new Date().toISOString();
    const appt = newAppointment(
      {
        id: newId('apt'),
        patientId: patient.id,
        ...cand,
        notaAdministrativa: (input.notaAdministrativa || '').trim(),
        tarifa: input.tarifa === '' || input.tarifa === undefined ? null : input.tarifa,
      },
      now,
    );
    await t.put('appointments', appt);
    return appt;
  });
}

/** Edición de UNA cita (no toca al resto de la serie). */
export async function updateAppointment(id, changes, opts = {}) {
  return getDB().tx(ALL, 'readwrite', async (t) => {
    const settings = await loadSettingsTx(t);
    const appt = await t.get('appointments', id);
    if (!appt) throw new ValidationError('La cita ya no existe.');
    if (appt.estado === 'reprogramada') throw new ValidationError('Esta cita fue reprogramada. Edita la nueva cita.');
    const patient = await t.get('patients', appt.patientId);
    const next = {
      ...appt,
      fecha: changes.fecha ?? appt.fecha,
      inicio: changes.inicio ?? appt.inicio,
      duracion: changes.duracion !== undefined ? Number(changes.duracion) : appt.duracion,
      notaAdministrativa: changes.notaAdministrativa !== undefined ? changes.notaAdministrativa.trim() : appt.notaAdministrativa,
      tarifa: changes.tarifa !== undefined ? (changes.tarifa === '' ? null : changes.tarifa) : appt.tarifa,
    };
    const errors = validateAppointmentInput(next, patient, { nuevo: false });
    if (SOLO_PASADO.includes(next.estado) && next.fecha > todayFn()) {
      errors.push('Una sesión ya registrada como realizada o con inasistencia no puede moverse a una fecha futura.');
    }
    if (errors.length) throw new ValidationError(errors);
    const timeChanged = next.fecha !== appt.fecha || next.inicio !== appt.inicio || next.duracion !== appt.duracion;
    const now = new Date().toISOString();
    if (timeChanged) {
      if (occupies(next)) {
        const c = await conflictsFor(t, next, settings, appt.id);
        if (hasConflicts(c) && !opts.allowConflict) throw new ConflictError(c);
      }
      next.historial = [
        ...(appt.historial || []),
        { at: now, tipo: 'cambio_horario', de: { fecha: appt.fecha, inicio: appt.inicio, duracion: appt.duracion }, a: { fecha: next.fecha, inicio: next.inicio, duracion: next.duracion } },
      ];
      if (appt.seriesId) next.editadaIndividual = true;
    }
    next.updatedAt = now;
    await t.put('appointments', next);
    return next;
  });
}

/** Cambia el estado de la cita y aplica (una sola vez) sus efectos en paquetes y cobros. */
export async function setAppointmentStatus(id, estado, { motivo = '', paraReprogramar = false } = {}) {
  if (!ESTADO_KEYS.includes(estado) || estado === 'reprogramada') {
    throw new ValidationError('Estado no válido. Para reprogramar usa la opción "Reprogramar".');
  }
  return getDB().tx(ALL, 'readwrite', async (t) => {
    const settings = await loadSettingsTx(t);
    const appt = await t.get('appointments', id);
    if (!appt) throw new ValidationError('La cita ya no existe.');
    if (appt.estado === 'reprogramada') throw new ValidationError('Esta cita ya fue reprogramada. Cambia el estado de la nueva cita.');
    const patient = await t.get('patients', appt.patientId);
    if (SOLO_PASADO.includes(estado) && appt.fecha > todayFn()) {
      throw new ValidationError('No se puede marcar como realizada (o con inasistencia) una cita que todavía no ocurrió.');
    }
    const now = new Date().toISOString();
    const next = { ...appt };
    if (appt.estado !== estado) {
      next.historial = [...(appt.historial || []), { at: now, tipo: 'estado', de: appt.estado, a: estado, motivo: motivo || undefined }];
    }
    next.estado = estado;
    next.motivoCancelacion = estado.startsWith('cancelada') || estado === 'inasistencia' ? motivo.trim() : '';
    next.paraReprogramar = estado === 'cancelada_terapeuta' ? paraReprogramar !== false : false;
    next.updatedAt = now;
    await t.put('appointments', next);
    const avisos = await syncBilling(t, next, patient, settings);
    return { appointment: next, avisos };
  });
}

/**
 * Reprograma: la cita original queda "reprogramada" (vinculada) y se crea una nueva.
 * Solo la nueva puede contarse como realizada; la original nunca cuenta.
 */
export async function rescheduleAppointment(id, nuevo, opts = {}) {
  return getDB().tx(ALL, 'readwrite', async (t) => {
    const settings = await loadSettingsTx(t);
    const orig = await t.get('appointments', id);
    if (!orig) throw new ValidationError('La cita ya no existe.');
    if (orig.estado === 'reprogramada') throw new ValidationError('Esta cita ya fue reprogramada.');
    if (orig.estado === 'realizada') throw new ValidationError('Una sesión realizada no se puede reprogramar.');
    const patient = await t.get('patients', orig.patientId);
    const cand = {
      fecha: nuevo.fecha,
      inicio: nuevo.inicio,
      duracion: nuevo.duracion !== undefined ? Number(nuevo.duracion) : orig.duracion,
    };
    const errors = validateAppointmentInput({ ...cand, notaAdministrativa: nuevo.notaAdministrativa }, patient, { nuevo: false });
    if (cand.fecha === orig.fecha && cand.inicio === orig.inicio) errors.push('La nueva fecha u hora debe ser distinta de la original.');
    if (errors.length) throw new ValidationError(errors);
    const c = await conflictsFor(t, cand, settings, orig.id);
    if (hasConflicts(c) && !opts.allowConflict) throw new ConflictError(c);
    const now = new Date().toISOString();
    const nueva = newAppointment(
      {
        id: newId('apt'),
        patientId: orig.patientId,
        ...cand,
        seriesId: orig.seriesId || null,
        editadaIndividual: !!orig.seriesId,
        notaAdministrativa: (nuevo.notaAdministrativa ?? orig.notaAdministrativa ?? '').trim(),
        tarifa: orig.tarifa ?? null,
        reprogramadaDe: orig.id,
        historial: [{ at: now, tipo: 'creada', motivo: `Reprogramada desde ${orig.fecha} ${orig.inicio}` }],
      },
      now,
    );
    const origNext = {
      ...orig,
      estado: 'reprogramada',
      estadoPrevio: orig.estado,
      reprogramadaA: nueva.id,
      paraReprogramar: false,
      updatedAt: now,
      historial: [...(orig.historial || []), { at: now, tipo: 'estado', de: orig.estado, a: 'reprogramada', motivo: `Nueva fecha: ${cand.fecha} ${cand.inicio}` }],
    };
    await t.put('appointments', nueva);
    await t.put('appointments', origNext);
    const avisos = await syncBilling(t, origNext, patient, settings);
    return { original: origNext, nueva, avisos };
  });
}

export async function setWhatsAppState(id, estado) {
  if (!WA_ESTADOS[estado]) throw new ValidationError('Estado de contacto no válido.');
  return getDB().tx(['appointments'], 'readwrite', async (t) => {
    const appt = await t.get('appointments', id);
    if (!appt) throw new ValidationError('La cita ya no existe.');
    const next = { ...appt, whatsappEstado: estado, updatedAt: new Date().toISOString() };
    await t.put('appointments', next);
    return next;
  });
}

export async function deleteAppointment(id) {
  return getDB().tx(ALL, 'readwrite', async (t) => {
    const settings = await loadSettingsTx(t);
    const appt = await t.get('appointments', id);
    if (!appt) return { avisos: [] };
    if (appt.estado === 'realizada') {
      throw new ValidationError('No se puede eliminar una sesión realizada. Si fue un error, primero cambia su estado.');
    }
    const patient = await t.get('patients', appt.patientId);
    const now = new Date().toISOString();
    // Devuelve sesión al paquete / anula el cobro de esta cita antes de borrarla.
    const avisos = patient ? await syncBilling(t, { ...appt, estado: 'eliminada' }, patient, settings) : [];
    const ob = await t.get('plans', `ob_ses_${id}`);
    if (ob) {
      const pagos = (await t.byIndex('payments', 'obligacionId', ob.id)).filter((p) => p.estado !== 'anulado');
      if (!pagos.length) await t.del('plans', ob.id);
    }
    if (appt.reprogramadaDe) {
      const orig = await t.get('appointments', appt.reprogramadaDe);
      if (orig) {
        const restored = {
          ...orig,
          estado: orig.estadoPrevio || 'cancelada_terapeuta',
          reprogramadaA: null,
          paraReprogramar: true,
          updatedAt: now,
          historial: [...(orig.historial || []), { at: now, tipo: 'estado', de: 'reprogramada', a: orig.estadoPrevio || 'cancelada_terapeuta', motivo: 'Se eliminó la cita nueva' }],
        };
        await t.put('appointments', restored);
        if (patient) avisos.push(...(await syncBilling(t, restored, patient, settings)));
      }
    }
    if (appt.reprogramadaA) {
      const nueva = await t.get('appointments', appt.reprogramadaA);
      if (nueva) await t.put('appointments', { ...nueva, reprogramadaDe: null });
    }
    if (appt.seriesId && appt.serieClave) {
      const s = await t.get('series', appt.seriesId);
      if (s && !(s.excepciones || []).includes(appt.serieFecha)) {
        await t.put('series', { ...s, excepciones: [...(s.excepciones || []), appt.serieFecha], updatedAt: now });
      }
    }
    await t.del('appointments', id);
    return { avisos };
  });
}

// ---------------------------------------------------------------- series recurrentes

function normalizeDias(dias) {
  return [...dias]
    .map((d) => ({ dow: Number(d.dow), inicio: d.inicio, duracion: Number(d.duracion) }))
    .sort((a, b) => a.dow - b.dow);
}

function horizonFor(settings, hoy = todayFn()) {
  return addDays(hoy, Math.max(1, Number(settings.semanasAbiertas) || 12) * 7);
}

function appointmentFromOccurrence(series, occ, now) {
  return newAppointment(
    {
      id: `${series.id}__${occ.fecha}`,
      patientId: series.patientId,
      seriesId: series.id,
      serieClave: occ.clave,
      serieFecha: occ.fecha,
      fecha: occ.fecha,
      inicio: occ.inicio,
      duracion: occ.duracion,
    },
    now,
  );
}

/** Crea las citas que falten de la serie (idempotente: nunca duplica por serieClave). */
async function materialize(t, series, existingOfSeries, horizon, { skipDates = new Set(), fromDate = null, patientAppts = null } = {}) {
  const have = new Set(existingOfSeries.map((a) => a.serieClave).filter(Boolean));
  const taken = patientAppts ? new Set(patientAppts.filter(occupies).map((a) => `${a.fecha}|${a.inicio}`)) : null;
  const now = new Date().toISOString();
  const created = [];
  let duplicadas = 0;
  for (const occ of activeOccurrences(series, { horizon })) {
    if (fromDate && occ.fecha < fromDate) continue;
    if (have.has(occ.clave) || skipDates.has(occ.fecha)) continue;
    if (taken && taken.has(`${occ.fecha}|${occ.inicio}`)) {
      duplicadas++;
      continue;
    }
    const a = appointmentFromOccurrence(series, occ, now);
    await t.put('appointments', a);
    created.push(a);
  }
  return { created, duplicadas };
}

/** Citas de la serie que se pueden reemplazar: abiertas y que no son recuperaciones. */
const isReplaceable = (a) => ABIERTOS.includes(a.estado) && !a.reprogramadaDe;

async function overlapsFor(t, appts, settings) {
  const out = [];
  for (const a of appts) {
    const c = await conflictsFor(t, a, settings, a.id);
    if (c.citas.length || c.bloqueos.length) out.push({ appointment: a, conflicts: c });
  }
  return out;
}

/** Vista previa de las citas que se crearían (con conflictos marcados). */
export async function previewSeries(draft, { ignoreSeries = null } = {}) {
  const errors = validateSeries({ ...draft, dias: draft.dias || [] });
  if (errors.length) throw new ValidationError(errors);
  const db = getDB();
  const settings = mergeSettings(await db.get('settings', 'main'));
  const horizon = horizonFor(settings);
  const series = { ...draft, id: 'preview', dias: normalizeDias(draft.dias) };
  const occs = activeOccurrences(series, { horizon });
  if (!occs.length) return { rows: [], abierta: resolveEnd(series) === null, horizon };
  const first = occs[0].fecha;
  const last = occs[occs.length - 1].fecha;
  const [appointments, blocks, patientAppts] = await Promise.all([
    db.range('appointments', 'fecha', first, last),
    db.all('blocks'),
    draft.patientId ? db.byIndex('appointments', 'patientId', draft.patientId) : [],
  ]);
  const pool = ignoreSeries
    ? appointments.filter((a) => !(a.seriesId === ignoreSeries.seriesId && a.fecha >= ignoreSeries.fromDate && isReplaceable(a)))
    : appointments;
  const mine = new Set(patientAppts.filter(occupies).filter((a) => !ignoreSeries || a.seriesId !== ignoreSeries.seriesId).map((a) => `${a.fecha}|${a.inicio}`));
  const rows = occs.map((o) => {
    const c = findConflicts(o, { appointments: pool, blocks, horario: settings.horario });
    return { fecha: o.fecha, inicio: o.inicio, duracion: o.duracion, dow: o.dow, conflictos: c, solapa: c.citas.length > 0 || c.bloqueos.length > 0, duplicada: mine.has(`${o.fecha}|${o.inicio}`) };
  });
  return { rows, abierta: resolveEnd(series) === null, horizon };
}

export async function createSeries(draft, { excludeDates = [] } = {}) {
  return getDB().tx(ALL, 'readwrite', async (t) => {
    const settings = await loadSettingsTx(t);
    const patient = draft.patientId ? await t.get('patients', draft.patientId) : null;
    const errors = validateSeries(draft);
    if (!patient) errors.push('El paciente no existe.');
    else if (patient.estado !== 'activo') errors.push('El paciente está inactivo. Actívalo para programar citas.');
    if (errors.length) throw new ValidationError(errors);
    const now = new Date().toISOString();
    const series = {
      id: newId('ser'),
      patientId: patient.id,
      dias: normalizeDias(draft.dias),
      fechaInicio: draft.fechaInicio,
      fechaFin: resolveEnd(draft),
      repeticiones: draft.repeticiones ? Number(draft.repeticiones) : null,
      excepciones: [...new Set(excludeDates)].sort(),
      pausas: [],
      estado: 'activa',
      createdAt: now,
      updatedAt: now,
    };
    const patientAppts = await t.byIndex('appointments', 'patientId', patient.id);
    const { created, duplicadas } = await materialize(t, series, [], horizonFor(settings), { patientAppts });
    if (!created.length) {
      throw new ValidationError(
        duplicadas
          ? 'Todas esas citas ya existen para este paciente; no se creó nada nuevo.'
          : 'Con esas condiciones la serie no genera ninguna cita (revisa las fechas y las exclusiones).',
      );
    }
    await t.put('series', series);
    return { series, creadas: created.length, duplicadasOmitidas: duplicadas };
  });
}

/**
 * Edita "esta cita y las futuras" de una serie. Divide la serie en la fecha dada:
 * lo anterior queda intacto y lo futuro se regenera con los nuevos valores. Las citas
 * futuras que ya tienen resultado (realizada, cancelada...) NO se tocan.
 * changes: { dias?, fechaFin? (null = sin fin), repeticiones? }
 */
export async function editSeriesFrom(seriesId, fromDate, changes, opts = {}) {
  return getDB().tx(ALL, 'readwrite', async (t) => {
    const settings = await loadSettingsTx(t);
    const series = await t.get('series', seriesId);
    if (!series) throw new ValidationError('La serie ya no existe.');
    if (!isValidDate(fromDate)) throw new ValidationError('La fecha de corte no es válida.');
    const now = new Date().toISOString();
    const inPlace = fromDate <= series.fechaInicio;
    const dias = changes.dias ? normalizeDias(changes.dias) : series.dias;
    const origEnd = resolveEnd(series);
    let nuevoFin = origEnd;
    let reps = null;
    if (changes.fechaFin !== undefined) nuevoFin = changes.fechaFin || null;
    if (changes.repeticiones) {
      nuevoFin = addDays(fromDate, 7 * Number(changes.repeticiones) - 1);
      reps = Number(changes.repeticiones);
    }
    const target = inPlace
      ? { ...series, dias, fechaFin: nuevoFin, repeticiones: reps, updatedAt: now }
      : {
          ...series,
          id: newId('ser'),
          dias,
          fechaInicio: fromDate,
          fechaFin: nuevoFin,
          repeticiones: reps,
          excepciones: (series.excepciones || []).filter((d) => d >= fromDate),
          pausas: (series.pausas || []).filter((p) => p.hasta >= fromDate),
          origenSerieId: series.id,
          createdAt: now,
          updatedAt: now,
        };
    const errors = validateSeries({ ...target, repeticiones: target.repeticiones });
    if (errors.length) throw new ValidationError(errors);

    const existing = await t.byIndex('appointments', 'seriesId', series.id);
    const toDelete = existing.filter((a) => a.fecha >= fromDate && isReplaceable(a));
    for (const a of toDelete) await t.del('appointments', a.id);
    const kept = existing.filter((a) => !toDelete.includes(a));

    let created;
    if (inPlace) {
      ({ created } = await materialize(t, target, kept, horizonFor(settings), { fromDate }));
      await t.put('series', target);
    } else {
      const skipDates = new Set(kept.filter((a) => a.fecha >= fromDate && a.serieFecha).map((a) => a.serieFecha));
      kept.filter((a) => a.fecha >= fromDate).forEach((a) => skipDates.add(a.fecha));
      const old = { ...series, fechaFin: addDays(fromDate, -1), repeticiones: null, updatedAt: now };
      await t.put('series', old);
      ({ created } = await materialize(t, target, [], horizonFor(settings), { skipDates }));
      await t.put('series', target);
    }
    const overlaps = await overlapsFor(t, created, settings);
    if (overlaps.length && !opts.allowConflict) throw new ConflictError({ citas: overlaps.flatMap((o) => o.conflicts.citas), bloqueos: overlaps.flatMap((o) => o.conflicts.bloqueos), fueraDeHorario: false, detalle: overlaps });
    return { series: target, reemplazadas: toDelete.length, creadas: created.length };
  });
}

/** Edita TODA la serie, solo si es seguro: ninguna cita tiene todavía resultado. */
export async function editSeriesAll(seriesId, changes, opts = {}) {
  const db = getDB();
  const series = await db.get('series', seriesId);
  if (!series) throw new ValidationError('La serie ya no existe.');
  const citas = await db.byIndex('appointments', 'seriesId', seriesId);
  const conResultado = citas.filter((a) => !ABIERTOS.includes(a.estado) || a.reprogramadaDe);
  if (conResultado.length) {
    throw new ValidationError(
      `No es seguro editar toda la serie: ${conResultado.length} cita(s) ya tienen resultado o fueron reprogramadas. Usa "esta cita y las futuras" para no alterar el historial.`,
    );
  }
  return editSeriesFrom(seriesId, series.fechaInicio, changes, opts);
}

/** Termina la serie desde una fecha: borra las citas abiertas futuras y detiene la generación. */
export async function endSeries(seriesId, fromDate) {
  return getDB().tx(ALL, 'readwrite', async (t) => {
    const series = await t.get('series', seriesId);
    if (!series) throw new ValidationError('La serie ya no existe.');
    const existing = await t.byIndex('appointments', 'seriesId', seriesId);
    const toDelete = existing.filter((a) => a.fecha >= fromDate && isReplaceable(a));
    for (const a of toDelete) await t.del('appointments', a.id);
    const fin = addDays(fromDate, -1);
    await t.put('series', {
      ...series,
      fechaFin: fin,
      repeticiones: null,
      estado: fin < series.fechaInicio ? 'finalizada' : series.estado,
      updatedAt: new Date().toISOString(),
    });
    return { eliminadas: toDelete.length };
  });
}

/** Pausa (vacaciones, descanso): quita las citas abiertas del rango y evita regenerarlas. */
export async function addSeriesPause(seriesId, { desde, hasta, motivo = '' }) {
  if (!isValidDate(desde) || !isValidDate(hasta) || hasta < desde) throw new ValidationError('El rango de la pausa no es válido.');
  return getDB().tx(ALL, 'readwrite', async (t) => {
    const series = await t.get('series', seriesId);
    if (!series) throw new ValidationError('La serie ya no existe.');
    const existing = await t.byIndex('appointments', 'seriesId', seriesId);
    const toDelete = existing.filter((a) => a.fecha >= desde && a.fecha <= hasta && isReplaceable(a));
    for (const a of toDelete) await t.del('appointments', a.id);
    const pausa = { id: newId('pau'), desde, hasta, motivo: motivo.trim() };
    await t.put('series', { ...series, pausas: [...(series.pausas || []), pausa], updatedAt: new Date().toISOString() });
    return { pausa, eliminadas: toDelete.length };
  });
}

export async function removeSeriesPause(seriesId, pausaId) {
  return getDB().tx(ALL, 'readwrite', async (t) => {
    const settings = await loadSettingsTx(t);
    const series = await t.get('series', seriesId);
    if (!series) throw new ValidationError('La serie ya no existe.');
    const next = { ...series, pausas: (series.pausas || []).filter((p) => p.id !== pausaId), updatedAt: new Date().toISOString() };
    const existing = await t.byIndex('appointments', 'seriesId', seriesId);
    const { created } = await materialize(t, next, existing, horizonFor(settings));
    await t.put('series', next);
    return { restauradas: created.length };
  });
}

/** Amplía las series abiertas hasta el horizonte (se llama al abrir la app). */
export async function extendOpenSeries(hoy = todayFn()) {
  return getDB().tx(ALL, 'readwrite', async (t) => {
    const settings = await loadSettingsTx(t);
    const horizon = horizonFor(settings, hoy);
    let total = 0;
    for (const s of await t.all('series')) {
      if (s.estado !== 'activa' || resolveEnd(s) !== null) continue;
      const patient = await t.get('patients', s.patientId);
      if (!patient || patient.estado !== 'activo') continue;
      const existing = await t.byIndex('appointments', 'seriesId', s.id);
      const { created } = await materialize(t, s, existing, horizon);
      total += created.length;
    }
    return total;
  });
}

export async function getSeriesDetail(seriesId) {
  const db = getDB();
  const series = await db.get('series', seriesId);
  if (!series) return null;
  const citas = await db.byIndex('appointments', 'seriesId', seriesId);
  return { series, citas: citas.sort((a, b) => (a.fecha + a.inicio < b.fecha + b.inicio ? -1 : 1)) };
}

// ---------------------------------------------------------------- bloqueos

export async function saveBlock(input) {
  const errors = validateBlock(input);
  if (errors.length) throw new ValidationError(errors);
  if (!(input.motivo || '').trim()) throw new ValidationError('Indica el motivo del bloqueo (descanso, reunión, vacaciones...).');
  const now = new Date().toISOString();
  const block = {
    id: input.id || newId('blq'),
    fechaInicio: input.fechaInicio,
    fechaFin: input.fechaFin,
    horaInicio: input.todoElDia ? null : input.horaInicio,
    horaFin: input.todoElDia ? null : input.horaFin,
    todoElDia: !!input.todoElDia,
    motivo: input.motivo.trim(),
    repite: input.repite ? { dias: input.repite.dias.map(Number), hasta: input.repite.hasta || null } : null,
    demo: !!input.demo,
    createdAt: input.createdAt || now,
    updatedAt: now,
  };
  await getDB().put('blocks', block);
  return block;
}

export async function deleteBlock(id) {
  await getDB().del('blocks', id);
}

export async function listBlocks() {
  return getDB().all('blocks');
}
