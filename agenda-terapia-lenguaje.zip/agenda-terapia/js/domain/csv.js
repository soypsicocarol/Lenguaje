// Exportación CSV legible (se abre bien en Excel / Google Sheets).
// - Separador configurable (por defecto ";", el habitual en Excel en español).
// - BOM UTF-8 para que se vean bien las tildes.
// - Los textos que empiezan con = + - @ se neutralizan para evitar fórmulas inyectadas.

const FORMULA_START = /^[=+\-@\t\r]/;

export function csvCell(value, sep = ';') {
  if (value === null || value === undefined) return '';
  if (typeof value === 'number') return String(value);
  let s = String(value);
  if (FORMULA_START.test(s)) s = `'${s}`;
  if (s.includes('"') || s.includes('\n') || s.includes('\r') || s.includes(sep)) s = `"${s.replace(/"/g, '""')}"`;
  return s;
}

export function toCSV(headers, rows, sep = ';') {
  const lines = [headers.map((h) => csvCell(h, sep)).join(sep)];
  for (const r of rows) lines.push(r.map((c) => csvCell(c, sep)).join(sep));
  return `﻿${lines.join('\r\n')}\r\n`;
}
