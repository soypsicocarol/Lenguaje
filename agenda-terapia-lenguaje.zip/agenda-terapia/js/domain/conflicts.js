// Detección de conflictos de horario (funciones puras).
import { dow, isValidDate, isValidTime, toMin } from '../core/dates.js';
import { LIBERAN_HORARIO } from './estados.js';

export const occupies = (appt) => !LIBERAN_HORARIO.includes(appt.estado);

export const overlaps = (aStart, aEnd, bStart, bEnd) => aStart < bEnd && bStart < aEnd;

export function validateBlock(b) {
  const e = [];
  if (!isValidDate(b.fechaInicio)) e.push('La fecha de inicio del bloqueo no es válida.');
  if (!isValidDate(b.fechaFin)) e.push('La fecha final del bloqueo no es válida.');
  if (!b.todoElDia) {
    if (!isValidTime(b.horaInicio)) e.push('La hora de inicio del bloqueo no es válida.');
    if (!isValidTime(b.horaFin)) e.push('La hora final del bloqueo no es válida.');
  }
  if (isValidDate(b.fechaInicio) && isValidDate(b.fechaFin)) {
    if (b.fechaFin < b.fechaInicio) e.push('El bloqueo no puede terminar antes de empezar.');
    else if (!b.todoElDia && isValidTime(b.horaInicio) && isValidTime(b.horaFin)) {
      if (b.repite) {
        if (toMin(b.horaFin) <= toMin(b.horaInicio)) e.push('La hora final debe ser posterior a la inicial.');
      } else if (b.fechaInicio === b.fechaFin && toMin(b.horaFin) <= toMin(b.horaInicio)) {
        e.push('La hora final debe ser posterior a la inicial.');
      }
    }
  }
  if (b.repite) {
    if (!Array.isArray(b.repite.dias) || b.repite.dias.length === 0) e.push('Elige los días en que se repite el bloqueo.');
    if (b.repite.hasta && !isValidDate(b.repite.hasta)) e.push('La fecha límite de repetición no es válida.');
  }
  return e;
}

/** Intervalos [inicioMin, finMin] que el bloqueo ocupa en una fecha concreta. */
export function blockIntervalsForDate(block, fecha) {
  const allDay = !!block.todoElDia;
  if (block.repite) {
    if (fecha < block.fechaInicio) return [];
    const limite = block.repite.hasta || block.fechaFin;
    if (limite && fecha > limite) return [];
    if (!block.repite.dias.includes(dow(fecha))) return [];
    return allDay ? [[0, 1440]] : [[toMin(block.horaInicio), toMin(block.horaFin)]];
  }
  if (fecha < block.fechaInicio || fecha > block.fechaFin) return [];
  if (allDay) return [[0, 1440]];
  const s = fecha === block.fechaInicio ? toMin(block.horaInicio) : 0;
  const e = fecha === block.fechaFin ? toMin(block.horaFin) : 1440;
  return [[s, e]];
}

/**
 * Busca solapes del candidato { fecha, inicio, duracion } con otras citas y bloqueos.
 * @returns {{citas: object[], bloqueos: object[], fueraDeHorario: boolean}}
 */
export function findConflicts(candidate, { appointments = [], blocks = [], horario = null, ignoreId = null } = {}) {
  const s = toMin(candidate.inicio);
  const e = s + candidate.duracion;
  const citas = appointments.filter(
    (a) =>
      a.id !== ignoreId &&
      a.fecha === candidate.fecha &&
      occupies(a) &&
      overlaps(s, e, toMin(a.inicio), toMin(a.inicio) + a.duracion),
  );
  const bloqueos = blocks.filter((b) => blockIntervalsForDate(b, candidate.fecha).some(([bs, be]) => overlaps(s, e, bs, be)));
  let fueraDeHorario = false;
  if (horario) {
    const h = horario[dow(candidate.fecha)];
    fueraDeHorario = !h || !h.abierto || s < toMin(h.desde) || e > toMin(h.hasta);
  }
  return { citas, bloqueos, fueraDeHorario };
}

export const hasConflicts = (c) => c.citas.length > 0 || c.bloqueos.length > 0 || c.fueraDeHorario;
