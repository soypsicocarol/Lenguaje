// Pagos, obligaciones y paquetes.
//
// - Un PAGO es dinero que la terapeuta declara haber recibido. Nunca se edita en silencio:
//   se anula (con motivo), se reasigna o se corrige (anula + crea uno nuevo enlazado).
// - Una OBLIGACIÓN (PaymentPlan) es lo que se debe: una sesión, un período o un paquete.
// - El saldo se CALCULA (obligación - pagos vigentes); no se guarda.

import { getDB } from '../core/store.js';
import { newId } from '../core/ids.js';
import { mergeSettings } from '../core/defaults.js';
import { OverpayError, ValidationError } from '../core/errors.js';
import { isValidDate, today as todayFn } from '../core/dates.js';
import { fromCents, toCents } from '../core/money.js';
import { obligationSummary } from './finance.js';
import { packageSummary } from './packages.js';

const ALL = ['patients', 'plans', 'payments', 'packages', 'movements', 'settings'];

const clean = (s) => (s ?? '').toString().trim();

export function validatePayment(p, { hoy = todayFn() } = {}) {
  const e = [];
  if (!p.patientId) e.push('Selecciona un paciente.');
  if (!isValidDate(p.fecha)) e.push('La fecha del pago no es válida.');
  else if (p.fecha > hoy) e.push('La fecha del pago no puede ser futura: solo se registran pagos ya recibidos.');
  const imp = Number(p.importe);
  if (!Number.isFinite(imp) || imp <= 0) e.push('El importe debe ser mayor que cero.');
  else if (Math.abs(imp * 100 - Math.round(imp * 100)) > 1e-6) e.push('El importe solo admite dos decimales.');
  if (!clean(p.moneda)) e.push('Elige la moneda.');
  if (!clean(p.metodo)) e.push('Elige el método de pago.');
  if (!clean(p.concepto)) e.push('Escribe el concepto del pago (ej. "Sesión del 12/11").');
  if (clean(p.nota).length > 300) e.push('La nota es demasiado larga (máx. 300 caracteres).');
  return e;
}

async function obligationSnapshot(t, ob) {
  const pagos = await t.byIndex('payments', 'obligacionId', ob.id);
  return obligationSummary(ob, pagos);
}

/**
 * Registra un pago recibido. Si supera el saldo de la obligación asociada lanza
 * OverpayError: la interfaz debe confirmar (el excedente queda "a favor").
 */
export async function savePayment(input, opts = {}) {
  return getDB().tx(ALL, 'readwrite', async (t) => {
    const patient = input.patientId ? await t.get('patients', input.patientId) : null;
    const errors = validatePayment(input);
    if (!patient) errors.push('El paciente no existe.');
    let moneda = clean(input.moneda).toUpperCase();
    let ob = null;
    if (input.obligacionId) {
      ob = await t.get('plans', input.obligacionId);
      if (!ob || ob.patientId !== input.patientId) errors.push('La obligación seleccionada no corresponde a este paciente.');
      else if (ob.estado === 'anulada') errors.push('La obligación seleccionada está anulada.');
      else moneda = ob.moneda; // el pago siempre va en la moneda de lo que se debe
    }
    if (errors.length) throw new ValidationError(errors);
    if (ob) {
      const snap = await obligationSnapshot(t, ob);
      const exceso = fromCents(toCents(input.importe) - toCents(snap.pendiente));
      if (exceso > 0 && !opts.allowOverpay) throw new OverpayError(exceso, ob.moneda);
    }
    const now = new Date().toISOString();
    const payment = {
      id: newId('pag'),
      patientId: patient.id,
      fecha: input.fecha,
      importe: fromCents(toCents(input.importe)),
      moneda,
      metodo: clean(input.metodo),
      concepto: clean(input.concepto),
      obligacionId: ob ? ob.id : null,
      packageId: ob?.packageId || null,
      nota: clean(input.nota),
      estado: 'vigente',
      corrigeA: input.corrigeA || null,
      historial: [{ at: now, tipo: 'registrado' }],
      demo: patient.demo || false,
      createdAt: now,
    };
    await t.put('payments', payment);
    return payment;
  });
}

/** Anula un pago (queda en el historial, no se borra ni se suma). */
export async function voidPayment(id, motivo) {
  if (!clean(motivo)) throw new ValidationError('Indica el motivo de la anulación.');
  return getDB().tx(['payments'], 'readwrite', async (t) => {
    const p = await t.get('payments', id);
    if (!p) throw new ValidationError('El pago ya no existe.');
    if (p.estado === 'anulado') throw new ValidationError('Este pago ya está anulado.');
    const now = new Date().toISOString();
    const next = { ...p, estado: 'anulado', motivoAnulacion: clean(motivo), anuladoEn: now, historial: [...(p.historial || []), { at: now, tipo: 'anulado', motivo: clean(motivo) }] };
    await t.put('payments', next);
    return next;
  });
}

/** Corrección explícita: anula el pago original (con motivo) y crea uno nuevo enlazado. */
export async function correctPayment(id, changes, motivo, opts = {}) {
  if (!clean(motivo)) throw new ValidationError('Indica el motivo de la corrección.');
  const db = getDB();
  const original = await db.get('payments', id);
  if (!original) throw new ValidationError('El pago ya no existe.');
  if (original.estado === 'anulado') throw new ValidationError('Este pago ya está anulado.');
  const draft = { ...original, ...changes, patientId: original.patientId, corrigeA: original.id };
  // Valida y simula ANTES de anular para no dejar el estado a medias.
  return db.tx(ALL, 'readwrite', async (t) => {
    const cur = await t.get('payments', id);
    const now = new Date().toISOString();
    const anulado = { ...cur, estado: 'anulado', motivoAnulacion: `Corregido: ${clean(motivo)}`, anuladoEn: now, historial: [...(cur.historial || []), { at: now, tipo: 'corregido', motivo: clean(motivo) }] };
    await t.put('payments', anulado);
    const errors = validatePayment(draft);
    let ob = null;
    let moneda = clean(draft.moneda).toUpperCase();
    if (draft.obligacionId) {
      ob = await t.get('plans', draft.obligacionId);
      if (!ob || ob.patientId !== draft.patientId || ob.estado === 'anulada') errors.push('La obligación seleccionada no es válida.');
      else moneda = ob.moneda;
    }
    if (errors.length) throw new ValidationError(errors);
    if (ob) {
      const snap = await obligationSnapshot(t, ob); // el original ya está anulado
      const exceso = fromCents(toCents(draft.importe) - toCents(snap.pendiente));
      if (exceso > 0 && !opts.allowOverpay) throw new OverpayError(exceso, ob.moneda);
    }
    const nuevo = {
      id: newId('pag'),
      patientId: draft.patientId,
      fecha: draft.fecha,
      importe: fromCents(toCents(draft.importe)),
      moneda,
      metodo: clean(draft.metodo),
      concepto: clean(draft.concepto),
      obligacionId: ob ? ob.id : null,
      packageId: ob?.packageId || null,
      nota: clean(draft.nota),
      estado: 'vigente',
      corrigeA: id,
      historial: [{ at: now, tipo: 'registrado', motivo: `Corrige al pago ${id}: ${clean(motivo)}` }],
      demo: cur.demo || false,
      createdAt: now,
    };
    await t.put('payments', nuevo);
    return { anulado, nuevo };
  });
}

/** Asocia un pago "sin asignar" (o cambia su obligación) dejando constancia en el historial. */
export async function reassignPayment(id, obligacionId, motivo) {
  if (!clean(motivo)) throw new ValidationError('Indica el motivo del cambio.');
  return getDB().tx(ALL, 'readwrite', async (t) => {
    const p = await t.get('payments', id);
    if (!p) throw new ValidationError('El pago ya no existe.');
    if (p.estado === 'anulado') throw new ValidationError('No se puede reasignar un pago anulado.');
    let ob = null;
    if (obligacionId) {
      ob = await t.get('plans', obligacionId);
      if (!ob || ob.patientId !== p.patientId || ob.estado === 'anulada') throw new ValidationError('La obligación seleccionada no es válida.');
      if (ob.moneda !== p.moneda) throw new ValidationError(`El pago es en ${p.moneda} y la obligación en ${ob.moneda}: no se pueden mezclar monedas.`);
    }
    const now = new Date().toISOString();
    const next = { ...p, obligacionId: ob ? ob.id : null, packageId: ob?.packageId || null, historial: [...(p.historial || []), { at: now, tipo: 'reasignado', de: p.obligacionId, a: ob ? ob.id : null, motivo: clean(motivo) }] };
    await t.put('payments', next);
    return next;
  });
}

// ------------------------------------------------------------------ obligaciones

/** Obligación manual (cobro por período semanal/mensual u otro concepto). */
export async function saveObligation(input) {
  const e = [];
  if (!input.patientId) e.push('Selecciona un paciente.');
  const imp = Number(input.importe);
  if (!Number.isFinite(imp) || imp <= 0) e.push('El importe debe ser mayor que cero.');
  if (!clean(input.concepto)) e.push('Escribe el concepto (ej. "Mensualidad de noviembre").');
  if (!clean(input.moneda)) e.push('Elige la moneda.');
  if (input.fechaInicio && !isValidDate(input.fechaInicio)) e.push('La fecha de inicio no es válida.');
  if (input.fechaFin && !isValidDate(input.fechaFin)) e.push('La fecha final no es válida.');
  if (input.fechaInicio && input.fechaFin && input.fechaFin < input.fechaInicio) e.push('El período termina antes de empezar.');
  return getDB().tx(['patients', 'plans'], 'readwrite', async (t) => {
    const patient = input.patientId ? await t.get('patients', input.patientId) : null;
    if (!patient) e.push('El paciente no existe.');
    if (e.length) throw new ValidationError(e);
    const now = new Date().toISOString();
    const ob = {
      id: newId('obl'),
      patientId: patient.id,
      tipo: 'periodo',
      periodoTipo: input.periodoTipo || null,
      concepto: clean(input.concepto),
      importe: fromCents(toCents(imp)),
      moneda: clean(input.moneda).toUpperCase(),
      fechaInicio: input.fechaInicio || null,
      fechaFin: input.fechaFin || null,
      estado: 'activa',
      historial: [{ at: now, tipo: 'creada' }],
      demo: patient.demo || false,
      createdAt: now,
    };
    await t.put('plans', ob);
    return ob;
  });
}

export async function voidObligation(id, motivo) {
  if (!clean(motivo)) throw new ValidationError('Indica el motivo de la anulación.');
  return getDB().tx(['plans', 'payments'], 'readwrite', async (t) => {
    const ob = await t.get('plans', id);
    if (!ob) throw new ValidationError('La obligación ya no existe.');
    if (ob.estado === 'anulada') throw new ValidationError('Ya está anulada.');
    const now = new Date().toISOString();
    await t.put('plans', { ...ob, estado: 'anulada', motivoAnulacion: clean(motivo), historial: [...(ob.historial || []), { at: now, tipo: 'anulada', motivo: clean(motivo) }] });
    const pagos = (await t.byIndex('payments', 'obligacionId', id)).filter((p) => p.estado !== 'anulado');
    return { pagosQuedanAFavor: pagos.length };
  });
}

// ------------------------------------------------------------------ paquetes

export function validatePackage(p, { hoy = todayFn() } = {}) {
  const e = [];
  if (!p.patientId) e.push('Selecciona un paciente.');
  if (!clean(p.nombre)) e.push('Escribe un nombre para el paquete (ej. "Paquete de 8 sesiones").');
  const n = Number(p.cantidadInicial);
  if (!Number.isInteger(n) || n < 1 || n > 500) e.push('La cantidad de sesiones debe ser un número entero entre 1 y 500.');
  const precio = Number(p.precio);
  if (!Number.isFinite(precio) || precio < 0) e.push('El precio no es válido.');
  if (!clean(p.moneda)) e.push('Elige la moneda.');
  if (!isValidDate(p.fechaCompra)) e.push('La fecha de compra no es válida.');
  if (p.vigencia && !isValidDate(p.vigencia)) e.push('La fecha de vigencia no es válida.');
  else if (p.vigencia && isValidDate(p.fechaCompra) && p.vigencia < p.fechaCompra) e.push('La vigencia no puede ser anterior a la compra.');
  void hoy;
  return e;
}

/**
 * Crea un paquete y su obligación de pago por el precio. Opcionalmente registra un pago
 * inicial (solo si la terapeuta lo declara recibido).
 */
export async function createPackage(input, pagoInicial = null) {
  const errors = validatePackage(input);
  return getDB().tx(ALL, 'readwrite', async (t) => {
    const patient = input.patientId ? await t.get('patients', input.patientId) : null;
    if (!patient) errors.push('El paciente no existe.');
    if (pagoInicial) {
      const pe = validatePayment({ ...pagoInicial, patientId: input.patientId, moneda: input.moneda, concepto: pagoInicial.concepto || clean(input.nombre) });
      errors.push(...pe);
      if (toCents(pagoInicial.importe) > toCents(input.precio)) errors.push('El pago inicial no puede superar el precio del paquete.');
    }
    if (errors.length) throw new ValidationError(errors);
    const now = new Date().toISOString();
    const pkg = {
      id: newId('paq'),
      patientId: patient.id,
      nombre: clean(input.nombre),
      cantidadInicial: Number(input.cantidadInicial),
      precio: fromCents(toCents(input.precio)),
      moneda: clean(input.moneda).toUpperCase(),
      fechaCompra: input.fechaCompra,
      vigencia: input.vigencia || null,
      estado: 'activo',
      demo: patient.demo || false,
      createdAt: now,
    };
    const ob = {
      id: `ob_pkg_${pkg.id}`,
      patientId: patient.id,
      tipo: 'paquete',
      packageId: pkg.id,
      concepto: pkg.nombre,
      importe: pkg.precio,
      moneda: pkg.moneda,
      fechaInicio: pkg.fechaCompra,
      fechaFin: pkg.vigencia,
      estado: 'activa',
      historial: [{ at: now, tipo: 'creada' }],
      demo: pkg.demo,
      createdAt: now,
    };
    await t.put('packages', pkg);
    await t.put('plans', ob);
    let pago = null;
    if (pagoInicial) {
      pago = {
        id: newId('pag'),
        patientId: patient.id,
        fecha: pagoInicial.fecha,
        importe: fromCents(toCents(pagoInicial.importe)),
        moneda: pkg.moneda,
        metodo: clean(pagoInicial.metodo),
        concepto: clean(pagoInicial.concepto) || pkg.nombre,
        obligacionId: ob.id,
        packageId: pkg.id,
        nota: clean(pagoInicial.nota),
        estado: 'vigente',
        corrigeA: null,
        historial: [{ at: now, tipo: 'registrado' }],
        demo: pkg.demo,
        createdAt: now,
      };
      await t.put('payments', pago);
    }
    return { pkg, obligacion: ob, pago };
  });
}

/** Ajuste manual de sesiones (±n) con motivo y fecha. La confirmación la pide la interfaz. */
export async function adjustPackage(packageId, delta, motivo, fecha = todayFn()) {
  const d = Number(delta);
  if (!Number.isInteger(d) || d === 0) throw new ValidationError('El ajuste debe ser un número entero distinto de cero (ej. 1 o -1).');
  if (!clean(motivo)) throw new ValidationError('Indica el motivo del ajuste.');
  if (!isValidDate(fecha)) throw new ValidationError('La fecha del ajuste no es válida.');
  return getDB().tx(['packages', 'movements'], 'readwrite', async (t) => {
    const pkg = await t.get('packages', packageId);
    if (!pkg) throw new ValidationError('El paquete ya no existe.');
    const movs = await t.byIndex('movements', 'packageId', packageId);
    const s = packageSummary(pkg, movs, fecha);
    if (s.disponibles + d < 0) throw new ValidationError(`El ajuste dejaría el paquete en ${s.disponibles + d} sesiones. El mínimo es 0.`);
    const mov = { id: newId('pm'), packageId, appointmentId: null, tipo: 'ajuste', delta: d, fecha, motivo: clean(motivo), createdAt: new Date().toISOString() };
    await t.put('movements', mov);
    return mov;
  });
}

/** Anula un paquete (y su obligación). Los pagos ya recibidos quedan como saldo a favor. */
export async function voidPackage(packageId, motivo) {
  if (!clean(motivo)) throw new ValidationError('Indica el motivo de la anulación.');
  return getDB().tx(['packages', 'plans', 'payments'], 'readwrite', async (t) => {
    const pkg = await t.get('packages', packageId);
    if (!pkg) throw new ValidationError('El paquete ya no existe.');
    const now = new Date().toISOString();
    await t.put('packages', { ...pkg, estado: 'anulado', motivoAnulacion: clean(motivo), anuladoEn: now });
    const ob = await t.get('plans', `ob_pkg_${packageId}`);
    let pagos = 0;
    if (ob && ob.estado !== 'anulada') {
      await t.put('plans', { ...ob, estado: 'anulada', motivoAnulacion: `Paquete anulado: ${clean(motivo)}`, historial: [...(ob.historial || []), { at: now, tipo: 'anulada', motivo: clean(motivo) }] });
      pagos = (await t.byIndex('payments', 'obligacionId', ob.id)).filter((p) => p.estado !== 'anulado').length;
    }
    return { pagosQuedanAFavor: pagos };
  });
}

export async function getSettings() {
  return mergeSettings(await getDB().get('settings', 'main'));
}
