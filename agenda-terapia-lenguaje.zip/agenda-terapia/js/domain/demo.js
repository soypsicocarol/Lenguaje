// Datos de demostración 100 % FICTICIOS. Se crean usando los mismos servicios que la
// aplicación real (nada está "cableado") y se marcan con demo:true para poder
// eliminarlos fácilmente desde Configuración sin tocar datos reales.

import { getDB } from '../core/store.js';
import { addDays, startOfWeek, today as todayFn } from '../core/dates.js';
import { savePatient, deletePatientPermanently } from './patients.js';
import { createSeries, createAppointment, setAppointmentStatus, saveBlock, deleteBlock } from './agenda.js';
import { createPackage, savePayment, saveObligation } from './billing.js';

const base = (extra) => ({ fechaIngreso: '2026-01-12', estado: 'activo', frecuencia: '', notasAdministrativas: '', demo: true, ...extra });

export async function loadDemoData(hoy = todayFn()) {
  const db = getDB();
  const existing = (await db.all('patients')).filter((p) => p.demo);
  if (existing.length) throw new Error('Ya hay datos de demostración cargados.');
  const lunes = startOfWeek(hoy);
  const inicio = addDays(lunes, -14);

  const mateo = await savePatient(base({ nombre: 'Mateo', apellidos: 'Demo Uno', fechaNacimiento: '2020-03-14', representante: 'Representante Demo A', telefono: '+58 400 0000001', modalidadCobro: 'sesion', tarifa: 20, moneda: 'USD', frecuencia: '2 veces por semana' }));
  const sofia = await savePatient(base({ nombre: 'Sofía', apellidos: 'Demo Dos', fechaNacimiento: '2019-08-02', representante: 'Representante Demo B', telefono: '+58 400 0000002', modalidadCobro: 'paquete', tarifa: 15, moneda: 'USD' }));
  const daniel = await savePatient(base({ nombre: 'Daniel', apellidos: 'Demo Tres', fechaNacimiento: '2018-11-21', representante: 'Representante Demo C', telefono: '+58 400 0000003', modalidadCobro: 'periodo', periodoTipo: 'mensual', tarifa: 160, moneda: 'USD', frecuencia: '2 veces por semana' }));
  const vale = await savePatient(base({ nombre: 'Valentina', apellidos: 'Demo Cuatro', fechaNacimiento: '2021-05-30', representante: 'Representante Demo D', telefono: '+58 400 0000004', modalidadCobro: 'sesion', tarifa: 18, moneda: 'USD', frecuencia: 'Horario variable' }));
  await savePatient(base({ nombre: 'Andrés', apellidos: 'Demo Cinco', fechaNacimiento: '2017-01-09', representante: 'Representante Demo E', telefono: '+58 400 0000005', modalidadCobro: 'sesion', tarifa: 20, moneda: 'USD', estado: 'activo' }))
    .then((p) => import('./patients.js').then((m) => m.setPatientActive(p.id, false)));

  await createSeries({ patientId: mateo.id, fechaInicio: inicio, dias: [{ dow: 1, inicio: '15:00', duracion: 45 }, { dow: 4, inicio: '15:00', duracion: 45 }], repeticiones: 6 });
  await createSeries({ patientId: sofia.id, fechaInicio: inicio, dias: [{ dow: 2, inicio: '16:00', duracion: 45 }], repeticiones: 8 });
  await createSeries({ patientId: daniel.id, fechaInicio: inicio, dias: [{ dow: 3, inicio: '10:00', duracion: 60 }, { dow: 5, inicio: '10:00', duracion: 60 }], repeticiones: 6 });
  // Citas variables (sin serie) para Valentina
  await createAppointment({ patientId: vale.id, fecha: addDays(lunes, -5), inicio: '14:00', duracion: 45 });
  await createAppointment({ patientId: vale.id, fecha: addDays(lunes, 2), inicio: '15:00', duracion: 45 });
  await createAppointment({ patientId: vale.id, fecha: addDays(lunes, 10), inicio: '09:30', duracion: 45 });

  await saveBlock({ demo: true, fechaInicio: lunes, fechaFin: lunes, horaInicio: '15:00', horaFin: '17:00', motivo: 'Reunión (demo)', repite: { dias: [5], hasta: addDays(lunes, 60) } });

  // Resultados de las citas pasadas (usa el mismo flujo que la interfaz).
  let n = 0;
  const pasadas = (await db.all('appointments')).filter((a) => a.fecha < hoy).sort((a, b) => (a.fecha + a.inicio < b.fecha + b.inicio ? -1 : 1));
  for (const a of pasadas) {
    n++;
    if (n % 9 === 0) await setAppointmentStatus(a.id, 'inasistencia', { motivo: 'Demo' });
    else if (n % 11 === 0) await setAppointmentStatus(a.id, 'cancelada_representante', { motivo: 'Demo: enfermedad' });
    else await setAppointmentStatus(a.id, 'realizada');
  }

  // Paquete de 8 sesiones para Sofía (pagado completo) y pagos de ejemplo.
  const { pkg } = await createPackage(
    { patientId: sofia.id, nombre: 'Paquete de 8 sesiones', cantidadInicial: 8, precio: 120, moneda: 'USD', fechaCompra: inicio, vigencia: null },
    { fecha: inicio, importe: 120, metodo: 'Transferencia', concepto: 'Paquete de 8 sesiones' },
  );
  // Las sesiones de Sofía ya realizadas se descuentan con la misma lógica real:
  for (const a of (await db.byIndex('appointments', 'patientId', sofia.id)).filter((x) => x.estado === 'realizada')) {
    await setAppointmentStatus(a.id, 'realizada');
  }

  const obs = await db.byIndex('plans', 'patientId', mateo.id);
  const primera = obs.filter((o) => o.tipo === 'sesion').sort((a, b) => (a.fechaInicio < b.fechaInicio ? -1 : 1))[0];
  if (primera) await savePayment({ patientId: mateo.id, fecha: primera.fechaInicio, importe: primera.importe, moneda: 'USD', metodo: 'Efectivo', concepto: primera.concepto, obligacionId: primera.id });

  const mensual = await saveObligation({ patientId: daniel.id, concepto: 'Mensualidad (demo)', importe: 160, moneda: 'USD', periodoTipo: 'mensual', fechaInicio: inicio, fechaFin: addDays(inicio, 29) });
  await savePayment({ patientId: daniel.id, fecha: addDays(inicio, 1), importe: 80, moneda: 'USD', metodo: 'Pago móvil', concepto: 'Abono mensualidad', obligacionId: mensual.id });
  void pkg;
  return { pacientes: 5 };
}

export async function deleteDemoData() {
  const db = getDB();
  const demos = (await db.all('patients')).filter((p) => p.demo);
  const totals = { pacientes: 0, citas: 0, pagos: 0, paquetes: 0, bloqueos: 0 };
  for (const p of demos) {
    const c = await deletePatientPermanently(p.id);
    totals.pacientes++;
    totals.citas += c.citas;
    totals.pagos += c.pagos;
    totals.paquetes += c.paquetes;
  }
  for (const b of (await db.all('blocks')).filter((x) => x.demo)) {
    await deleteBlock(b.id);
    totals.bloqueos++;
  }
  return totals;
}

export async function hasDemoData() {
  return (await getDB().all('patients')).some((p) => p.demo);
}
