// Cálculo de paquetes de sesiones (funciones puras).
//
// El saldo de un paquete NO se guarda: se calcula siempre a partir de los movimientos.
//   disponibles = sesiones iniciales + suma(delta de todos los movimientos)
// consumo = -1, devolución = +1, ajuste manual = ±n.
// Esto hace imposible descontar dos veces: guardar de nuevo una cita no añade movimientos
// si el consumo neto de esa cita ya coincide con el deseado.

export function packageSummary(pkg, movements, today) {
  const mine = movements.filter((m) => m.packageId === pkg.id);
  const consumidas = -mine.filter((m) => m.tipo === 'consumo' || m.tipo === 'devolucion').reduce((a, m) => a + m.delta, 0);
  const ajustes = mine.filter((m) => m.tipo === 'ajuste').reduce((a, m) => a + m.delta, 0);
  const iniciales = pkg.cantidadInicial;
  const disponibles = iniciales - consumidas + ajustes;
  let estado = 'activo';
  if (pkg.estado === 'anulado') estado = 'anulado';
  else if (disponibles <= 0) estado = 'agotado';
  else if (pkg.vigencia && today && pkg.vigencia < today) estado = 'vencido';
  return { iniciales, consumidas, ajustes, disponibles, estado };
}

/** Sesiones netas consumidas por una cita (0 o 1 normalmente). */
export function netConsumption(movementsOfAppointment) {
  return -movementsOfAppointment.filter((m) => m.tipo === 'consumo' || m.tipo === 'devolucion').reduce((a, m) => a + m.delta, 0);
}

/**
 * Elige el paquete del que se descuenta una sesión: activo, con sesiones disponibles y
 * vigente en la fecha de la cita. Primero el más antiguo.
 */
export function pickPackage(packages, movements, fechaCita, today) {
  const candidates = packages
    .filter((p) => {
      const s = packageSummary(p, movements, today);
      if (s.estado === 'anulado' || s.disponibles <= 0) return false;
      if (p.vigencia && fechaCita > p.vigencia) return false;
      return true;
    })
    .sort((a, b) => (a.fechaCompra < b.fechaCompra ? -1 : a.fechaCompra > b.fechaCompra ? 1 : a.id < b.id ? -1 : 1));
  return candidates[0] || null;
}
