// Bloqueo de acceso local con PIN o contraseña.
//
// LÍMITES (se explican también en la documentación y en Configuración):
//  - Es un bloqueo de PANTALLA: impide usar la aplicación sin la clave, pero NO cifra la
//    base de datos del navegador. Quien tenga acceso al dispositivo desbloqueado y a las
//    herramientas del navegador podría leer los datos almacenados.
//  - La clave nunca se guarda en texto plano: se guarda un hash PBKDF2-SHA256 con sal.
//  - Los intentos fallidos se limitan con esperas crecientes (frenan adivinar a mano,
//    pero no detienen a alguien con acceso técnico a los datos locales).
//  - No existe recuperación de clave: si se olvida, solo queda borrar los datos locales
//    y restaurar un respaldo.

import { getMeta, setMeta } from '../core/store.js';
import { fromB64, randomBytes, safeEqual, toB64 } from '../core/bytes.js';

export const AUTH_ITERATIONS = 600000;
const MAX_FREE_ATTEMPTS = 5;

async function derive(secret, salt, iterations) {
  const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(secret), 'PBKDF2', false, ['deriveBits']);
  const bits = await crypto.subtle.deriveBits({ name: 'PBKDF2', hash: 'SHA-256', salt, iterations }, key, 256);
  return toB64(new Uint8Array(bits));
}

export function validateSecret(secret) {
  if (typeof secret !== 'string' || secret.length < 4) return 'La clave debe tener al menos 4 caracteres.';
  if (secret.length > 64) return 'La clave es demasiado larga (máx. 64 caracteres).';
  if (/^(\d)\1+$/.test(secret) || secret === '1234' || secret === '0000' || secret === '123456') {
    return 'Esa clave es demasiado fácil de adivinar. Elige otra.';
  }
  return null;
}

export async function hasSecret() {
  const a = await getMeta('auth');
  return !!(a && a.hash);
}

export async function setSecret(secret) {
  const err = validateSecret(secret);
  if (err) throw new Error(err);
  const salt = randomBytes(16);
  const hash = await derive(secret, salt, AUTH_ITERATIONS);
  await setMeta('auth', { salt: toB64(salt), hash, iter: AUTH_ITERATIONS, fallos: 0, bloqueadoHasta: 0, creadoEn: new Date().toISOString() });
}

/** @returns {Promise<{ok:boolean, esperaSegundos?:number, intentosRestantes?:number}>} */
export async function verifySecret(secret, ahora = Date.now()) {
  const a = await getMeta('auth');
  if (!a || !a.hash) return { ok: true };
  if (a.bloqueadoHasta && a.bloqueadoHasta > ahora) {
    return { ok: false, esperaSegundos: Math.ceil((a.bloqueadoHasta - ahora) / 1000) };
  }
  const h = await derive(String(secret), fromB64(a.salt), a.iter);
  if (safeEqual(h, a.hash)) {
    if (a.fallos) await setMeta('auth', { ...a, fallos: 0, bloqueadoHasta: 0 });
    return { ok: true };
  }
  const fallos = (a.fallos || 0) + 1;
  let bloqueadoHasta = 0;
  let esperaSegundos = 0;
  if (fallos >= MAX_FREE_ATTEMPTS) {
    esperaSegundos = Math.min(30 * 2 ** (fallos - MAX_FREE_ATTEMPTS), 3600);
    bloqueadoHasta = ahora + esperaSegundos * 1000;
  }
  await setMeta('auth', { ...a, fallos, bloqueadoHasta });
  return { ok: false, esperaSegundos: esperaSegundos || undefined, intentosRestantes: Math.max(0, MAX_FREE_ATTEMPTS - fallos) };
}

export async function removeSecret(current) {
  const v = await verifySecret(current);
  if (!v.ok) throw new Error(v.esperaSegundos ? `Espera ${v.esperaSegundos} s antes de reintentar.` : 'La clave actual no es correcta.');
  await setMeta('auth', null);
}

export async function changeSecret(current, next) {
  const v = await verifySecret(current);
  if (!v.ok) throw new Error(v.esperaSegundos ? `Espera ${v.esperaSegundos} s antes de reintentar.` : 'La clave actual no es correcta.');
  await setSecret(next);
}
