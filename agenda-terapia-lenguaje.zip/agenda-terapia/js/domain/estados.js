// Estados de las citas y textos asociados.

export const ESTADOS = {
  programada: { label: 'Programada', cls: 'st-programada' },
  confirmada: { label: 'Confirmada', cls: 'st-confirmada' },
  realizada: { label: 'Realizada', cls: 'st-realizada' },
  cancelada_representante: { label: 'Cancelada por representante', cls: 'st-cancelada' },
  cancelada_terapeuta: { label: 'Cancelada por terapeuta', cls: 'st-cancelada' },
  inasistencia: { label: 'Inasistencia', cls: 'st-inasistencia' },
  reprogramada: { label: 'Reprogramada', cls: 'st-reprogramada' },
};

export const ESTADO_KEYS = Object.keys(ESTADOS);

/** Estados en los que la cita todavía no tiene resultado. */
export const ABIERTOS = ['programada', 'confirmada'];

/** Estados que NO ocupan el horario (no generan conflicto). */
export const LIBERAN_HORARIO = ['cancelada_representante', 'cancelada_terapeuta', 'reprogramada'];

/** Estados que no se pueden asignar a una cita que todavía no ocurrió. */
export const SOLO_PASADO = ['realizada', 'inasistencia'];

export const WA_ESTADOS = {
  pendiente: 'Pendiente de confirmar',
  confirmado: 'Confirmado',
  contactado: 'Contacto realizado',
};

export const MODALIDADES = {
  sesion: 'Pago por sesión',
  periodo: 'Pago por período (semanal o mensual)',
  paquete: 'Paquete prepagado',
};

export const estadoLabel = (e) => ESTADOS[e]?.label || e;
