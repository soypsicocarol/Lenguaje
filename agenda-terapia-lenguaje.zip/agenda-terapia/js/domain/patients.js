// Pacientes: validación, guardado, inactivación y eliminación definitiva.
import { getDB } from '../core/store.js';
import { newId } from '../core/ids.js';
import { mergeSettings } from '../core/defaults.js';
import { ValidationError } from '../core/errors.js';
import { addDays, isValidDate, today as todayFn } from '../core/dates.js';
import { MODALIDADES } from './estados.js';
import { normalizePhone } from './whatsapp.js';
import { ABIERTOS } from './estados.js';

const ALL = ['patients', 'appointments', 'series', 'blocks', 'plans', 'packages', 'movements', 'payments', 'settings'];

export const fullName = (p) => `${p.nombre} ${p.apellidos || ''}`.trim();

export function validatePatient(p, settings, hoy = todayFn()) {
  const e = [];
  if (!(p.nombre || '').trim()) e.push('Escribe el nombre del niño o niña.');
  if (!(p.apellidos || '').trim()) e.push('Escribe los apellidos del niño o niña.');
  if ((p.nombre || '').length > 80 || (p.apellidos || '').length > 80) e.push('El nombre o los apellidos son demasiado largos.');
  if (!isValidDate(p.fechaNacimiento)) e.push('La fecha de nacimiento no es válida.');
  else if (p.fechaNacimiento > hoy) e.push('La fecha de nacimiento no puede ser futura.');
  if (!(p.representante || '').trim()) e.push('Escribe el nombre del representante responsable.');
  if ((p.telefono || '').trim()) {
    const r = normalizePhone(p.telefono, settings?.codigoPais);
    if (!r.ok) e.push(r.error);
  }
  if (!isValidDate(p.fechaIngreso)) e.push('La fecha de ingreso no es válida.');
  if (!MODALIDADES[p.modalidadCobro]) e.push('Elige una modalidad de cobro.');
  if (p.tarifa !== null && p.tarifa !== undefined && p.tarifa !== '' && !(Number(p.tarifa) >= 0)) e.push('La tarifa no es válida.');
  if (!(p.moneda || '').trim()) e.push('Elige la moneda.');
  if ((p.notasAdministrativas || '').length > 500) e.push('Las observaciones administrativas son demasiado largas (máx. 500 caracteres).');
  return e;
}

export async function findDuplicate(input) {
  const all = await getDB().all('patients');
  const norm = (s) => (s || '').trim().toLowerCase();
  return (
    all.find(
      (p) =>
        p.id !== input.id &&
        norm(p.nombre) === norm(input.nombre) &&
        norm(p.apellidos) === norm(input.apellidos) &&
        p.fechaNacimiento === input.fechaNacimiento,
    ) || null
  );
}

export async function savePatient(input) {
  const db = getDB();
  const settings = mergeSettings(await db.get('settings', 'main'));
  const errors = validatePatient(input, settings);
  if (errors.length) throw new ValidationError(errors);
  const now = new Date().toISOString();
  const prev = input.id ? await db.get('patients', input.id) : null;
  const patient = {
    id: prev?.id || newId('pac'),
    nombre: input.nombre.trim(),
    apellidos: input.apellidos.trim(),
    fechaNacimiento: input.fechaNacimiento, // la edad se calcula siempre; nunca se guarda
    representante: input.representante.trim(),
    telefono: (input.telefono || '').trim(),
    fechaIngreso: input.fechaIngreso,
    estado: prev?.estado || input.estado || 'activo',
    frecuencia: (input.frecuencia || '').trim(),
    notasAdministrativas: (input.notasAdministrativas || '').trim(),
    modalidadCobro: input.modalidadCobro,
    periodoTipo: input.modalidadCobro === 'periodo' ? input.periodoTipo || 'mensual' : null,
    tarifa: input.tarifa === '' || input.tarifa === null || input.tarifa === undefined ? null : Number(input.tarifa),
    moneda: input.moneda.trim().toUpperCase(),
    demo: prev?.demo || input.demo || false,
    createdAt: prev?.createdAt || now,
    updatedAt: now,
  };
  await db.put('patients', patient);
  return patient;
}

/**
 * Activa o inactiva. Al inactivar se puede quitar de la agenda las citas futuras abiertas
 * y detener sus series (el historial de citas y pagos siempre se conserva).
 */
export async function setPatientActive(id, active, { quitarCitasFuturas = false } = {}) {
  return getDB().tx(ALL, 'readwrite', async (t) => {
    const p = await t.get('patients', id);
    if (!p) throw new ValidationError('El paciente ya no existe.');
    const now = new Date().toISOString();
    await t.put('patients', { ...p, estado: active ? 'activo' : 'inactivo', updatedAt: now });
    let eliminadas = 0;
    if (!active && quitarCitasFuturas) {
      const hoy = todayFn();
      const citas = await t.byIndex('appointments', 'patientId', id);
      for (const a of citas) {
        if (a.fecha >= hoy && ABIERTOS.includes(a.estado) && !a.reprogramadaDe) {
          await t.del('appointments', a.id);
          eliminadas++;
        }
      }
      for (const s of await t.byIndex('series', 'patientId', id)) {
        await t.put('series', { ...s, fechaFin: s.fechaFin && s.fechaFin < addDays(hoy, -1) ? s.fechaFin : addDays(hoy, -1), repeticiones: null, estado: 'finalizada', updatedAt: now });
      }
    }
    return { eliminadas };
  });
}

export async function patientUsage(id) {
  return getDB().tx(ALL, 'readonly', async (t) => ({
    citas: (await t.byIndex('appointments', 'patientId', id)).length,
    series: (await t.byIndex('series', 'patientId', id)).length,
    pagos: (await t.byIndex('payments', 'patientId', id)).length,
    obligaciones: (await t.byIndex('plans', 'patientId', id)).length,
    paquetes: (await t.byIndex('packages', 'patientId', id)).length,
  }));
}

/**
 * Eliminación DEFINITIVA con todo su historial (citas, pagos, paquetes). La interfaz debe
 * pedir confirmación explícita y explicar las consecuencias antes de llamar a esta función.
 */
export async function deletePatientPermanently(id) {
  return getDB().tx(ALL, 'readwrite', async (t) => {
    const counts = { citas: 0, series: 0, pagos: 0, obligaciones: 0, paquetes: 0, movimientos: 0 };
    for (const a of await t.byIndex('appointments', 'patientId', id)) {
      await t.del('appointments', a.id);
      counts.citas++;
    }
    for (const s of await t.byIndex('series', 'patientId', id)) {
      await t.del('series', s.id);
      counts.series++;
    }
    for (const p of await t.byIndex('payments', 'patientId', id)) {
      await t.del('payments', p.id);
      counts.pagos++;
    }
    for (const o of await t.byIndex('plans', 'patientId', id)) {
      await t.del('plans', o.id);
      counts.obligaciones++;
    }
    for (const pk of await t.byIndex('packages', 'patientId', id)) {
      for (const m of await t.byIndex('movements', 'packageId', pk.id)) {
        await t.del('movements', m.id);
        counts.movimientos++;
      }
      await t.del('packages', pk.id);
      counts.paquetes++;
    }
    await t.del('patients', id);
    return counts;
  });
}
