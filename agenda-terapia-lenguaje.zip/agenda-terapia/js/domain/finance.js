// Cálculos financieros (funciones puras).
//
// REGLA DE SEGURIDAD FINANCIERA: el ingreso efectivo se basa EXCLUSIVAMENTE en pagos
// registrados (y no anulados). Programar o realizar una cita nunca genera un ingreso.
// Una obligación (lo que se debe) y un pago (lo que se cobró) son cosas distintas.
//
// Nunca se suman monedas distintas: todo se agrupa por moneda.

import { addDays, startOfWeek } from '../core/dates.js';
import { toCents, fromCents } from '../core/money.js';

const vigente = (p) => p.estado !== 'anulado';

/** Resumen de una obligación frente a los pagos vigentes que tiene asociados. */
export function obligationSummary(ob, payments) {
  const pagadoC = payments.filter((p) => vigente(p) && p.obligacionId === ob.id).reduce((a, p) => a + toCents(p.importe), 0);
  const importeC = toCents(ob.importe);
  if (ob.estado === 'anulada') {
    return { importe: fromCents(importeC), pagado: fromCents(pagadoC), pendiente: 0, aFavor: fromCents(pagadoC), estado: 'anulada' };
  }
  const pendienteC = Math.max(0, importeC - pagadoC);
  const aFavorC = Math.max(0, pagadoC - importeC);
  let estado = 'pendiente';
  if (importeC === 0 || pagadoC >= importeC) estado = 'saldada';
  else if (pagadoC > 0) estado = 'parcial';
  return { importe: fromCents(importeC), pagado: fromCents(pagadoC), pendiente: fromCents(pendienteC), aFavor: fromCents(aFavorC), estado };
}

/**
 * Saldos agrupados por moneda: pendiente, a favor y total cobrado.
 * "A favor" = pagos sin obligación válida + excedentes sobre obligaciones.
 */
export function balancesByCurrency(obligations, payments) {
  const res = {};
  const slot = (cur) => (res[cur] ||= { pendiente: 0, aFavor: 0, cobrado: 0, obligaciones: 0 });
  const obById = new Map(obligations.map((o) => [o.id, o]));
  const acc = {};
  const add = (cur, key, c) => {
    acc[cur] ||= { pendiente: 0, aFavor: 0, cobrado: 0, obligaciones: 0 };
    acc[cur][key] += c;
  };
  for (const ob of obligations) {
    const s = obligationSummary(ob, payments);
    if (ob.estado !== 'anulada') {
      add(ob.moneda, 'pendiente', toCents(s.pendiente));
      add(ob.moneda, 'aFavor', toCents(s.aFavor));
      add(ob.moneda, 'obligaciones', toCents(s.importe));
    }
  }
  for (const p of payments.filter(vigente)) {
    add(p.moneda, 'cobrado', toCents(p.importe));
    const ob = p.obligacionId ? obById.get(p.obligacionId) : null;
    if (!ob || ob.estado === 'anulada') add(p.moneda, 'aFavor', toCents(p.importe));
  }
  for (const [cur, v] of Object.entries(acc)) {
    const r = slot(cur);
    for (const k of Object.keys(v)) r[k] = fromCents(v[k]);
  }
  return res;
}

/** Ingresos efectivamente recibidos en [from, to], por moneda y por día / semana / mes. */
export function incomeReport(payments, from, to) {
  const out = {};
  for (const p of payments) {
    if (!vigente(p) || p.fecha < from || p.fecha > to) continue;
    const r = (out[p.moneda] ||= { totalC: 0, count: 0, dia: {}, semana: {}, mes: {} });
    const c = toCents(p.importe);
    r.totalC += c;
    r.count += 1;
    r.dia[p.fecha] = (r.dia[p.fecha] || 0) + c;
    const w = startOfWeek(p.fecha);
    r.semana[w] = (r.semana[w] || 0) + c;
    const m = p.fecha.slice(0, 7);
    r.mes[m] = (r.mes[m] || 0) + c;
  }
  const conv = (o) => Object.fromEntries(Object.entries(o).sort(([a], [b]) => (a < b ? -1 : 1)).map(([k, v]) => [k, fromCents(v)]));
  return Object.fromEntries(
    Object.entries(out).map(([cur, r]) => [cur, { total: fromCents(r.totalC), count: r.count, dia: conv(r.dia), semana: conv(r.semana), mes: conv(r.mes) }]),
  );
}

/**
 * Importe ESTIMADO de servicios programados (no cobrados): solo citas abiertas de
 * pacientes con cobro por sesión. Se muestra siempre separado de lo cobrado.
 */
export function estimatedScheduled(appointments, patients, settings, from, to) {
  const byId = new Map(patients.map((p) => [p.id, p]));
  const acc = {};
  for (const a of appointments) {
    if (a.fecha < from || a.fecha > to) continue;
    if (a.estado !== 'programada' && a.estado !== 'confirmada') continue;
    const p = byId.get(a.patientId);
    if (!p || (p.modalidadCobro || 'sesion') !== 'sesion') continue;
    const tarifa = a.tarifa ?? p.tarifa ?? settings.tarifaDefault ?? 0;
    if (!(tarifa > 0)) continue;
    const cur = p.moneda || settings.moneda;
    acc[cur] = (acc[cur] || 0) + toCents(tarifa);
  }
  return Object.fromEntries(Object.entries(acc).map(([k, v]) => [k, fromCents(v)]));
}

/** Pagos que no están asociados a ninguna obligación válida. */
export function unassignedPayments(obligations, payments) {
  const ok = new Set(obligations.filter((o) => o.estado !== 'anulada').map((o) => o.id));
  return payments.filter((p) => vigente(p) && (!p.obligacionId || !ok.has(p.obligacionId)));
}

export { addDays };
