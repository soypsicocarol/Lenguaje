// WhatsApp MANUAL: solo se construye un enlace con el texto prellenado. La persona
// usuaria revisa y envía el mensaje. La aplicación nunca envía nada ni sabe si se envió
// o se leyó. No se guarda el contenido de los mensajes.

import { fmtDateLong, fmtTime } from '../core/dates.js';

/**
 * Normaliza un teléfono a solo dígitos con código de país (formato que usa wa.me).
 * - "+58 414-1234567" -> 584141234567
 * - "0414 1234567" con código de país por defecto 58 -> 584141234567
 * - "00" inicial se interpreta como prefijo internacional.
 * Devuelve { ok, digits, error }.
 */
export function normalizePhone(raw, defaultCountry = '') {
  const original = String(raw ?? '').trim();
  if (!original) return { ok: false, digits: '', error: 'Falta el teléfono.' };
  if (/[^0-9+\s().-]/.test(original)) return { ok: false, digits: '', error: 'El teléfono solo puede tener números, espacios, guiones y "+".' };
  const hasPlus = original.startsWith('+');
  let digits = original.replace(/\D/g, '');
  const cc = String(defaultCountry || '').replace(/\D/g, '');
  if (hasPlus) {
    // ya es internacional
  } else if (digits.startsWith('00')) {
    digits = digits.slice(2);
  } else if (cc) {
    if (digits.startsWith('0')) digits = cc + digits.replace(/^0+/, '');
    else if (digits.length <= 10 && !digits.startsWith(cc)) digits = cc + digits;
  }
  if (digits.length < 8 || digits.length > 15) {
    return { ok: false, digits: '', error: 'El teléfono debe tener entre 8 y 15 dígitos e incluir el código de país (ej. +58 414 1234567).' };
  }
  return { ok: true, digits, error: '' };
}

export function buildWhatsAppLink(digits, text = '') {
  const base = `https://wa.me/${digits}`;
  return text ? `${base}?text=${encodeURIComponent(text)}` : base;
}

/** Reemplaza {variables}. Las que no tienen dato quedan como [variable] para completarlas a mano. */
export function fillTemplate(template, vars) {
  return String(template).replace(/\{(\w+)\}/g, (_, k) => {
    const v = vars[k];
    return v === undefined || v === null || v === '' ? `[${k}]` : String(v);
  });
}

export function templateVars({ patient, appointment, settings, saldo }) {
  return {
    nino: patient ? patient.nombre : '',
    representante: patient?.representante || '',
    consultorio: settings?.consultorio?.nombre || '',
    fecha: appointment ? fmtDateLong(appointment.fecha) : '',
    hora: appointment ? fmtTime(appointment.inicio) : '',
    saldo: saldo || '',
  };
}
