// Tableros y reportes. Funciones puras sobre los datos cargados (loadAll()).
// Siempre indican período y moneda; nunca suman monedas distintas.

import { addDays, startOfMonth, endOfMonth, startOfWeek, today as todayFn } from '../core/dates.js';
import { balancesByCurrency, estimatedScheduled, incomeReport, obligationSummary, unassignedPayments } from './finance.js';
import { packageSummary } from './packages.js';
import { occupies } from './conflicts.js';
import { ESTADO_KEYS } from './estados.js';
import { fullName } from './patients.js';

const byTime = (a, b) => (a.fecha + a.inicio < b.fecha + b.inicio ? -1 : a.fecha + a.inicio > b.fecha + b.inicio ? 1 : 0);

export function buildDashboard(data, hoy = todayFn()) {
  const { appointments, payments, plans, packages, movements, patients, settings } = data;
  const pById = new Map(patients.map((p) => [p.id, p]));
  const activos = new Set(patients.filter((p) => p.estado === 'activo').map((p) => p.id));
  const visible = appointments.filter((a) => a.estado !== 'reprogramada');

  const hoyCitas = visible.filter((a) => a.fecha === hoy).sort(byTime);
  const proximas = visible.filter((a) => a.fecha > hoy && a.fecha <= addDays(hoy, 7) && occupies(a)).sort(byTime);
  const porConfirmar = visible
    .filter((a) => a.fecha >= hoy && a.fecha <= addDays(hoy, 7) && a.estado === 'programada' && a.whatsappEstado !== 'confirmado')
    .sort(byTime);
  const recientes = appointments
    .filter((a) => a.fecha <= hoy && a.fecha >= addDays(hoy, -14) && ['cancelada_representante', 'cancelada_terapeuta', 'inasistencia'].includes(a.estado))
    .sort((a, b) => byTime(b, a));
  const porReprogramar = appointments.filter((a) => a.estado === 'cancelada_terapeuta' && a.paraReprogramar).sort(byTime);
  const sinResultado = visible.filter((a) => a.fecha < hoy && (a.estado === 'programada' || a.estado === 'confirmada')).sort((a, b) => byTime(b, a));

  const mesDesde = startOfMonth(hoy);
  const mesHasta = endOfMonth(hoy);
  const semanaDesde = startOfWeek(hoy);
  const semanaHasta = addDays(semanaDesde, 6);

  const obls = plans.map((o) => ({ o, s: obligationSummary(o, payments) }));
  const parciales = obls.filter((x) => x.s.estado === 'parcial').map((x) => ({ ...x.s, obligacion: x.o, paciente: pById.get(x.o.patientId) }));

  const paquetes = packages
    .map((p) => ({ pkg: p, s: packageSummary(p, movements, hoy), paciente: pById.get(p.patientId) }))
    .filter((x) => x.s.estado === 'activo');

  return {
    hoy: hoyCitas,
    proximas,
    porConfirmar,
    recientes,
    porReprogramar,
    sinResultado,
    sesionesMes: appointments.filter((a) => a.estado === 'realizada' && a.fecha >= mesDesde && a.fecha <= mesHasta).length,
    ingresos: {
      dia: incomeReport(payments, hoy, hoy),
      semana: incomeReport(payments, semanaDesde, semanaHasta),
      mes: incomeReport(payments, mesDesde, mesHasta),
    },
    saldos: balancesByCurrency(plans, payments),
    parciales,
    paquetes,
    pacientesActivos: activos.size,
    settings,
  };
}

/** Reporte por rango de fechas y (opcionalmente) paciente. */
export function buildReport(data, { from, to, patientId = '' }, hoy = todayFn()) {
  const patients = data.patients;
  const pById = new Map(patients.map((p) => [p.id, p]));
  const okPat = (id) => !patientId || id === patientId;
  const appointments = data.appointments.filter((a) => okPat(a.patientId));
  const payments = data.payments.filter((p) => okPat(p.patientId));
  const plans = data.plans.filter((o) => okPat(o.patientId));
  const packages = data.packages.filter((p) => okPat(p.patientId));

  const enRango = appointments.filter((a) => a.fecha >= from && a.fecha <= to);
  const sesiones = Object.fromEntries(ESTADO_KEYS.map((k) => [k, enRango.filter((a) => a.estado === k).length]));

  const pendientes = plans
    .map((o) => ({ obligacion: o, paciente: pById.get(o.patientId), ...obligationSummary(o, payments) }))
    .filter((x) => x.estado === 'pendiente' || x.estado === 'parcial')
    .sort((a, b) => (a.obligacion.fechaInicio || '') < (b.obligacion.fechaInicio || '') ? -1 : 1);

  return {
    from,
    to,
    sesiones,
    ingresos: incomeReport(payments, from, to),
    saldos: balancesByCurrency(plans, payments),
    pendientes,
    parciales: pendientes.filter((x) => x.estado === 'parcial'),
    sinAsignar: unassignedPayments(plans, payments),
    estimado: estimatedScheduled(appointments, patients, data.settings, from < hoy ? hoy : from, to),
    paquetes: packages
      .map((p) => ({ pkg: p, paciente: pById.get(p.patientId), ...packageSummary(p, data.movements, hoy) }))
      .filter((x) => x.estado === 'activo' || x.estado === 'vencido'),
  };
}

// ------------------------------------------------------------ filas para exportar (CSV)

export function paymentRows(data, { from, to, patientId = '' }) {
  const pById = new Map(data.patients.map((p) => [p.id, p]));
  const obById = new Map(data.plans.map((o) => [o.id, o]));
  return data.payments
    .filter((p) => p.fecha >= from && p.fecha <= to && (!patientId || p.patientId === patientId))
    .sort((a, b) => (a.fecha < b.fecha ? -1 : 1))
    .map((p) => [
      p.fecha,
      pById.get(p.patientId) ? fullName(pById.get(p.patientId)) : '(paciente eliminado)',
      p.importe,
      p.moneda,
      p.metodo,
      p.concepto,
      obById.get(p.obligacionId)?.concepto || '',
      p.estado === 'anulado' ? 'ANULADO' : 'Vigente',
      p.estado === 'anulado' ? p.motivoAnulacion || '' : p.nota || '',
    ]);
}
export const PAYMENT_HEADERS = ['Fecha', 'Paciente', 'Importe', 'Moneda', 'Método', 'Concepto', 'Obligación', 'Estado', 'Nota / motivo'];

export function balanceRows(data, { patientId = '' } = {}) {
  const pById = new Map(data.patients.map((p) => [p.id, p]));
  return data.plans
    .filter((o) => !patientId || o.patientId === patientId)
    .map((o) => ({ o, s: obligationSummary(o, data.payments) }))
    .filter(({ s }) => s.estado === 'pendiente' || s.estado === 'parcial')
    .map(({ o, s }) => [
      pById.get(o.patientId) ? fullName(pById.get(o.patientId)) : '(paciente eliminado)',
      o.concepto,
      o.fechaInicio || '',
      s.importe,
      s.pagado,
      s.pendiente,
      o.moneda,
      s.estado === 'parcial' ? 'Pago parcial' : 'Pendiente',
    ]);
}
export const BALANCE_HEADERS = ['Paciente', 'Concepto', 'Fecha', 'Importe', 'Pagado', 'Pendiente', 'Moneda', 'Estado'];

export function appointmentRows(data, { from, to, patientId = '' }) {
  const pById = new Map(data.patients.map((p) => [p.id, p]));
  return data.appointments
    .filter((a) => a.fecha >= from && a.fecha <= to && (!patientId || a.patientId === patientId))
    .sort(byTime)
    .map((a) => [a.fecha, a.inicio, a.duracion, pById.get(a.patientId) ? fullName(pById.get(a.patientId)) : '(paciente eliminado)', a.estado, a.motivoCancelacion || '']);
}
export const APPOINTMENT_HEADERS = ['Fecha', 'Hora', 'Duración (min)', 'Paciente', 'Estado', 'Motivo'];
