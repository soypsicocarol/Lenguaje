// Servicios de la aplicación: validan, calculan y escriben en la base local de forma atómica.
// Todas las operaciones de escritura se serializan (un candado) para evitar condiciones de carrera.
import { DEFAULT_SETTINGS, ESTADOS, ESTADOS_MODIFICABLES } from './core/constants.js';
import { addDays, dayOfWeek, diffDays, isValidDate, isValidTime, toMin, today as fechaHoy } from './core/dates.js';
import { ConflictError, ValidationError, clone, isStr, mergeDeep, r2, uid } from './core/util.js';
import { detectarProblemas, generarFechasSerie, hayConflicto, validarSerie } from './core/schedule.js';
import { estadoPaquete, planificarPaquete, saldoPaquete } from './core/finance.js';
import { normalizarTelefono } from './core/whatsapp.js';
import { hashSecreto, verificarSecreto } from './core/crypto.js';
import { STORES_DATOS, construirRespaldo, planificarImportacion, validarRespaldo } from './core/backup.js';

const MODALIDADES = ['sesion', 'periodo', 'paquete'];

export function crearServicios(db, { ahora = () => new Date(), nuevoId = uid } = {}) {
  let cadena = Promise.resolve();
  const bloquear = (fn) => {
    const p = cadena.then(() => fn());
    cadena = p.catch(() => {});
    return p;
  };
  const iso = () => ahora().toISOString();
  const hoy = () => fechaHoy(ahora());

  async function cargar() {
    const [patients, appointments, series, blocks, payments, plans, packages, movements, ajustes] = await Promise.all(
      [...STORES_DATOS, 'settings'].map((s) => db.getAll(s)),
    );
    const main = ajustes.find((r) => r.id === 'main') || {};
    const { id, ...resto } = main;
    return { patients, appointments, series, blocks, payments, plans, packages, movements, settings: mergeDeep(clone(DEFAULT_SETTINGS), resto) };
  }

  /** Ejecuta un planificador dentro del candado: lee, calcula operaciones, escribe una sola transacción. */
  const tx = (fn) =>
    bloquear(async () => {
      const d = await cargar();
      const r = (await fn(d)) || {};
      if (r.ops && r.ops.length) await db.batch(r.ops);
      return r.resultado;
    });
  const put = (store, rec) => ({ op: 'put', store, rec });
  const del = (store, id) => ({ op: 'delete', store, id });

  const buscar = (lista, id, msg) => {
    const x = lista.find((r) => r.id === id);
    if (!x) throw new ValidationError(msg);
    return x;
  };

  // ------------------------------------------------------------ Ajustes
  function validarAjustes(s) {
    if (!Array.isArray(s.monedas) || !s.monedas.length || !s.monedas.every((m) => /^[A-Z]{3}$/.test(m)))
      throw new ValidationError('Las monedas deben ser códigos de 3 letras mayúsculas (por ejemplo USD).');
    if (!s.monedas.includes(s.moneda)) throw new ValidationError('La moneda predeterminada debe estar entre las monedas habilitadas.');
    if (!(Number.isInteger(s.duracionPredeterminada) && s.duracionPredeterminada >= 5 && s.duracionPredeterminada <= 480))
      throw new ValidationError('La duración habitual debe estar entre 5 y 480 minutos.');
    if (!Array.isArray(s.duracionesAdicionales) || !s.duracionesAdicionales.every((n) => Number.isInteger(n) && n >= 5 && n <= 480))
      throw new ValidationError('Las duraciones adicionales deben ser minutos entre 5 y 480.');
    for (let i = 0; i < 7; i++) {
      const h = s.horario[i];
      if (!h || !isValidTime(h.desde) || !isValidTime(h.hasta)) throw new ValidationError('Revisa las horas del horario de atención.');
      if (h.activo && toMin(h.desde) >= toMin(h.hasta)) throw new ValidationError('En el horario de atención, la hora final debe ser posterior a la inicial.');
    }
    if (!Array.isArray(s.metodosPago) || !s.metodosPago.length) throw new ValidationError('Define al menos un método de pago.');
    if (!(s.tarifaPredeterminada >= 0)) throw new ValidationError('La tarifa predeterminada no puede ser negativa.');
    if (!(Number.isInteger(s.autobloqueoMin) && s.autobloqueoMin >= 0 && s.autobloqueoMin <= 240))
      throw new ValidationError('El bloqueo automático debe estar entre 0 y 240 minutos (0 = desactivado).');
    if (s.codigoPais && !/^\d{1,4}$/.test(String(s.codigoPais))) throw new ValidationError('El código de país debe tener solo números (por ejemplo 58).');
    for (const k of ['confirmacion', 'recordatorio', 'cambio', 'cancelacion', 'saldo'])
      if (!isStr(s.plantillas?.[k])) throw new ValidationError('Las plantillas de WhatsApp no pueden estar vacías.');
  }

  const guardarAjustes = (parcial) =>
    tx((d) => {
      const nuevo = mergeDeep(d.settings, parcial);
      if (parcial.monedas) nuevo.monedas = parcial.monedas;
      if (parcial.metodosPago) nuevo.metodosPago = parcial.metodosPago;
      if (parcial.duracionesAdicionales) nuevo.duracionesAdicionales = parcial.duracionesAdicionales;
      validarAjustes(nuevo);
      return { ops: [put('settings', { id: 'main', ...nuevo })], resultado: nuevo };
    });

  // ------------------------------------------------------------ Seguridad (PIN local)
  const leerSeguridad = async () => {
    const r = await db.get('settings', 'seguridad');
    return r && r.activo ? r : null;
  };
  const definirPin = (pin) =>
    bloquear(async () => {
      if (typeof pin !== 'string' || pin.length < 4) throw new ValidationError('El PIN o contraseña debe tener al menos 4 caracteres.');
      const h = await hashSecreto(pin);
      await db.batch([put('settings', { id: 'seguridad', activo: true, ...h, creadoEn: iso() })]);
    });
  const quitarPin = (pin) =>
    bloquear(async () => {
      const s = await leerSeguridad();
      if (s && !(await verificarSecreto(pin, s))) throw new ValidationError('PIN o contraseña incorrectos.');
      await db.batch([del('settings', 'seguridad')]);
    });
  const verificarPin = async (pin) => {
    const s = await leerSeguridad();
    return !s || (await verificarSecreto(pin, s));
  };

  // ------------------------------------------------------------ Pacientes
  function normalizarPaciente(i, settings, previo = null) {
    if (!isStr(i.nombre)) throw new ValidationError('Escribe el nombre del niño o niña.', 'nombre');
    if (!isStr(i.representante)) throw new ValidationError('Escribe el nombre del representante responsable.', 'representante');
    if (i.fechaNacimiento) {
      if (!isValidDate(i.fechaNacimiento)) throw new ValidationError('La fecha de nacimiento no es válida.', 'fechaNacimiento');
      if (i.fechaNacimiento > hoy()) throw new ValidationError('La fecha de nacimiento no puede ser futura.', 'fechaNacimiento');
    }
    const fechaIngreso = i.fechaIngreso || hoy();
    if (!isValidDate(fechaIngreso)) throw new ValidationError('La fecha de ingreso no es válida.', 'fechaIngreso');
    let telefono = '';
    if (isStr(i.telefono)) {
      const n = normalizarTelefono(i.telefono, settings.codigoPais);
      if (!n.ok) throw new ValidationError(n.error, 'telefono');
      telefono = n.e164;
    }
    const modalidadCobro = i.modalidadCobro || 'sesion';
    if (!MODALIDADES.includes(modalidadCobro)) throw new ValidationError('Modalidad de cobro no válida.', 'modalidadCobro');
    const tarifa = i.tarifa === '' || i.tarifa == null ? settings.tarifaPredeterminada || 0 : Number(i.tarifa);
    if (!(tarifa >= 0)) throw new ValidationError('La tarifa debe ser un número igual o mayor que 0.', 'tarifa');
    const moneda = i.moneda || settings.moneda;
    if (!settings.monedas.includes(moneda)) throw new ValidationError('Moneda no habilitada en Configuración.', 'moneda');
    return {
      ...(previo || {}),
      nombre: i.nombre.trim(),
      apellidos: (i.apellidos || '').trim(),
      fechaNacimiento: i.fechaNacimiento || '',
      representante: i.representante.trim(),
      telefono,
      fechaIngreso,
      frecuencia: (i.frecuencia || '').trim(),
      notasAdministrativas: (i.notasAdministrativas || '').trim(),
      modalidadCobro,
      tarifa: r2(tarifa),
      moneda,
    };
  }

  const crearPaciente = (input) =>
    tx((d) => {
      const base = normalizarPaciente(input, d.settings);
      const p = { id: nuevoId(), estado: 'activo', demo: !!input.demo, ...base, createdAt: iso(), updatedAt: iso() };
      return { ops: [put('patients', p)], resultado: p };
    });

  const actualizarPaciente = (id, input) =>
    tx((d) => {
      const prev = buscar(d.patients, id, 'El paciente no existe.');
      const p = { ...normalizarPaciente(input, d.settings, prev), updatedAt: iso() };
      return { ops: [put('patients', p)], resultado: p };
    });

  const cambiarEstadoPaciente = (id, activo) =>
    tx((d) => {
      const prev = buscar(d.patients, id, 'El paciente no existe.');
      const p = { ...prev, estado: activo ? 'activo' : 'inactivo', updatedAt: iso() };
      return { ops: [put('patients', p)], resultado: p };
    });

  function huellaPaciente(d, id) {
    const pk = d.packages.filter((k) => k.patientId === id).map((k) => k.id);
    return {
      citas: d.appointments.filter((a) => a.patientId === id).length,
      series: d.series.filter((s) => s.patientId === id).length,
      pagos: d.payments.filter((p) => p.patientId === id).length,
      cobros: d.plans.filter((p) => p.patientId === id).length,
      paquetes: pk.length,
      movimientos: d.movements.filter((m) => pk.includes(m.packageId)).length,
    };
  }

  const eliminarPaciente = (id) =>
    tx((d) => {
      buscar(d.patients, id, 'El paciente no existe.');
      const pk = d.packages.filter((k) => k.patientId === id).map((k) => k.id);
      const ops = [
        del('patients', id),
        ...d.appointments.filter((a) => a.patientId === id).map((a) => del('appointments', a.id)),
        ...d.series.filter((s) => s.patientId === id).map((s) => del('series', s.id)),
        ...d.payments.filter((p) => p.patientId === id).map((p) => del('payments', p.id)),
        ...d.plans.filter((p) => p.patientId === id).map((p) => del('plans', p.id)),
        ...d.packages.filter((k) => k.patientId === id).map((k) => del('packages', k.id)),
        ...d.movements.filter((m) => pk.includes(m.packageId)).map((m) => del('movements', m.id)),
      ];
      return { ops, resultado: huellaPaciente(d, id) };
    });

  // ------------------------------------------------------------ Citas
  function validarHorarioCita(c) {
    if (!isValidDate(c.fecha)) throw new ValidationError('La fecha no es válida.', 'fecha');
    if (!isValidTime(c.inicio)) throw new ValidationError('La hora de inicio no es válida.', 'inicio');
    if (!(Number.isInteger(c.duracion) && c.duracion >= 5 && c.duracion <= 480)) throw new ValidationError('La duración debe estar entre 5 y 480 minutos.', 'duracion');
    if (toMin(c.inicio) + c.duracion > 24 * 60) throw new ValidationError('La cita no puede cruzar la medianoche.', 'duracion');
  }

  function crearRegistroCita(p, f, extra = {}) {
    const t = iso();
    return {
      id: nuevoId(),
      patientId: p.id,
      seriesId: null,
      serieClave: null,
      fecha: f.fecha,
      inicio: f.inicio,
      duracion: Number(f.duracion),
      estado: 'programada',
      motivoCancelacion: '',
      nota: (f.nota || '').trim(),
      modalidad: p.modalidadCobro,
      tarifa: f.tarifa === '' || f.tarifa == null ? p.tarifa || 0 : r2(Number(f.tarifa)),
      moneda: f.moneda || p.moneda,
      pendienteReprogramar: false,
      whatsappEstado: 'pendiente',
      reprogramadaDe: null,
      reprogramadaA: null,
      editadaIndividual: false,
      historial: [{ en: t, tipo: 'creada' }],
      createdAt: t,
      updatedAt: t,
      ...extra,
    };
  }

  const crearCita = (input, { permitirConflicto = false } = {}) =>
    tx((d) => {
      const p = buscar(d.patients, input.patientId, 'Selecciona un paciente.');
      if (p.estado === 'inactivo') throw new ValidationError('El paciente está inactivo. Actívalo para agendar nuevas citas.');
      const c = crearRegistroCita(p, { ...input, duracion: Number(input.duracion) });
      if (!(c.tarifa >= 0)) throw new ValidationError('La tarifa no es válida.', 'tarifa');
      validarHorarioCita(c);
      const pr = detectarProblemas(c, d, {}, d.settings);
      if (hayConflicto(pr) && !permitirConflicto) throw new ConflictError(pr);
      return { ops: [put('appointments', c)], resultado: { cita: c, problemas: pr } };
    });

  /** Planifica el cambio de fecha/hora/duración/nota/tarifa de una sola cita. */
  function planCita(d, id, cambios, permitirConflicto) {
    const a = buscar(d.appointments, id, 'La cita no existe.');
    const n = { ...a };
    for (const k of ['fecha', 'inicio', 'nota', 'whatsappEstado']) if (cambios[k] !== undefined) n[k] = cambios[k];
    if (cambios.duracion !== undefined) n.duracion = Number(cambios.duracion);
    if (cambios.tarifa !== undefined) {
      n.tarifa = r2(Number(cambios.tarifa) || 0);
      if (!(n.tarifa >= 0)) throw new ValidationError('La tarifa no es válida.', 'tarifa');
    }
    validarHorarioCita(n);
    const movio = n.fecha !== a.fecha || n.inicio !== a.inicio || n.duracion !== a.duracion;
    let pr = null;
    if (movio) {
      pr = detectarProblemas(n, d, {}, d.settings);
      if (hayConflicto(pr) && !permitirConflicto) throw new ConflictError(pr);
      if (a.seriesId) n.editadaIndividual = true;
    }
    n.updatedAt = iso();
    if (movio) n.historial = [...a.historial, { en: iso(), tipo: 'editada', de: `${a.fecha} ${a.inicio} (${a.duracion} min)`, a: `${n.fecha} ${n.inicio} (${n.duracion} min)` }];
    return { cita: n, problemas: pr };
  }

  const actualizarCita = (id, cambios, { permitirConflicto = false } = {}) =>
    tx((d) => {
      const r = planCita(d, id, cambios, permitirConflicto);
      return { ops: [put('appointments', r.cita)], resultado: r };
    });

  const cambiarEstadoCita = (id, estado, { motivo = '' } = {}) =>
    tx((d) => {
      if (!ESTADOS[estado] || estado === 'reprogramada') throw new ValidationError('Estado no válido. Para reprogramar usa la acción "Reprogramar".');
      const a = buscar(d.appointments, id, 'La cita no existe.');
      if (a.estado === 'reprogramada') throw new ValidationError('Esta cita ya fue reprogramada. Gestiona la nueva cita.');
      if ((estado === 'realizada' || estado === 'inasistencia') && a.fecha > hoy())
        throw new ValidationError('No se puede registrar como realizada o inasistencia una cita de una fecha futura.');
      if (a.estado === estado) return { resultado: { cita: a, aviso: null } };
      const n = {
        ...a,
        estado,
        motivoCancelacion: estado.startsWith('cancelada') ? motivo : '',
        pendienteReprogramar: estado === 'cancelada_terapeuta',
        updatedAt: iso(),
        historial: [...a.historial, { en: iso(), tipo: 'estado', de: a.estado, a: estado, nota: motivo || undefined }],
      };
      const sync = planificarPaquete(n, { packages: d.packages, movements: d.movements, reglas: d.settings.reglasPaquete, nuevoId, ahora: iso() });
      return { ops: [put('appointments', n), ...sync.ops], resultado: { cita: n, aviso: sync.aviso } };
    });

  const reprogramarCita = (id, nueva, { permitirConflicto = false } = {}) =>
    tx((d) => {
      const o = buscar(d.appointments, id, 'La cita no existe.');
      if (!['programada', 'confirmada', 'cancelada_terapeuta', 'cancelada_representante'].includes(o.estado))
        throw new ValidationError('Solo se pueden reprogramar citas programadas, confirmadas o canceladas.');
      const p = buscar(d.patients, o.patientId, 'El paciente no existe.');
      const c = crearRegistroCita(p, { fecha: nueva.fecha, inicio: nueva.inicio, duracion: Number(nueva.duracion ?? o.duracion), nota: nueva.nota ?? o.nota, tarifa: o.tarifa, moneda: o.moneda }, {
        seriesId: o.seriesId,
        reprogramadaDe: o.id,
        modalidad: o.modalidad,
        historial: [{ en: iso(), tipo: 'creada', nota: `Reprogramada desde ${o.fecha} ${o.inicio}` }],
      });
      validarHorarioCita(c);
      const pr = detectarProblemas(c, d, { ignorar: [o.id] }, d.settings);
      if (hayConflicto(pr) && !permitirConflicto) throw new ConflictError(pr);
      const orig = {
        ...o,
        estado: 'reprogramada',
        reprogramadaA: c.id,
        pendienteReprogramar: false,
        updatedAt: iso(),
        historial: [...o.historial, { en: iso(), tipo: 'estado', de: o.estado, a: 'reprogramada', nota: `Nueva fecha ${c.fecha} ${c.inicio}` }],
      };
      const sync = planificarPaquete(orig, { packages: d.packages, movements: d.movements, reglas: d.settings.reglasPaquete, nuevoId, ahora: iso() });
      return { ops: [put('appointments', orig), put('appointments', c), ...sync.ops], resultado: { original: orig, nueva: c } };
    });

  const eliminarCita = (id) =>
    tx((d) => {
      const a = buscar(d.appointments, id, 'La cita no existe.');
      const ops = [del('appointments', id)];
      const sync = planificarPaquete({ ...a, estado: 'programada' }, { packages: d.packages, movements: d.movements, reglas: d.settings.reglasPaquete, nuevoId, ahora: iso() });
      ops.push(...sync.ops);
      if (a.reprogramadaDe) {
        const o = d.appointments.find((x) => x.id === a.reprogramadaDe);
        if (o) ops.push(put('appointments', { ...o, reprogramadaA: null, updatedAt: iso(), historial: [...o.historial, { en: iso(), tipo: 'nota', nota: 'Se eliminó la cita reprogramada' }] }));
      }
      if (a.seriesId && a.serieClave) {
        const s = d.series.find((x) => x.id === a.seriesId);
        if (s && !s.excepciones.includes(a.serieClave)) ops.push(put('series', { ...s, excepciones: [...s.excepciones, a.serieClave], updatedAt: iso() }));
      }
      return { ops, resultado: true };
    });

  // ------------------------------------------------------------ Bloqueos
  function normalizarBloqueo(i) {
    const b = { fechaInicio: i.fechaInicio, horaInicio: i.horaInicio, fechaFin: i.fechaFin || i.fechaInicio, horaFin: i.horaFin, motivo: (i.motivo || '').trim() };
    if (!isValidDate(b.fechaInicio) || !isValidDate(b.fechaFin)) throw new ValidationError('Revisa las fechas del bloqueo.');
    if (!isValidTime(b.horaInicio) || !(isValidTime(b.horaFin) || b.horaFin === '24:00')) throw new ValidationError('Revisa las horas del bloqueo.');
    if (`${b.fechaFin}T${b.horaFin}` <= `${b.fechaInicio}T${b.horaInicio}`) throw new ValidationError('El bloqueo debe terminar después de empezar.');
    if (!b.motivo) throw new ValidationError('Indica un motivo para el bloqueo (descanso, reunión, vacaciones…).');
    return b;
  }
  const crearBloqueo = (input) =>
    tx((d) => {
      const b = { id: nuevoId(), ...normalizarBloqueo(input), createdAt: iso(), updatedAt: iso() };
      const afectadas = d.appointments.filter((a) => ['programada', 'confirmada'].includes(a.estado) && detectarProblemas(a, { appointments: [], blocks: [b] }).bloqueos.length).length;
      return { ops: [put('blocks', b)], resultado: { bloqueo: b, citasAfectadas: afectadas } };
    });
  const actualizarBloqueo = (id, input) =>
    tx((d) => {
      const prev = buscar(d.blocks, id, 'El bloqueo no existe.');
      const b = { ...prev, ...normalizarBloqueo(input), updatedAt: iso() };
      return { ops: [put('blocks', b)], resultado: b };
    });
  const eliminarBloqueo = (id) => tx(() => ({ ops: [del('blocks', id)], resultado: true }));

  // ------------------------------------------------------------ Series
  const finDeSerie = (s) => {
    let l = s.fechaFin || null;
    if (s.semanas) {
      const x = addDays(s.fechaInicio, 7 * s.semanas - 1);
      l = l && l < x ? l : x;
    }
    return l;
  };

  function vistaPreviaSerieDatos(input, d) {
    validarSerie(input);
    buscar(d.patients, input.patientId, 'Selecciona un paciente.');
    const filas = generarFechasSerie({ ...input, excepciones: input.excepciones || [] });
    return filas.map((f) => {
      const c = { id: '__tmp', patientId: input.patientId, fecha: f.fecha, inicio: f.inicio, duracion: Number(input.duracion) };
      const problemas = detectarProblemas(c, d, {}, d.settings);
      const existe = d.appointments.some((a) => a.seriesId === input.id && a.serieClave === f.clave);
      return { ...f, problemas, conflicto: hayConflicto(problemas), existe };
    });
  }
  const vistaPreviaSerie = (input) => bloquear(async () => vistaPreviaSerieDatos({ ...input, duracion: Number(input.duracion) }, await cargar()));

  const crearSerie = (input, { incluir = null, permitirConflicto = false } = {}) =>
    tx((d) => {
      const id = input.id || nuevoId();
      const ya = d.series.find((s) => s.id === id);
      if (ya) return { resultado: { serie: ya, creadas: 0, yaExistia: true } }; // guardar dos veces no duplica
      const inp = { ...input, id, duracion: Number(input.duracion), semanas: input.semanas ? Number(input.semanas) : null, fechaFin: input.fechaFin || null };
      const filas = vistaPreviaSerieDatos(inp, d);
      const sel = filas.filter((r) => !incluir || incluir.includes(r.clave));
      if (!sel.length) throw new ValidationError('No hay citas seleccionadas para crear.');
      const conf = sel.filter((r) => r.conflicto);
      if (conf.length && !permitirConflicto) throw new ConflictError({ porFecha: conf.map((r) => ({ fecha: r.fecha, inicio: r.inicio, ...r.problemas })) });
      const p = buscar(d.patients, inp.patientId, 'Selecciona un paciente.');
      if (p.estado === 'inactivo') throw new ValidationError('El paciente está inactivo.');
      const t = iso();
      const serie = {
        id,
        patientId: inp.patientId,
        dias: inp.dias.map((x) => ({ dia: Number(x.dia), hora: x.hora })),
        duracion: inp.duracion,
        fechaInicio: inp.fechaInicio,
        fechaFin: inp.fechaFin,
        semanas: inp.semanas,
        excepciones: [...(inp.excepciones || []), ...filas.filter((r) => !sel.includes(r)).map((r) => r.clave)],
        estado: 'activa',
        nota: (inp.nota || '').trim(),
        createdAt: t,
        updatedAt: t,
      };
      const citas = sel.map((r) => crearRegistroCita(p, { fecha: r.fecha, inicio: r.inicio, duracion: inp.duracion, nota: inp.notaCitas || '' }, { seriesId: id, serieClave: r.clave }));
      return { ops: [put('series', serie), ...citas.map((c) => put('appointments', c))], resultado: { serie, creadas: citas.length, citas } };
    });

  /** Edita una cita de una serie con alcance 'esta' | 'futuras' | 'toda'. */
  const editarCitaSerie = (id, alcance, cambios, { permitirConflicto = false } = {}) =>
    tx((d) => {
      const a = buscar(d.appointments, id, 'La cita no existe.');
      const serie = a.seriesId ? d.series.find((s) => s.id === a.seriesId) : null;
      const c = { fecha: cambios.fecha ?? a.fecha, inicio: cambios.inicio ?? a.inicio, duracion: Number(cambios.duracion ?? a.duracion), nota: cambios.nota };
      validarHorarioCita({ ...a, ...c });
      if (!serie || alcance === 'esta') {
        const r = planCita(d, id, { fecha: c.fecha, inicio: c.inicio, duracion: c.duracion, ...(c.nota !== undefined ? { nota: c.nota } : {}) }, permitirConflicto);
        return { ops: [put('appointments', r.cita)], resultado: { modificadas: 1 } };
      }
      const dow = dayOfWeek(a.fecha);
      const delta = diffDays(a.fecha, c.fecha);
      const nuevoDow = dayOfWeek(c.fecha);
      const enAlcance = d.appointments.filter(
        (x) => x.seriesId === serie.id && (x.id === a.id || (ESTADOS_MODIFICABLES.includes(x.estado) && !x.editadaIndividual && (alcance === 'toda' || x.fecha >= a.fecha))),
      );
      const ids = enAlcance.map((x) => x.id);
      const t = iso();
      const nuevos = enAlcance.map((x) => {
        const mueve = x.id === a.id || dayOfWeek(x.fecha) === dow;
        return {
          ...x,
          fecha: mueve ? addDays(x.fecha, delta) : x.fecha,
          inicio: mueve ? c.inicio : x.inicio,
          duracion: c.duracion,
          nota: x.id === a.id && c.nota !== undefined ? c.nota : x.nota,
          updatedAt: t,
          historial: [...x.historial, { en: t, tipo: 'editada', nota: alcance === 'toda' ? 'Edición de toda la serie' : 'Edición de esta y las futuras' }],
        };
      });
      const conflictos = nuevos
        .map((n) => ({ n, pr: detectarProblemas(n, d, { ignorar: ids }, d.settings) }))
        .filter((x) => hayConflicto(x.pr))
        .map((x) => ({ fecha: x.n.fecha, inicio: x.n.inicio, ...x.pr }));
      if (conflictos.length && !permitirConflicto) throw new ConflictError({ porFecha: conflictos });

      const dias = serie.dias.filter((x) => Number(x.dia) !== dow && Number(x.dia) !== nuevoDow).concat({ dia: nuevoDow, hora: c.inicio });
      const hayAnteriores = d.appointments.some((x) => x.seriesId === serie.id && x.fecha < a.fecha);
      const ops = [];
      if (alcance === 'futuras' && hayAnteriores) {
        const fin = finDeSerie(serie);
        const B = { ...serie, id: nuevoId(), dias, duracion: c.duracion, fechaInicio: c.fecha < a.fecha ? c.fecha : a.fecha, fechaFin: fin, semanas: null, excepciones: serie.excepciones.filter((e) => e >= a.fecha), createdAt: t, updatedAt: t };
        const A = { ...serie, fechaFin: addDays(a.fecha, -1), semanas: null, updatedAt: t };
        ops.push(put('series', A), put('series', B));
        for (const n of nuevos) ops.push(put('appointments', { ...n, seriesId: B.id }));
      } else {
        ops.push(put('series', { ...serie, dias, duracion: c.duracion, updatedAt: t }));
        for (const n of nuevos) ops.push(put('appointments', n));
      }
      return { ops, resultado: { modificadas: nuevos.length, conflictos: conflictos.length } };
    });

  /** Excluye fechas (pausas/vacaciones) de una serie y elimina las citas aún no atendidas de esas fechas. */
  const excluirFechasSerie = (seriesId, fechas) =>
    tx((d) => {
      const s = buscar(d.series, seriesId, 'La serie no existe.');
      const set = new Set(fechas);
      const quitar = d.appointments.filter((a) => a.seriesId === seriesId && set.has(a.fecha) && ESTADOS_MODIFICABLES.includes(a.estado));
      const omitidas = d.appointments.filter((a) => a.seriesId === seriesId && set.has(a.fecha) && !ESTADOS_MODIFICABLES.includes(a.estado)).length;
      const exc = [...new Set([...s.excepciones, ...fechas])].sort();
      return { ops: [put('series', { ...s, excepciones: exc, updatedAt: iso() }), ...quitar.map((a) => del('appointments', a.id))], resultado: { eliminadas: quitar.length, conservadas: omitidas } };
    });

  /** Termina la serie en la cita indicada: borra ésa y las futuras sin atender. */
  const finalizarSerieDesde = (apptId) =>
    tx((d) => {
      const a = buscar(d.appointments, apptId, 'La cita no existe.');
      const s = buscar(d.series, a.seriesId, 'La cita no pertenece a una serie.');
      const quitar = d.appointments.filter((x) => x.seriesId === s.id && x.fecha >= a.fecha && ESTADOS_MODIFICABLES.includes(x.estado));
      const resto = d.appointments.some((x) => x.seriesId === s.id && !quitar.includes(x));
      return {
        ops: [put('series', { ...s, fechaFin: addDays(a.fecha, -1), semanas: null, estado: resto ? 'activa' : 'finalizada', updatedAt: iso() }), ...quitar.map((x) => del('appointments', x.id))],
        resultado: { eliminadas: quitar.length },
      };
    });

  /** Extiende una serie hasta una nueva fecha final sin duplicar citas existentes. */
  const extenderSerie = (seriesId, fechaFin, { permitirConflicto = false } = {}) =>
    tx((d) => {
      const s = buscar(d.series, seriesId, 'La serie no existe.');
      if (!isValidDate(fechaFin)) throw new ValidationError('La fecha final no es válida.');
      const finActual = finDeSerie(s);
      if (finActual && fechaFin <= finActual) throw new ValidationError('La nueva fecha final debe ser posterior a la actual.');
      const p = buscar(d.patients, s.patientId, 'El paciente no existe.');
      const filas = generarFechasSerie({ ...s, fechaFin, semanas: null }).filter(
        (f) => !d.appointments.some((a) => a.seriesId === s.id && (a.serieClave === f.clave || a.fecha === f.fecha)),
      );
      const nuevas = filas.map((f) => ({ f, pr: detectarProblemas({ id: '__t', fecha: f.fecha, inicio: f.inicio, duracion: s.duracion }, d, {}, d.settings) }));
      const conf = nuevas.filter((x) => hayConflicto(x.pr));
      if (conf.length && !permitirConflicto) throw new ConflictError({ porFecha: conf.map((x) => ({ fecha: x.f.fecha, inicio: x.f.inicio, ...x.pr })) });
      const citas = nuevas.map((x) => crearRegistroCita(p, { fecha: x.f.fecha, inicio: x.f.inicio, duracion: s.duracion }, { seriesId: s.id, serieClave: x.f.clave }));
      return { ops: [put('series', { ...s, fechaFin, semanas: null, estado: 'activa', updatedAt: iso() }), ...citas.map((c) => put('appointments', c))], resultado: { creadas: citas.length } };
    });

  // ------------------------------------------------------------ Pagos
  function normalizarPago(i, d) {
    const p = buscar(d.patients, i.patientId, 'Selecciona un paciente.');
    const importe = r2(Number(i.importe));
    if (!(importe > 0)) throw new ValidationError('El importe debe ser mayor que 0.', 'importe');
    if (!isValidDate(i.fecha)) throw new ValidationError('La fecha del pago no es válida.', 'fecha');
    if (i.fecha > hoy()) throw new ValidationError('La fecha del pago no puede ser futura: solo se registran pagos ya recibidos.', 'fecha');
    const moneda = i.moneda || p.moneda;
    if (!d.settings.monedas.includes(moneda)) throw new ValidationError('Moneda no habilitada.', 'moneda');
    if (!isStr(i.metodo)) throw new ValidationError('Elige el método de pago.', 'metodo');
    let obligacion = null;
    if (i.obligacion && i.obligacion.id) {
      const { tipo, id } = i.obligacion;
      const lista = { cita: d.appointments, plan: d.plans, paquete: d.packages }[tipo];
      const ob = lista && lista.find((x) => x.id === id && x.patientId === p.id);
      if (!ob) throw new ValidationError('El cobro al que asocias el pago no existe.');
      obligacion = { tipo, id };
    }
    return { patientId: p.id, fecha: i.fecha, importe, moneda, metodo: i.metodo.trim(), concepto: (i.concepto || '').trim(), obligacion, nota: (i.nota || '').trim() };
  }

  const registrarPago = (input) =>
    tx((d) => {
      const pago = { id: nuevoId(), ...normalizarPago(input, d), anulado: false, createdAt: iso() };
      return { ops: [put('payments', pago)], resultado: pago };
    });

  const anularPago = (id, motivo) =>
    tx((d) => {
      const p = buscar(d.payments, id, 'El pago no existe.');
      if (p.anulado) throw new ValidationError('El pago ya estaba anulado.');
      if (!isStr(motivo)) throw new ValidationError('Indica el motivo de la anulación.', 'motivo');
      return { ops: [put('payments', { ...p, anulado: true, anuladoEn: iso(), motivoAnulacion: motivo.trim() })], resultado: true };
    });

  /** Corrección explícita: anula el pago original y crea uno nuevo enlazado. */
  const corregirPago = (id, input, motivo) =>
    tx((d) => {
      const p = buscar(d.payments, id, 'El pago no existe.');
      if (p.anulado) throw new ValidationError('No se puede corregir un pago anulado.');
      if (!isStr(motivo)) throw new ValidationError('Indica el motivo de la corrección.', 'motivo');
      const nuevo = { id: nuevoId(), ...normalizarPago({ ...input, patientId: p.patientId }, d), anulado: false, corrige: p.id, createdAt: iso() };
      const viejo = { ...p, anulado: true, anuladoEn: iso(), motivoAnulacion: `Corrección: ${motivo.trim()}`, reemplazadoPor: nuevo.id };
      return { ops: [put('payments', viejo), put('payments', nuevo)], resultado: nuevo };
    });

  // ------------------------------------------------------------ Cobros por período
  function normalizarPlan(i, d) {
    const p = buscar(d.patients, i.patientId, 'Selecciona un paciente.');
    const importe = r2(Number(i.importe));
    if (!(importe > 0)) throw new ValidationError('El importe debe ser mayor que 0.', 'importe');
    if (!isValidDate(i.desde) || !isValidDate(i.hasta) || i.hasta < i.desde) throw new ValidationError('Revisa las fechas del período.', 'desde');
    const tipo = ['semanal', 'mensual', 'otro'].includes(i.tipo) ? i.tipo : 'otro';
    const moneda = i.moneda || p.moneda;
    if (!d.settings.monedas.includes(moneda)) throw new ValidationError('Moneda no habilitada.', 'moneda');
    return { patientId: p.id, tipo, importe, moneda, desde: i.desde, hasta: i.hasta, sesiones: i.sesiones ? Number(i.sesiones) : null, nota: (i.nota || '').trim() };
  }
  const crearPlan = (input) =>
    tx((d) => {
      const p = { id: nuevoId(), ...normalizarPlan(input, d), estado: 'activo', createdAt: iso(), updatedAt: iso() };
      return { ops: [put('plans', p)], resultado: p };
    });
  const actualizarPlan = (id, input) =>
    tx((d) => {
      const prev = buscar(d.plans, id, 'El cobro por período no existe.');
      const p = { ...prev, ...normalizarPlan({ ...input, patientId: prev.patientId }, d), updatedAt: iso() };
      return { ops: [put('plans', p)], resultado: p };
    });
  const cambiarEstadoPlan = (id, estado) =>
    tx((d) => {
      const prev = buscar(d.plans, id, 'El cobro por período no existe.');
      if (!['activo', 'cerrado', 'anulado'].includes(estado)) throw new ValidationError('Estado no válido.');
      return { ops: [put('plans', { ...prev, estado, updatedAt: iso() })], resultado: true };
    });

  // ------------------------------------------------------------ Paquetes
  const crearPaquete = (input, pagoInicial = null) =>
    tx((d) => {
      const p = buscar(d.patients, input.patientId, 'Selecciona un paciente.');
      if (!isStr(input.nombre)) throw new ValidationError('Escribe un nombre para el paquete.', 'nombre');
      const cant = Number(input.cantidadInicial);
      if (!(Number.isInteger(cant) && cant >= 1 && cant <= 500)) throw new ValidationError('La cantidad de sesiones debe ser un número entero entre 1 y 500.', 'cantidadInicial');
      const precio = r2(Number(input.precio) || 0);
      if (precio < 0) throw new ValidationError('El precio no puede ser negativo.', 'precio');
      const fechaCompra = input.fechaCompra || hoy();
      if (!isValidDate(fechaCompra)) throw new ValidationError('La fecha de compra no es válida.', 'fechaCompra');
      if (input.vigencia && (!isValidDate(input.vigencia) || input.vigencia < fechaCompra)) throw new ValidationError('La vigencia debe ser una fecha posterior a la compra.', 'vigencia');
      const moneda = input.moneda || p.moneda;
      if (!d.settings.monedas.includes(moneda)) throw new ValidationError('Moneda no habilitada.', 'moneda');
      const k = { id: nuevoId(), patientId: p.id, nombre: input.nombre.trim(), cantidadInicial: cant, precio, moneda, fechaCompra, vigencia: input.vigencia || '', estado: 'activo', createdAt: iso(), updatedAt: iso() };
      const ops = [put('packages', k)];
      if (pagoInicial && Number(pagoInicial.importe) > 0) {
        const pago = { id: nuevoId(), ...normalizarPago({ ...pagoInicial, fecha: pagoInicial.fecha || hoy(), metodo: pagoInicial.metodo || d.settings.metodosPago[0], patientId: p.id, moneda, concepto: pagoInicial.concepto || `Paquete ${k.nombre}`, obligacion: { tipo: 'paquete', id: k.id } }, { ...d, packages: [...d.packages, k] }), anulado: false, createdAt: iso() };
        ops.push(put('payments', pago));
      }
      return { ops, resultado: k };
    });

  const ajustarPaquete = (id, cantidad, motivo) =>
    tx((d) => {
      const k = buscar(d.packages, id, 'El paquete no existe.');
      const n = Number(cantidad);
      if (!Number.isInteger(n) || n === 0) throw new ValidationError('El ajuste debe ser un número entero distinto de 0 (positivo suma sesiones, negativo resta).');
      if (!isStr(motivo)) throw new ValidationError('Indica el motivo del ajuste manual.', 'motivo');
      const s = saldoPaquete(k, d.movements);
      if (s.disponibles + n < 0) throw new ValidationError('El ajuste dejaría el paquete con sesiones negativas.');
      const m = { id: nuevoId(), packageId: id, appointmentId: null, tipo: 'ajuste', cantidad: n, fecha: hoy(), motivo: motivo.trim(), createdAt: iso() };
      return { ops: [put('movements', m)], resultado: m };
    });

  const cerrarPaquete = (id, cerrado = true) =>
    tx((d) => {
      const k = buscar(d.packages, id, 'El paquete no existe.');
      return { ops: [put('packages', { ...k, estado: cerrado ? 'cerrado' : 'activo', updatedAt: iso() })], resultado: true };
    });

  // ------------------------------------------------------------ WhatsApp (estado manual)
  const marcarWhatsApp = (citaId, estado) =>
    tx((d) => {
      if (!['pendiente', 'confirmado', 'contactado'].includes(estado)) throw new ValidationError('Estado no válido.');
      const a = buscar(d.appointments, citaId, 'La cita no existe.');
      return { ops: [put('appointments', { ...a, whatsappEstado: estado, updatedAt: iso() })], resultado: true };
    });

  // ------------------------------------------------------------ Respaldo
  const exportarRespaldo = () =>
    bloquear(async () => {
      const d = await cargar();
      return construirRespaldo(d, d.settings, ahora());
    });

  const registrarRespaldoHecho = (info) =>
    tx((d) => ({ ops: [put('settings', { id: 'main', ...d.settings, ultimoRespaldo: { fecha: iso(), ...info } })], resultado: true }));

  const resumenImportacion = (obj, opciones) =>
    bloquear(async () => {
      const v = await validarRespaldo(obj);
      if (!v.ok) throw new ValidationError('El respaldo no es válido: ' + v.errores.join(' '));
      const d = await cargar();
      const plan = planificarImportacion(d, obj, opciones);
      return { validacion: v, resumen: plan.resumen, actual: Object.fromEntries(STORES_DATOS.map((s) => [s, d[s].length])) };
    });

  /** Ejecuta la importación. Reemplazar conserva el PIN local y la fecha del último respaldo de este dispositivo. */
  const importarRespaldo = (obj, opciones) =>
    bloquear(async () => {
      const v = await validarRespaldo(obj);
      if (!v.ok) throw new ValidationError('El respaldo no es válido: ' + v.errores.join(' '));
      const d = await cargar();
      const plan = planificarImportacion(d, obj, opciones);
      const ops = [...plan.ops];
      if (opciones.modo === 'reemplazar' && obj.datos.settings) {
        ops.push(put('settings', { id: 'main', ...mergeDeep(clone(DEFAULT_SETTINGS), obj.datos.settings), ultimoRespaldo: d.settings.ultimoRespaldo }));
      }
      await db.batch(ops);
      return plan.resumen;
    });

  const borrarTodo = () => bloquear(() => db.clearAll());

  return {
    db,
    cargar,
    hoy,
    guardarAjustes,
    leerSeguridad,
    definirPin,
    quitarPin,
    verificarPin,
    crearPaciente,
    actualizarPaciente,
    cambiarEstadoPaciente,
    huellaPaciente: async (id) => huellaPaciente(await cargar(), id),
    eliminarPaciente,
    crearCita,
    actualizarCita,
    cambiarEstadoCita,
    reprogramarCita,
    eliminarCita,
    crearBloqueo,
    actualizarBloqueo,
    eliminarBloqueo,
    vistaPreviaSerie,
    crearSerie,
    editarCitaSerie,
    excluirFechasSerie,
    finalizarSerieDesde,
    extenderSerie,
    registrarPago,
    anularPago,
    corregirPago,
    crearPlan,
    actualizarPlan,
    cambiarEstadoPlan,
    crearPaquete,
    ajustarPaquete,
    cerrarPaquete,
    marcarWhatsApp,
    exportarRespaldo,
    registrarRespaldoHecho,
    resumenImportacion,
    importarRespaldo,
    borrarTodo,
    estadoPaquete,
  };
}
