// Derivación de claves, hash de PIN/contraseña y cifrado de respaldos con WebCrypto.
// Límites: ver docs/SEGURIDAD.md. El PIN bloquea la interfaz; NO cifra la base IndexedDB.

const enc = new TextEncoder();
const dec = new TextDecoder();

export const b64 = (buf) => {
  const bytes = new Uint8Array(buf);
  let s = '';
  for (let i = 0; i < bytes.length; i += 0x8000) s += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
  return btoa(s);
};
export const unb64 = (s) => Uint8Array.from(atob(s), (c) => c.charCodeAt(0));

const subtle = () => {
  const s = globalThis.crypto?.subtle;
  if (!s) throw new Error('Este navegador no ofrece cifrado (WebCrypto). Abre la app desde HTTPS o localhost.');
  return s;
};

async function claveAES(secreto, salt, iter) {
  const base = await subtle().importKey('raw', enc.encode(secreto), 'PBKDF2', false, ['deriveKey']);
  return subtle().deriveKey({ name: 'PBKDF2', salt, iterations: iter, hash: 'SHA-256' }, base, { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);
}

export const ITER_PIN = 150000;
export const ITER_RESPALDO = 250000;

export async function hashSecreto(secreto, saltB64 = null, iter = ITER_PIN) {
  const salt = saltB64 ? unb64(saltB64) : globalThis.crypto.getRandomValues(new Uint8Array(16));
  const base = await subtle().importKey('raw', enc.encode(secreto), 'PBKDF2', false, ['deriveBits']);
  const bits = await subtle().deriveBits({ name: 'PBKDF2', salt, iterations: iter, hash: 'SHA-256' }, base, 256);
  return { salt: b64(salt), hash: b64(bits), iter };
}

export async function verificarSecreto(secreto, reg) {
  const r = await hashSecreto(secreto, reg.salt, reg.iter);
  // comparación sin atajos
  let diff = r.hash.length ^ reg.hash.length;
  for (let i = 0; i < Math.max(r.hash.length, reg.hash.length); i++) diff |= (r.hash.charCodeAt(i) || 0) ^ (reg.hash.charCodeAt(i) || 0);
  return diff === 0;
}

export async function sha256Hex(texto) {
  const h = await subtle().digest('SHA-256', enc.encode(texto));
  return [...new Uint8Array(h)].map((x) => x.toString(16).padStart(2, '0')).join('');
}

/** Cifra un texto con AES-256-GCM; la clave se deriva de la contraseña con PBKDF2-SHA256. */
export async function cifrarTexto(texto, password) {
  const salt = globalThis.crypto.getRandomValues(new Uint8Array(16));
  const iv = globalThis.crypto.getRandomValues(new Uint8Array(12));
  const key = await claveAES(password, salt, ITER_RESPALDO);
  const ct = await subtle().encrypt({ name: 'AES-GCM', iv }, key, enc.encode(texto));
  return {
    cifrado: true,
    kdf: { nombre: 'PBKDF2-SHA256', iteraciones: ITER_RESPALDO, salt: b64(salt) },
    cifra: 'AES-256-GCM',
    iv: b64(iv),
    contenido: b64(ct),
  };
}

export async function descifrarTexto(env, password) {
  try {
    const key = await claveAES(password, unb64(env.kdf.salt), env.kdf.iteraciones);
    const pt = await subtle().decrypt({ name: 'AES-GCM', iv: unb64(env.iv) }, key, unb64(env.contenido));
    return dec.decode(pt);
  } catch {
    throw new Error('Contraseña incorrecta o archivo dañado.');
  }
}
