// Acceso único a la base local, configuración y metadatos.
import { DB, DATA_STORES } from './db.js';
import { mergeSettings } from './defaults.js';

export const DB_NAME = 'agenda-terapia-lenguaje';

let db = null;

export async function initStore(name = DB_NAME, opts) {
  db = await DB.open(name, opts);
  return db;
}

export function getDB() {
  if (!db) throw new Error('La base de datos local todavía no está lista.');
  return db;
}

export function closeStore() {
  if (db) db.close();
  db = null;
}

export async function loadSettings() {
  return mergeSettings(await getDB().get('settings', 'main'));
}

export async function saveSettings(settings) {
  const clean = mergeSettings(settings);
  await getDB().put('settings', { ...clean, key: 'main' });
  return clean;
}

export async function getMeta(key) {
  const rec = await getDB().get('meta', key);
  return rec ? rec.value : undefined;
}

export async function setMeta(key, value) {
  await getDB().put('meta', { key, value });
}

/** Lee todos los datos (los volúmenes de un consultorio individual son pequeños). */
export async function loadAll() {
  return getDB().tx([...DATA_STORES, 'settings'], 'readonly', async (t) => {
    const out = {};
    for (const s of DATA_STORES) out[s] = await t.all(s);
    out.settings = mergeSettings(await t.get('settings', 'main'));
    return out;
  });
}

export async function appointmentsBetween(from, to) {
  return getDB().range('appointments', 'fecha', from, to);
}

export async function isEmptyDatabase() {
  const d = await getDB().tx(DATA_STORES, 'readonly', async (t) => {
    const counts = {};
    for (const s of DATA_STORES) counts[s] = (await t.all(s)).length;
    return counts;
  });
  return Object.values(d).every((n) => n === 0);
}
