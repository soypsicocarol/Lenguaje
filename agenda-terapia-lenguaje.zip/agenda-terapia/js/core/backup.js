// Formato de respaldo versionado: construcción, validación, resumen y planificación de importación.
import { APP_VERSION } from './constants.js';
import { cifrarTexto, descifrarTexto, sha256Hex } from './crypto.js';
import { deepEqual } from './util.js';

export const FORMATO = 'agenda-terapia-lenguaje-respaldo';
export const VERSION_FORMATO = 1;
export const STORES_DATOS = ['patients', 'appointments', 'series', 'blocks', 'payments', 'plans', 'packages', 'movements'];

export const ETIQUETAS = {
  patients: 'pacientes',
  appointments: 'citas',
  series: 'series',
  blocks: 'bloqueos',
  payments: 'pagos',
  plans: 'cobros por período',
  packages: 'paquetes',
  movements: 'movimientos de paquete',
};

export const contar = (datos) => Object.fromEntries(STORES_DATOS.map((s) => [s, (datos[s] || []).length]));

/** Construye el respaldo en claro. Se excluye el PIN/contraseña de acceso (no se transfiere). */
export async function construirRespaldo(datos, settings, ahora = new Date()) {
  const cuerpo = {};
  for (const s of STORES_DATOS) cuerpo[s] = datos[s] || [];
  const { ultimoRespaldo, ...ajustes } = settings;
  cuerpo.settings = ajustes;
  const texto = JSON.stringify(cuerpo);
  return {
    formato: FORMATO,
    version: VERSION_FORMATO,
    appVersion: APP_VERSION,
    exportadoEn: ahora.toISOString(),
    contadores: contar(cuerpo),
    integridad: { algoritmo: 'SHA-256', hash: await sha256Hex(texto) },
    datos: cuerpo,
  };
}

export async function cifrarRespaldo(obj, password) {
  const interno = JSON.stringify(obj);
  const env = await cifrarTexto(interno, password);
  return {
    formato: FORMATO,
    version: VERSION_FORMATO,
    exportadoEn: obj.exportadoEn,
    ...env,
  };
}

/** Lee texto de archivo. Devuelve {obj, cifrado}. */
export function leerArchivo(texto) {
  let obj;
  try {
    obj = JSON.parse(texto);
  } catch {
    throw new Error('El archivo no es un respaldo válido (no se pudo leer como JSON).');
  }
  if (!obj || obj.formato !== FORMATO) throw new Error('El archivo no corresponde a un respaldo de esta aplicación.');
  return { obj, cifrado: !!obj.cifrado };
}

export async function abrirCifrado(env, password) {
  const texto = await descifrarTexto(env, password);
  return leerArchivo(texto).obj;
}

/** Valida estructura, versión, integridad y relaciones. No modifica nada. */
export async function validarRespaldo(obj) {
  const errores = [];
  const avisos = [];
  if (!obj || obj.formato !== FORMATO) return { ok: false, errores: ['Formato desconocido.'], avisos, contadores: null };
  if (!Number.isInteger(obj.version) || obj.version < 1) errores.push('Versión del formato no válida.');
  else if (obj.version > VERSION_FORMATO) errores.push(`El respaldo es de una versión más nueva (${obj.version}). Actualiza la aplicación antes de importarlo.`);
  const d = obj.datos;
  if (!d || typeof d !== 'object') return { ok: false, errores: [...errores, 'El respaldo no contiene datos.'], avisos, contadores: null };
  for (const s of STORES_DATOS) {
    if (!Array.isArray(d[s])) errores.push(`Falta la sección "${ETIQUETAS[s]}".`);
    else {
      const ids = new Set();
      for (const r of d[s]) {
        if (!r || typeof r.id !== 'string' || !r.id) {
          errores.push(`Hay un registro sin identificador en "${ETIQUETAS[s]}".`);
          break;
        }
        if (ids.has(r.id)) {
          errores.push(`Identificador repetido en "${ETIQUETAS[s]}".`);
          break;
        }
        ids.add(r.id);
      }
    }
  }
  if (errores.length === 0) {
    // integridad
    const texto = JSON.stringify(d);
    const hash = await sha256Hex(texto);
    if (!obj.integridad || obj.integridad.hash !== hash) errores.push('La verificación de integridad falló: el archivo fue modificado o está incompleto.');
    // relaciones
    const ids = (s) => new Set(d[s].map((r) => r.id));
    const pac = ids('patients');
    const chk = (store, campo, set, nombre) => {
      const huerfanos = d[store].filter((r) => r[campo] && !set.has(r[campo])).length;
      if (huerfanos) errores.push(`${huerfanos} registro(s) de "${ETIQUETAS[store]}" apuntan a ${nombre} que no existe en el respaldo.`);
    };
    for (const s of ['appointments', 'series', 'payments', 'plans', 'packages']) chk(s, 'patientId', pac, 'un paciente');
    chk('appointments', 'seriesId', ids('series'), 'una serie');
    chk('movements', 'packageId', ids('packages'), 'un paquete');
    chk('movements', 'appointmentId', ids('appointments'), 'una cita');
  }
  if (errores.length === 0 && (!d.settings || typeof d.settings !== 'object')) avisos.push('El respaldo no incluye configuración; se conservará la actual.');
  return { ok: errores.length === 0, errores, avisos, contadores: errores.length ? null : contar(d) };
}

const marca = (r) => r.updatedAt || r.createdAt || '';

/**
 * Planifica la importación sin ejecutarla.
 * modo 'reemplazar' o 'combinar'; politica (solo combinar) 'local' | 'reciente'.
 */
export function planificarImportacion(local, obj, { modo, politica = 'local' }) {
  const d = obj.datos;
  const ops = [];
  const resumen = {};
  if (modo === 'reemplazar') {
    for (const s of STORES_DATOS) {
      ops.push({ op: 'clear', store: s });
      resumen[s] = { nuevos: d[s].length, iguales: 0, conflictos: 0, eliminados: (local[s] || []).length };
      for (const rec of d[s]) ops.push({ op: 'put', store: s, rec });
    }
    return { ops, resumen };
  }
  for (const s of STORES_DATOS) {
    const porId = new Map((local[s] || []).map((r) => [r.id, r]));
    const r = (resumen[s] = { nuevos: 0, iguales: 0, conflictos: 0, reemplazados: 0 });
    for (const rec of d[s]) {
      const l = porId.get(rec.id);
      if (!l) {
        r.nuevos++;
        ops.push({ op: 'put', store: s, rec });
      } else if (deepEqual(l, rec)) r.iguales++;
      else {
        r.conflictos++;
        if (politica === 'reciente' && marca(rec) > marca(l)) {
          r.reemplazados++;
          ops.push({ op: 'put', store: s, rec });
        }
      }
    }
  }
  return { ops, resumen };
}
