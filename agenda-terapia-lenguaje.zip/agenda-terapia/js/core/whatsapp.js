// WhatsApp manual: normaliza teléfonos, arma enlaces wa.me y plantillas. No envía nada.

/**
 * Acepta "+58 414-1234567", "0058414...", o un número local si hay código de país predeterminado.
 * @returns {{ok:boolean, digits?:string, e164?:string, error?:string}}
 */
export function normalizarTelefono(raw, codigoPais = '') {
  const s = String(raw ?? '').trim();
  if (!s) return { ok: false, error: 'Teléfono vacío.' };
  let digits;
  if (s.startsWith('+')) digits = s.slice(1).replace(/\D/g, '');
  else if (s.startsWith('00')) digits = s.replace(/\D/g, '').replace(/^00/, '');
  else {
    const local = s.replace(/\D/g, '').replace(/^0+/, '');
    const cc = String(codigoPais || '').replace(/\D/g, '');
    if (!cc) return { ok: false, error: 'Incluye el código de país (por ejemplo +58…).' };
    digits = local.startsWith(cc) && local.length >= 11 ? local : cc + local;
  }
  if (digits.length < 8 || digits.length > 15) return { ok: false, error: 'El teléfono debe tener entre 8 y 15 dígitos con código de país.' };
  return { ok: true, digits, e164: '+' + digits };
}

export const enlaceWhatsApp = (digits, texto = '') =>
  `https://wa.me/${digits}${texto ? '?text=' + encodeURIComponent(texto) : ''}`;

/** Reemplaza {variables}; las que no tienen valor se omiten sin dejar huecos raros. */
export function aplicarPlantilla(tpl, vars) {
  return String(tpl)
    .replace(/\{(\w+)\}/g, (m, k) => (vars[k] != null && vars[k] !== '' ? String(vars[k]) : ''))
    .replace(/[ \t]{2,}/g, ' ')
    .replace(/\s+([,.;:!?])/g, '$1')
    .trim();
}
