// CSV legible por Excel/Sheets. Neutraliza fórmulas (=,+,-,@) para evitar inyección en hojas de cálculo.

const celda = (v) => {
  if (v == null) return '';
  let s = String(v);
  if (/^[=+\-@\t\r]/.test(s) && !/^-?\d+(\.\d+)?$/.test(s)) s = "'" + s;
  return /[",\n\r;]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
};

export function aCSV(columnas, filas) {
  const head = columnas.map((c) => celda(c.titulo)).join(',');
  const body = filas.map((f) => columnas.map((c) => celda(typeof c.valor === 'function' ? c.valor(f) : f[c.valor])).join(','));
  return [head, ...body].join('\r\n') + '\r\n';
}
