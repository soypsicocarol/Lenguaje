// Errores propios para que la interfaz pueda mostrar mensajes comprensibles.

export class ValidationError extends Error {
  constructor(errors) {
    const list = Array.isArray(errors) ? errors : [String(errors)];
    super(list.join(' '));
    this.name = 'ValidationError';
    this.errors = list;
  }
}

/** Solapes con otras citas o bloqueos. La interfaz debe pedir confirmación explícita. */
export class ConflictError extends Error {
  constructor(conflicts) {
    super('Hay conflictos de horario.');
    this.name = 'ConflictError';
    this.conflicts = conflicts;
  }
}

/** Un pago supera el saldo de la obligación. Requiere confirmación. */
export class OverpayError extends Error {
  constructor(exceso, moneda) {
    super('El pago supera el saldo pendiente.');
    this.name = 'OverpayError';
    this.exceso = exceso;
    this.moneda = moneda;
  }
}

export class BackupError extends Error {
  constructor(code, message) {
    super(message);
    this.name = 'BackupError';
    this.code = code;
  }
}

/** Convierte cualquier error en un texto que una persona no técnica pueda entender. */
export function friendlyError(e) {
  if (!e) return 'Ocurrió un error desconocido.';
  if (e.name === 'ValidationError') return e.errors.join(' ');
  if (e.name === 'QuotaExceededError' || e?.cause?.name === 'QuotaExceededError') {
    return 'No hay espacio de almacenamiento en el dispositivo. Libera espacio o exporta un respaldo y borra datos antiguos.';
  }
  if (e.name === 'InvalidStateError' || e.name === 'TransactionInactiveError') {
    return 'No se pudo acceder a la base de datos local. Cierra otras pestañas de la agenda y vuelve a intentarlo.';
  }
  if (e.name === 'AbortError') return 'La operación se canceló y no se guardó ningún cambio.';
  return e.message || 'Ocurrió un error inesperado.';
}
