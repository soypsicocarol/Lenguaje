// Utilidades generales sin dependencias del navegador (aptas para Node y pruebas).

export const r2 = (x) => Math.round((Number(x) + Number.EPSILON) * 100) / 100;

export function uid() {
  const c = globalThis.crypto;
  if (c && c.randomUUID) return c.randomUUID();
  const b = new Uint8Array(16);
  if (c && c.getRandomValues) c.getRandomValues(b);
  else for (let i = 0; i < 16; i++) b[i] = Math.floor(Math.random() * 256);
  b[6] = (b[6] & 0x0f) | 0x40;
  b[8] = (b[8] & 0x3f) | 0x80;
  const h = [...b].map((x) => x.toString(16).padStart(2, '0')).join('');
  return `${h.slice(0, 8)}-${h.slice(8, 12)}-${h.slice(12, 16)}-${h.slice(16, 20)}-${h.slice(20)}`;
}

export class ValidationError extends Error {
  constructor(message, campo = null) {
    super(message);
    this.name = 'ValidationError';
    this.campo = campo;
  }
}

/** Se lanza cuando una cita choca con otra cita o con un bloqueo y falta confirmación explícita. */
export class ConflictError extends Error {
  constructor(info) {
    super('Conflicto de horario');
    this.name = 'ConflictError';
    this.info = info; // { citas:[], bloqueos:[], porFecha?:[] }
  }
}

export const clone = (x) => JSON.parse(JSON.stringify(x));

function sortKeys(v) {
  if (Array.isArray(v)) return v.map(sortKeys);
  if (v && typeof v === 'object') {
    return Object.keys(v)
      .sort()
      .reduce((o, k) => {
        o[k] = sortKeys(v[k]);
        return o;
      }, {});
  }
  return v;
}
export const deepEqual = (a, b) => JSON.stringify(sortKeys(a)) === JSON.stringify(sortKeys(b));

export function fmtMoney(n, cur = 'USD', locale = 'es') {
  const v = Number(n) || 0;
  try {
    return new Intl.NumberFormat(locale, { style: 'currency', currency: cur }).format(v);
  } catch {
    return `${v.toFixed(2)} ${cur}`;
  }
}

export const isStr = (x) => typeof x === 'string' && x.trim().length > 0;

export function mergeDeep(base, extra) {
  if (Array.isArray(base) || Array.isArray(extra)) return extra === undefined ? base : extra;
  if (base && typeof base === 'object' && extra && typeof extra === 'object') {
    const out = { ...base };
    for (const k of Object.keys(extra)) out[k] = k in base ? mergeDeep(base[k], extra[k]) : extra[k];
    return out;
  }
  return extra === undefined ? base : extra;
}

export function normText(s) {
  return String(s || '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '');
}
