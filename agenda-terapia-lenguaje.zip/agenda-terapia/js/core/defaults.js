// Configuración por defecto. Todo es editable desde Configuración.

export const APP_VERSION = '1.0.0';

const HORARIO_BASE = { abierto: true, desde: '08:00', hasta: '17:00' };

export const DEFAULT_SETTINGS = {
  consultorio: { nombre: 'Consultorio de Terapia del Lenguaje', terapeuta: '', telefono: '', direccion: '' },
  moneda: 'USD',
  monedas: ['USD', 'VES'],
  tarifaDefault: 0,
  duracionDefault: 45,
  duraciones: [30, 45, 60],
  horario: {
    0: { abierto: false, desde: '08:00', hasta: '12:00' },
    1: { ...HORARIO_BASE },
    2: { ...HORARIO_BASE },
    3: { ...HORARIO_BASE },
    4: { ...HORARIO_BASE },
    5: { ...HORARIO_BASE },
    6: { abierto: false, desde: '08:00', hasta: '12:00' },
  },
  metodosPago: ['Efectivo', 'Transferencia', 'Pago móvil'],
  // Código de país por defecto para teléfonos escritos sin código (editable).
  codigoPais: '58',
  // Cómo afecta cada estado a los paquetes (descuenta) y al cobro por sesión (cobra).
  reglasConsumo: {
    realizada: { descuenta: true, cobra: true },
    cancelada_representante: { descuenta: false, cobra: false },
    cancelada_terapeuta: { descuenta: false, cobra: false },
    inasistencia: { descuenta: false, cobra: false },
  },
  plantillas: {
    confirmacion:
      'Hola {representante}, le escribimos de {consultorio} para confirmar la sesión de {nino} el {fecha} a las {hora}. ¿Nos confirma su asistencia? Gracias.',
    recordatorio:
      'Hola {representante}, le recordamos la sesión de {nino} el {fecha} a las {hora} en {consultorio}. ¡Le esperamos!',
    cambio:
      'Hola {representante}, necesitamos cambiar el horario de la sesión de {nino}. La nueva fecha propuesta es {fecha} a las {hora}. ¿Le parece bien?',
    cancelacion:
      'Hola {representante}, lamentablemente debemos cancelar la sesión de {nino} del {fecha} a las {hora}. Le contactaremos para reprogramarla. Disculpe las molestias.',
    saldo:
      'Hola {representante}, le recordamos que hay un saldo pendiente de {saldo} correspondiente a las sesiones de {nino}. Cualquier duda, con gusto le ayudamos. Gracias.',
  },
  bloqueoMinutos: 5, // 0 = sin bloqueo automático
  csvSeparador: ';',
  semanasAbiertas: 12, // horizonte de citas para series sin fecha final
};

export const PLANTILLA_NOMBRES = {
  confirmacion: 'Confirmación',
  recordatorio: 'Recordatorio',
  cambio: 'Cambio de horario',
  cancelacion: 'Cancelación',
  saldo: 'Saldo pendiente',
};

const clone = (o) => JSON.parse(JSON.stringify(o));

/** Combina lo guardado con los valores por defecto (para versiones futuras). */
export function mergeSettings(stored) {
  const base = clone(DEFAULT_SETTINGS);
  if (!stored) return base;
  const s = { ...base, ...stored };
  s.consultorio = { ...base.consultorio, ...(stored.consultorio || {}) };
  s.plantillas = { ...base.plantillas, ...(stored.plantillas || {}) };
  s.horario = { ...base.horario };
  for (const k of Object.keys(base.horario)) s.horario[k] = { ...base.horario[k], ...((stored.horario || {})[k] || {}) };
  s.reglasConsumo = { ...base.reglasConsumo };
  for (const k of Object.keys(base.reglasConsumo)) {
    s.reglasConsumo[k] = { ...base.reglasConsumo[k], ...((stored.reglasConsumo || {})[k] || {}) };
  }
  s.reglasConsumo.realizada = { descuenta: true, cobra: true }; // regla fija
  delete s.key;
  return s;
}
