// Lógica de agenda: solapes, bloqueos, recurrencia.
import { absMin, addDays, dayOfWeek, diffDays, endTime, isValidDate, isValidTime, toMin } from './dates.js';
import { ESTADOS_LIBRES } from './constants.js';
import { ValidationError } from './util.js';

export const ocupa = (a) => !ESTADOS_LIBRES.includes(a.estado);

export const rangoCita = (a) => [absMin(a.fecha, a.inicio), absMin(a.fecha, a.inicio) + a.duracion];
export const rangoBloqueo = (b) => [absMin(b.fechaInicio, b.horaInicio), absMin(b.fechaFin, b.horaFin)];

const solapa = ([s1, e1], [s2, e2]) => s1 < e2 && s2 < e1;

/**
 * Detecta problemas de una cita candidata.
 * @returns {{citas:Array, bloqueos:Array, horario:null|'dia_inactivo'|'fuera_horario'}}
 *   citas y bloqueos son conflictos que exigen confirmación; horario es solo informativo.
 */
export function detectarProblemas(c, data, { ignorar = [] } = {}, settings = null) {
  const r = rangoCita(c);
  const citas = data.appointments.filter((a) => a.id !== c.id && !ignorar.includes(a.id) && ocupa(a) && solapa(r, rangoCita(a)));
  const bloqueos = data.blocks.filter((b) => solapa(r, rangoBloqueo(b)));
  let horario = null;
  const h = settings?.horario?.[dayOfWeek(c.fecha)];
  if (h) {
    if (!h.activo) horario = 'dia_inactivo';
    else if (toMin(c.inicio) < toMin(h.desde) || toMin(c.inicio) + c.duracion > toMin(h.hasta)) horario = 'fuera_horario';
  }
  return { citas, bloqueos, horario };
}
export const hayConflicto = (p) => p.citas.length > 0 || p.bloqueos.length > 0;

/** Genera las fechas de una serie semanal. Cada fila tiene `clave` estable (fecha original generada). */
export function generarFechasSerie(serie, { maxCitas = 400 } = {}) {
  const { dias, fechaInicio, fechaFin, semanas } = serie;
  const exc = new Set(serie.excepciones || []);
  let limite = null;
  if (fechaFin) limite = fechaFin;
  if (semanas) {
    const l = addDays(fechaInicio, 7 * semanas - 1);
    limite = limite && limite < l ? limite : l;
  }
  if (!limite) throw new ValidationError('Indica fecha final o número de semanas.', 'fin');
  const porDia = new Map(dias.map((d) => [Number(d.dia), d.hora]));
  const out = [];
  const n = diffDays(fechaInicio, limite);
  for (let i = 0; i <= n; i++) {
    const f = addDays(fechaInicio, i);
    const hora = porDia.get(dayOfWeek(f));
    if (hora && !exc.has(f)) out.push({ fecha: f, inicio: hora, clave: f });
    if (out.length > maxCitas) throw new ValidationError(`La serie generaría más de ${maxCitas} citas. Acorta el período.`, 'fin');
  }
  return out;
}

export function validarSerie(s) {
  if (!s.patientId) throw new ValidationError('Selecciona un paciente.', 'patientId');
  if (!Array.isArray(s.dias) || s.dias.length === 0) throw new ValidationError('Elige al menos un día de la semana.', 'dias');
  const vistos = new Set();
  for (const d of s.dias) {
    if (!(d.dia >= 0 && d.dia <= 6)) throw new ValidationError('Día de la semana no válido.', 'dias');
    if (!isValidTime(d.hora)) throw new ValidationError('Indica una hora válida para cada día elegido.', 'dias');
    if (vistos.has(Number(d.dia))) throw new ValidationError('Un día de la semana solo puede aparecer una vez en la serie.', 'dias');
    vistos.add(Number(d.dia));
  }
  if (!isValidDate(s.fechaInicio)) throw new ValidationError('Indica una fecha de inicio válida.', 'fechaInicio');
  if (s.fechaFin && !isValidDate(s.fechaFin)) throw new ValidationError('La fecha final no es válida.', 'fechaFin');
  if (s.fechaFin && s.fechaFin < s.fechaInicio) throw new ValidationError('La fecha final es anterior a la de inicio.', 'fechaFin');
  if (s.semanas != null && !(Number.isInteger(Number(s.semanas)) && s.semanas >= 1 && s.semanas <= 104))
    throw new ValidationError('El número de semanas debe estar entre 1 y 104.', 'semanas');
  if (!s.fechaFin && !s.semanas) throw new ValidationError('Indica fecha final o número de semanas.', 'fin');
  if (!(Number.isInteger(Number(s.duracion)) && s.duracion >= 5 && s.duracion <= 480))
    throw new ValidationError('La duración debe estar entre 5 y 480 minutos.', 'duracion');
}

export const etiquetaRango = (a) => `${a.inicio}–${endTime(a.inicio, a.duracion)}`;
