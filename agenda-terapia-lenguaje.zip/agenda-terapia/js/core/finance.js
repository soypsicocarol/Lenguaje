// Cálculos de paquetes, obligaciones, saldos e ingresos.
// Regla de seguridad financiera: el ingreso efectivo se basa SOLO en pagos registrados (no anulados).
import { REGLA_KEY } from './constants.js';
import { startOfWeek } from './dates.js';
import { r2 } from './util.js';

export const pagosValidos = (payments) => payments.filter((p) => !p.anulado);

export const reglaAplica = (reglas, estado) => {
  const k = REGLA_KEY[estado];
  return !!(k && reglas && reglas[k]);
};

// ---------------------------------------------------------------- Paquetes

export function saldoPaquete(pkg, movements) {
  let consumo = 0;
  let devolucion = 0;
  let ajustes = 0;
  for (const m of movements) {
    if (m.packageId !== pkg.id) continue;
    if (m.tipo === 'consumo') consumo += m.cantidad;
    else if (m.tipo === 'devolucion') devolucion += m.cantidad;
    else if (m.tipo === 'ajuste') ajustes += m.cantidad;
  }
  return {
    iniciales: pkg.cantidadInicial,
    consumidas: consumo - devolucion,
    ajustes,
    disponibles: pkg.cantidadInicial - consumo + devolucion + ajustes,
  };
}

export function estadoPaquete(pkg, movements, hoy) {
  if (pkg.estado === 'cerrado') return 'cerrado';
  if (pkg.vigencia && pkg.vigencia < hoy) return 'vencido';
  if (saldoPaquete(pkg, movements).disponibles <= 0) return 'agotado';
  return 'activo';
}

/**
 * Calcula (sin escribir) las operaciones necesarias para que el consumo del paquete de una cita
 * refleje su estado actual. Es idempotente: llamarla varias veces nunca descuenta dos veces.
 */
export function planificarPaquete(appt, { packages, movements, reglas, nuevoId, ahora }) {
  const propios = movements.filter((m) => m.appointmentId === appt.id && (m.tipo === 'consumo' || m.tipo === 'devolucion'));
  const neto = propios.reduce((s, m) => s + (m.tipo === 'consumo' ? m.cantidad : -m.cantidad), 0);
  const deseado = appt.modalidad === 'paquete' && reglaAplica(reglas, appt.estado) ? 1 : 0;
  const ultimoConsumo = [...propios].reverse().find((m) => m.tipo === 'consumo');
  if (deseado === neto) return { ops: [], aviso: null };

  if (deseado > neto) {
    let pkg = ultimoConsumo ? packages.find((p) => p.id === ultimoConsumo.packageId && p.estado !== 'cerrado') : null;
    if (!pkg) {
      pkg = packages
        .filter((p) => p.patientId === appt.patientId && estadoPaquete(p, movements, appt.fecha) === 'activo')
        .sort((a, b) => (a.fechaCompra + a.createdAt).localeCompare(b.fechaCompra + b.createdAt))[0];
    }
    if (!pkg) return { ops: [], aviso: 'sin_paquete' };
    return {
      ops: [
        {
          op: 'put',
          store: 'movements',
          rec: {
            id: nuevoId(),
            packageId: pkg.id,
            appointmentId: appt.id,
            tipo: 'consumo',
            cantidad: 1,
            fecha: appt.fecha,
            motivo: `Sesión ${appt.estado}`,
            createdAt: ahora,
          },
        },
      ],
      aviso: null,
    };
  }
  // deseado < neto: devolver la sesión al paquete del que se descontó
  const pkgId = ultimoConsumo ? ultimoConsumo.packageId : propios[0].packageId;
  return {
    ops: [
      {
        op: 'put',
        store: 'movements',
        rec: {
          id: nuevoId(),
          packageId: pkgId,
          appointmentId: appt.id,
          tipo: 'devolucion',
          cantidad: 1,
          fecha: appt.fecha,
          motivo: `Cambio de estado a ${appt.estado}`,
          createdAt: ahora,
        },
      },
    ],
    aviso: null,
  };
}

// ---------------------------------------------------------------- Obligaciones y saldos

/** Cargo generado por una cita para pacientes con pago por sesión. */
export function cargoDeCita(a, reglasCobro) {
  if (a.modalidad !== 'sesion') return null;
  if (!reglaAplica(reglasCobro, a.estado)) return null;
  const imp = r2(a.tarifa || 0);
  if (imp <= 0) return null;
  return { importe: imp, moneda: a.moneda };
}

export function construirObligaciones(patientId, data, settings) {
  const out = [];
  for (const a of data.appointments) {
    if (a.patientId !== patientId) continue;
    const c = cargoDeCita(a, settings.reglasCobro);
    if (c) out.push({ tipo: 'cita', id: a.id, fecha: a.fecha, concepto: `Sesión ${a.fecha} ${a.inicio}`, ...c });
  }
  for (const p of data.plans) {
    if (p.patientId !== patientId || p.estado === 'anulado') continue;
    out.push({
      tipo: 'plan',
      id: p.id,
      fecha: p.desde,
      concepto: `Período ${p.desde} a ${p.hasta}${p.nota ? ' · ' + p.nota : ''}`,
      importe: r2(p.importe),
      moneda: p.moneda,
    });
  }
  for (const k of data.packages) {
    if (k.patientId !== patientId || k.precio <= 0) continue;
    out.push({ tipo: 'paquete', id: k.id, fecha: k.fechaCompra, concepto: `Paquete ${k.nombre}`, importe: r2(k.precio), moneda: k.moneda });
  }
  return out.sort((a, b) => (a.fecha + a.tipo + a.id).localeCompare(b.fecha + b.tipo + b.id));
}

/**
 * Libro del paciente: asigna pagos vinculados a su obligación y los pagos generales (o excedentes)
 * por orden cronológico. Nunca mezcla monedas.
 */
export function libroPaciente(patientId, data, settings) {
  const obligaciones = construirObligaciones(patientId, data, settings).map((o) => ({ ...o, pagado: 0 }));
  const pagos = pagosValidos(data.payments).filter((p) => p.patientId === patientId);
  const pool = {}; // moneda -> importe disponible para asignar por antigüedad
  const add = (m, v) => (pool[m] = r2((pool[m] || 0) + v));
  const vinculados = {};
  for (const p of pagos) {
    const ob = p.obligacion
      ? obligaciones.find((o) => o.tipo === p.obligacion.tipo && o.id === p.obligacion.id && o.moneda === p.moneda)
      : null;
    if (ob) (vinculados[ob.tipo + ob.id] ||= []).push(p);
    else add(p.moneda, p.importe);
  }
  for (const ob of obligaciones) {
    const suma = r2((vinculados[ob.tipo + ob.id] || []).reduce((s, p) => s + p.importe, 0));
    ob.pagado = Math.min(ob.importe, suma);
    if (suma > ob.importe) add(ob.moneda, suma - ob.importe);
  }
  for (const ob of obligaciones) {
    const falta = r2(ob.importe - ob.pagado);
    if (falta > 0 && (pool[ob.moneda] || 0) > 0) {
      const x = Math.min(falta, pool[ob.moneda]);
      ob.pagado = r2(ob.pagado + x);
      pool[ob.moneda] = r2(pool[ob.moneda] - x);
    }
  }
  const porMoneda = {};
  const slot = (m) => (porMoneda[m] ||= { cargos: 0, pagado: 0, pendiente: 0, aFavor: 0 });
  for (const ob of obligaciones) {
    ob.pendiente = r2(ob.importe - ob.pagado);
    ob.estado = ob.pendiente <= 0 ? 'pagada' : ob.pagado > 0 ? 'parcial' : 'pendiente';
    const s = slot(ob.moneda);
    s.cargos = r2(s.cargos + ob.importe);
    s.pagado = r2(s.pagado + ob.pagado);
    s.pendiente = r2(s.pendiente + ob.pendiente);
  }
  for (const [m, v] of Object.entries(pool)) if (v > 0) slot(m).aFavor = r2(v);
  return { obligaciones, porMoneda };
}

export function saldosPendientes(data, settings) {
  const out = [];
  for (const p of data.patients) {
    const l = libroPaciente(p.id, data, settings);
    const pend = Object.entries(l.porMoneda).filter(([, v]) => v.pendiente > 0);
    if (pend.length) out.push({ patient: p, porMoneda: Object.fromEntries(pend.map(([m, v]) => [m, v.pendiente])) });
  }
  return out;
}

// ---------------------------------------------------------------- Ingresos

export const claveGrupo = (fecha, gran) => (gran === 'dia' ? fecha : gran === 'semana' ? startOfWeek(fecha) : fecha.slice(0, 7));

/** Ingresos efectivamente recibidos agrupados por día/semana/mes y moneda. */
export function ingresosPorPeriodo(payments, desde, hasta, gran = 'dia') {
  const res = {};
  for (const p of pagosValidos(payments)) {
    if (p.fecha < desde || p.fecha > hasta) continue;
    const k = claveGrupo(p.fecha, gran);
    const g = (res[k] ||= {});
    g[p.moneda] = r2((g[p.moneda] || 0) + p.importe);
  }
  return res;
}

export function totalPorMoneda(payments, desde, hasta) {
  const t = {};
  for (const p of pagosValidos(payments)) {
    if (p.fecha < desde || p.fecha > hasta) continue;
    t[p.moneda] = r2((t[p.moneda] || 0) + p.importe);
  }
  return t;
}

/** Importe estimado de sesiones programadas (NO es ingreso cobrado). Solo pacientes con pago por sesión. */
export function proyectado(appointments, desde, hasta) {
  const t = {};
  for (const a of appointments) {
    if (a.modalidad !== 'sesion' || !(a.estado === 'programada' || a.estado === 'confirmada')) continue;
    if (a.fecha < desde || a.fecha > hasta || !(a.tarifa > 0)) continue;
    t[a.moneda] = r2((t[a.moneda] || 0) + a.tarifa);
  }
  return t;
}
