// Capa mínima sobre IndexedDB. Sin dependencias. Todas las operaciones compuestas se
// ejecutan dentro de UNA transacción (db.tx) para que o se guardan completas o no se
// guarda nada (por ejemplo: cambiar el estado de una cita + descontar paquete).

export const DB_VERSION = 1;

export const SCHEMA = {
  patients: { keyPath: 'id', indexes: [['estado', 'estado']] },
  appointments: {
    keyPath: 'id',
    indexes: [['fecha', 'fecha'], ['patientId', 'patientId'], ['seriesId', 'seriesId'], ['estado', 'estado']],
  },
  series: { keyPath: 'id', indexes: [['patientId', 'patientId']] },
  blocks: { keyPath: 'id' },
  payments: {
    keyPath: 'id',
    indexes: [['patientId', 'patientId'], ['fecha', 'fecha'], ['obligacionId', 'obligacionId']],
  },
  // "plans" = PaymentPlan: obligaciones de pago (sesión, período, paquete)
  plans: {
    keyPath: 'id',
    indexes: [['patientId', 'patientId'], ['appointmentId', 'appointmentId'], ['packageId', 'packageId']],
  },
  packages: { keyPath: 'id', indexes: [['patientId', 'patientId']] },
  movements: { keyPath: 'id', indexes: [['packageId', 'packageId'], ['appointmentId', 'appointmentId']] },
  settings: { keyPath: 'key' },
  meta: { keyPath: 'key' },
};

/** Almacenes que forman parte de un respaldo (la configuración va aparte). */
export const DATA_STORES = ['patients', 'appointments', 'series', 'blocks', 'payments', 'plans', 'packages', 'movements'];

const req = (r) =>
  new Promise((resolve, reject) => {
    r.onsuccess = () => resolve(r.result);
    r.onerror = () => reject(r.error);
  });

export class DB {
  constructor(handle, KeyRange) {
    this.handle = handle;
    this.KeyRange = KeyRange;
  }

  static open(name, { indexedDB = globalThis.indexedDB, IDBKeyRange = globalThis.IDBKeyRange } = {}) {
    return new Promise((resolve, reject) => {
      if (!indexedDB) {
        reject(new Error('Este navegador no permite guardar datos locales (IndexedDB no disponible).'));
        return;
      }
      let request;
      try {
        request = indexedDB.open(name, DB_VERSION);
      } catch (e) {
        reject(e);
        return;
      }
      request.onupgradeneeded = () => {
        const db = request.result;
        for (const [store, cfg] of Object.entries(SCHEMA)) {
          if (db.objectStoreNames.contains(store)) continue;
          const os = db.createObjectStore(store, { keyPath: cfg.keyPath });
          for (const [idxName, path] of cfg.indexes || []) os.createIndex(idxName, path);
        }
      };
      request.onsuccess = () => {
        const handle = request.result;
        handle.onversionchange = () => handle.close();
        resolve(new DB(handle, IDBKeyRange));
      };
      request.onerror = () => reject(request.error);
      request.onblocked = () =>
        reject(new Error('La base de datos está bloqueada por otra pestaña abierta. Ciérrala e inténtalo de nuevo.'));
    });
  }

  /**
   * Ejecuta fn(t) dentro de una transacción. IMPORTANTE: dentro de fn solo se debe
   * esperar (await) a operaciones de `t`; esperar otras cosas cierra la transacción.
   * Si fn lanza un error, la transacción se cancela y no se guarda nada.
   */
  tx(storeNames, mode, fn) {
    return new Promise((resolve, reject) => {
      let t;
      try {
        t = this.handle.transaction(storeNames, mode);
      } catch (e) {
        reject(e);
        return;
      }
      let result;
      let failed = false;
      const KR = this.KeyRange;
      const api = {
        get: (s, k) => req(t.objectStore(s).get(k)),
        put: (s, v) => req(t.objectStore(s).put(v)),
        del: (s, k) => req(t.objectStore(s).delete(k)),
        all: (s) => req(t.objectStore(s).getAll()),
        clear: (s) => req(t.objectStore(s).clear()),
        byIndex: (s, idx, key) => req(t.objectStore(s).index(idx).getAll(key)),
        range: (s, idx, lower, upper) => req(t.objectStore(s).index(idx).getAll(KR.bound(lower, upper))),
      };
      t.oncomplete = () => resolve(result);
      t.onerror = () => {
        if (!failed) {
          failed = true;
          reject(t.error);
        }
      };
      t.onabort = () => {
        if (!failed) {
          failed = true;
          reject(t.error || new Error('Transacción cancelada'));
        }
      };
      Promise.resolve()
        .then(() => fn(api))
        .then((r) => {
          result = r;
        })
        .catch((e) => {
          if (!failed) {
            failed = true;
            reject(e);
          }
          try {
            t.abort();
          } catch {
            /* ya finalizada */
          }
        });
    });
  }

  get(store, key) {
    return this.tx([store], 'readonly', (t) => t.get(store, key));
  }
  all(store) {
    return this.tx([store], 'readonly', (t) => t.all(store));
  }
  put(store, value) {
    return this.tx([store], 'readwrite', (t) => t.put(store, value));
  }
  del(store, key) {
    return this.tx([store], 'readwrite', (t) => t.del(store, key));
  }
  byIndex(store, idx, key) {
    return this.tx([store], 'readonly', (t) => t.byIndex(store, idx, key));
  }
  range(store, idx, lower, upper) {
    return this.tx([store], 'readonly', (t) => t.range(store, idx, lower, upper));
  }

  close() {
    this.handle.close();
  }
}

export function deleteDatabase(name, indexedDB = globalThis.indexedDB) {
  return new Promise((resolve, reject) => {
    const r = indexedDB.deleteDatabase(name);
    r.onsuccess = () => resolve();
    r.onerror = () => reject(r.error);
    r.onblocked = () => reject(new Error('No se pudo borrar: hay otra pestaña usando la base de datos.'));
  });
}
