// Constantes del dominio y configuración predeterminada.

export const APP_VERSION = '1.0.0';

export const ESTADOS = {
  programada: { label: 'Programada', corto: 'Prog.' },
  confirmada: { label: 'Confirmada', corto: 'Conf.' },
  realizada: { label: 'Realizada', corto: 'Real.' },
  cancelada_representante: { label: 'Cancelada por representante', corto: 'Canc. repr.' },
  cancelada_terapeuta: { label: 'Cancelada por terapeuta', corto: 'Canc. terap.' },
  inasistencia: { label: 'Inasistencia', corto: 'Inasist.' },
  reprogramada: { label: 'Reprogramada', corto: 'Reprog.' },
};

/** Estados que liberan el horario (no ocupan agenda). */
export const ESTADOS_LIBRES = ['cancelada_representante', 'cancelada_terapeuta', 'reprogramada'];
/** Estados que todavía pueden modificarse en bloque desde una serie. */
export const ESTADOS_MODIFICABLES = ['programada', 'confirmada'];

/** Estado -> clave de las reglas de consumo/cobro. */
export const REGLA_KEY = {
  realizada: 'realizada',
  cancelada_representante: 'canceladaRepresentante',
  cancelada_terapeuta: 'canceladaTerapeuta',
  inasistencia: 'inasistencia',
};

export const MODALIDADES = {
  sesion: 'Por sesión',
  periodo: 'Por período (semanal o mensual)',
  paquete: 'Paquete prepagado',
};

export const WA_ESTADOS = {
  pendiente: 'Pendiente de confirmar',
  confirmado: 'Confirmado',
  contactado: 'Contacto realizado',
};

export const DEFAULT_TEMPLATES = {
  confirmacion:
    'Hola {representante}, le escribo de {consultorio} para confirmar la sesión de terapia de lenguaje de {nino} el {fecha} a las {hora}. ¿Nos confirma su asistencia? ¡Gracias!',
  recordatorio: 'Hola {representante}, le recuerdo la sesión de {nino} el {fecha} a las {hora}. ¡Los esperamos!',
  cambio:
    'Hola {representante}, necesito cambiar el horario de la sesión de {nino} del {fecha} a las {hora}. El nuevo horario propuesto es: [indicar nuevo horario]. ¿Le queda bien?',
  cancelacion:
    'Hola {representante}, lamentablemente debo cancelar la sesión de {nino} del {fecha} a las {hora}. Le propondré una nueva fecha para reprogramarla. Disculpe los inconvenientes.',
  saldo:
    'Hola {representante}, le escribo de {consultorio} para recordarle que {nino} tiene un saldo pendiente de {saldo}. Quedo pendiente de cualquier consulta. ¡Gracias!',
};

export const TEMPLATE_LABELS = {
  confirmacion: 'Confirmación',
  recordatorio: 'Recordatorio',
  cambio: 'Cambio de horario',
  cancelacion: 'Cancelación',
  saldo: 'Saldo pendiente',
};

const horarioBase = (activo) => ({ activo, desde: '08:00', hasta: '18:00' });

export const DEFAULT_SETTINGS = {
  consultorio: '',
  moneda: 'USD',
  monedas: ['USD'],
  codigoPais: '58',
  duracionPredeterminada: 45,
  duracionesAdicionales: [30, 45, 60, 90],
  horario: {
    0: horarioBase(false),
    1: horarioBase(true),
    2: horarioBase(true),
    3: horarioBase(true),
    4: horarioBase(true),
    5: horarioBase(true),
    6: horarioBase(false),
  },
  tarifaPredeterminada: 0,
  metodosPago: ['Efectivo', 'Transferencia', 'Pago móvil'],
  plantillas: { ...DEFAULT_TEMPLATES },
  // Qué estados descuentan una sesión del paquete prepagado.
  reglasPaquete: { realizada: true, canceladaRepresentante: false, canceladaTerapeuta: false, inasistencia: false },
  // Qué estados generan cobro para pacientes con pago por sesión.
  reglasCobro: { realizada: true, canceladaRepresentante: false, canceladaTerapeuta: false, inasistencia: false },
  autobloqueoMin: 5,
  ultimoRespaldo: null, // { fecha, archivo, resultado, cifrado, contadores }
};
