// Fechas locales como texto "AAAA-MM-DD" y horas "HH:MM". Se evita guardar instantes UTC
// para que una cita "lunes 3:00 p. m." siga siendo esa hora aunque cambie el huso horario o el horario de verano.

export const pad = (n) => String(n).padStart(2, '0');

export function isValidDate(s) {
  if (typeof s !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(s)) return false;
  const [y, m, d] = s.split('-').map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d));
  return dt.getUTCFullYear() === y && dt.getUTCMonth() === m - 1 && dt.getUTCDate() === d;
}

export function isValidTime(s) {
  if (typeof s !== 'string' || !/^\d{2}:\d{2}$/.test(s)) return false;
  const [h, m] = s.split(':').map(Number);
  return h >= 0 && h <= 23 && m >= 0 && m <= 59;
}

const utc = (s) => {
  const [y, m, d] = s.split('-').map(Number);
  return Date.UTC(y, m - 1, d);
};
const fromUtc = (ms) => {
  const d = new Date(ms);
  return `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())}`;
};

export function fmtDate(d) {
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}
export const today = (now = new Date()) => fmtDate(now);
export const addDays = (s, n) => fromUtc(utc(s) + n * 86400000);
export const diffDays = (a, b) => Math.round((utc(b) - utc(a)) / 86400000);
/** 0 = domingo ... 6 = sábado */
export const dayOfWeek = (s) => new Date(utc(s)).getUTCDay();
/** Lunes como inicio de semana */
export const startOfWeek = (s) => addDays(s, -((dayOfWeek(s) + 6) % 7));
export const startOfMonth = (s) => s.slice(0, 8) + '01';
export function endOfMonth(s) {
  const [y, m] = s.split('-').map(Number);
  return fromUtc(Date.UTC(y, m, 0));
}
export function addMonths(s, n) {
  const [y, m] = s.split('-').map(Number);
  const t = y * 12 + (m - 1) + n;
  return `${Math.floor(t / 12)}-${pad((t % 12) + 1)}-01`;
}

export const toMin = (hhmm) => {
  const [h, m] = hhmm.split(':').map(Number);
  return h * 60 + m;
};
export const fromMin = (n) => `${pad(Math.floor(n / 60))}:${pad(n % 60)}`;
export const endTime = (inicio, dur) => fromMin(toMin(inicio) + dur);

/** Minutos absolutos desde 1970-01-01 (hora local "plana"), útil para comparar rangos entre días. */
export const absMin = (fecha, hhmm) => Math.round(utc(fecha) / 60000) + (hhmm === '24:00' ? 1440 : toMin(hhmm));

export function calcAge(birth, ref = today()) {
  if (!isValidDate(birth)) return null;
  const [by, bm, bd] = birth.split('-').map(Number);
  const [ry, rm, rd] = ref.split('-').map(Number);
  let months = (ry - by) * 12 + (rm - bm);
  if (rd < bd) months -= 1;
  if (months < 0) return null;
  return { years: Math.floor(months / 12), months: months % 12 };
}
export function formatAge(birth, ref = today()) {
  const a = calcAge(birth, ref);
  if (!a) return '';
  if (a.years === 0) return `${a.months} ${a.months === 1 ? 'mes' : 'meses'}`;
  const y = `${a.years} ${a.years === 1 ? 'año' : 'años'}`;
  return a.months ? `${y} ${a.months} ${a.months === 1 ? 'mes' : 'meses'}` : y;
}

const DIAS = ['domingo', 'lunes', 'martes', 'miércoles', 'jueves', 'viernes', 'sábado'];
export const nombreDia = (i) => DIAS[i];
export const DIAS_CORTOS = ['Dom', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb'];

const localDate = (s) => {
  const [y, m, d] = s.split('-').map(Number);
  return new Date(y, m - 1, d, 12);
};
export const fmtFechaLarga = (s) =>
  new Intl.DateTimeFormat('es', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }).format(localDate(s));
export const fmtFechaCorta = (s) =>
  new Intl.DateTimeFormat('es', { weekday: 'short', day: 'numeric', month: 'short' }).format(localDate(s));
export const fmtMes = (s) => new Intl.DateTimeFormat('es', { month: 'long', year: 'numeric' }).format(localDate(s));
export const fmtHora = (hhmm) => {
  const [h, m] = hhmm.split(':').map(Number);
  const suf = h >= 12 ? 'p. m.' : 'a. m.';
  const h12 = h % 12 === 0 ? 12 : h % 12;
  return `${h12}:${pad(m)} ${suf}`;
};
