// Dinero: todos los cálculos se hacen en centavos enteros para evitar errores de
// coma flotante. Los importes se guardan como números con dos decimales.

export const toCents = (n) => Math.round(Number(n) * 100);
export const fromCents = (c) => Math.round(c) / 100;

/** Suma de importes (en unidades) sin errores de redondeo. */
export function sum(values) {
  return fromCents(values.reduce((acc, v) => acc + toCents(v), 0));
}

/**
 * Interpreta un importe escrito por una persona: "12,50", "12.50", "1.234,56", "1,234.56".
 * Devuelve NaN si no es válido o es negativo.
 */
export function parseAmount(input) {
  if (typeof input === 'number') return Number.isFinite(input) && input >= 0 ? fromCents(toCents(input)) : NaN;
  let s = String(input ?? '').trim().replace(/\s/g, '');
  if (!s || !/^[0-9.,]+$/.test(s)) return NaN;
  const lastComma = s.lastIndexOf(',');
  const lastDot = s.lastIndexOf('.');
  if (lastComma >= 0 && lastDot >= 0) {
    const dec = lastComma > lastDot ? ',' : '.';
    const thou = dec === ',' ? '.' : ',';
    s = s.split(thou).join('').replace(dec, '.');
  } else if (lastComma >= 0) {
    if (s.split(',').length > 2) return NaN;
    s = s.replace(',', '.');
  } else if (s.split('.').length > 2) {
    return NaN;
  }
  const n = Number(s);
  return Number.isFinite(n) && n >= 0 ? fromCents(toCents(n)) : NaN;
}

const nf = new Intl.NumberFormat('es', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

/** "1.234,50 USD": siempre con el código de moneda para no confundir monedas. */
export function fmtMoney(amount, currency) {
  const n = Number.isFinite(amount) ? amount : 0;
  return `${nf.format(n)} ${currency || ''}`.trim();
}

/** Texto para un objeto { USD: 10, VES: 5 } -> "10,00 USD · 5,00 VES". */
export function fmtByCurrency(obj) {
  const entries = Object.entries(obj || {}).filter(([, v]) => v);
  if (!entries.length) return '—';
  return entries.map(([cur, v]) => fmtMoney(v, cur)).join(' · ');
}
