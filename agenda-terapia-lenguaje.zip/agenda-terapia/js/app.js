// Punto de entrada: base local, bloqueo, navegación y service worker.
import { abrirIndexedDB } from './db.js';
import { crearServicios } from './services.js';
import { aviso, h, icono, mensajeError } from './ui/dom.js';
import { S, refrescar } from './ui/state.js';
import { vistaInicio } from './ui/inicio.js';
import { vistaAgenda } from './ui/agenda.js';
import { fichaPaciente, vistaPacientes } from './ui/pacientes.js';
import { vistaPagos } from './ui/pagos.js';
import { vistaConfig } from './ui/config.js';
import { pantallaBloqueo } from './ui/lock.js';

const root = document.getElementById('app');
let promptInstalar = null;
const instalar = {
  disponible: () => !!promptInstalar,
  lanzar: async () => {
    if (!promptInstalar) return;
    promptInstalar.prompt();
    await promptInstalar.userChoice;
    promptInstalar = null;
    S.render();
  },
};
window.addEventListener('beforeinstallprompt', (e) => {
  e.preventDefault();
  promptInstalar = e;
  if (S.data) S.render();
});

const NAV = [['inicio', 'Inicio', 'home'], ['agenda', 'Agenda', 'calendar'], ['pacientes', 'Pacientes', 'users'], ['pagos', 'Pagos', 'wallet'], ['config', 'Ajustes', 'settings']];

function leerRuta() {
  const [r, p] = (location.hash.replace(/^#\/?/, '') || 'inicio').split('/');
  S.ruta = NAV.some((n) => n[0] === r) ? r : 'inicio';
  S.param = p || null;
}

function render() {
  if (S.bloqueado) return pantallaBloqueo(root, desbloquear);
  if (!S.data) return;
  const scroll = window.scrollY;
  const main = h('main', { id: 'contenido', tabindex: '-1' });
  try {
    if (S.ruta === 'inicio') vistaInicio(main, { instalar });
    else if (S.ruta === 'agenda') vistaAgenda(main);
    else if (S.ruta === 'pacientes') (S.param ? fichaPaciente(main, S.param) : vistaPacientes(main));
    else if (S.ruta === 'pagos') vistaPagos(main);
    else vistaConfig(main, { instalar });
  } catch (e) {
    console.error(e);
    main.append(h('div', { class: 'err' }, 'No se pudo mostrar esta pantalla: ' + mensajeError(e)));
  }
  const nav = h('nav', { class: 'nav', 'aria-label': 'Principal' }, h('div', { class: 'marca' }, 'Agenda Lenguaje'),
    ...NAV.map(([k, n, ic]) => h('a', { href: `#/${k}`, 'aria-current': S.ruta === k ? 'page' : null }, icono(ic), n)));
  root.replaceChildren(h('div', { class: 'app' }, nav, main));
  window.scrollTo(0, scroll);
}
S.render = render;

// ---------------------------------------------------------------- Bloqueo automático
let ultimaActividad = Date.now();
let temporizador = null;
S.bloquearAhora = () => {
  if (!S.pinActivo) return;
  S.bloqueado = true;
  S.data = null;
  document.querySelectorAll('dialog').forEach((d) => d.close());
  render();
};
async function desbloquear() {
  S.bloqueado = false;
  ultimaActividad = Date.now();
  await refrescar();
}
function vigilar() {
  clearTimeout(temporizador);
  const min = S.ajustes?.autobloqueoMin || 0;
  if (!S.pinActivo || !min || S.bloqueado) return;
  temporizador = setTimeout(() => {
    if (Date.now() - ultimaActividad >= min * 60000) S.bloquearAhora();
    else vigilar();
  }, 15000);
}
['pointerdown', 'keydown', 'touchstart'].forEach((ev) => window.addEventListener(ev, () => {
  ultimaActividad = Date.now();
  vigilar();
}, { passive: true }));
document.addEventListener('visibilitychange', () => {
  const min = S.ajustes?.autobloqueoMin || 0;
  if (document.visibilityState === 'visible' && S.pinActivo && min && !S.bloqueado && Date.now() - ultimaActividad >= min * 60000) S.bloquearAhora();
});

// ---------------------------------------------------------------- Arranque
async function iniciar() {
  try {
    const db = await abrirIndexedDB();
    S.svc = crearServicios(db);
    window.__agenda = { S }; // útil para depurar; no expone datos fuera de esta pestaña
    navigator.storage?.persist?.().catch(() => {});
    S.pinActivo = !!(await S.svc.leerSeguridad());
    leerRuta();
    window.addEventListener('hashchange', () => {
      leerRuta();
      render();
      document.getElementById('contenido')?.focus({ preventScroll: true });
      window.scrollTo(0, 0);
    });
    if (S.pinActivo) {
      S.bloqueado = true;
      render();
    } else await refrescar();
    const orig = S.render;
    S.render = () => {
      orig();
      vigilar();
    };
    vigilar();
  } catch (e) {
    console.error(e);
    root.replaceChildren(h('div', { class: 'lock' }, h('div', { class: 'card' }, h('h1', null, 'No se pudo abrir el almacenamiento local'), h('p', null, mensajeError(e)),
      h('p', { class: 'muted' }, 'Esta agenda necesita guardar datos en el navegador. Revisa que no estés en una ventana privada, que haya espacio libre y que el navegador permita almacenamiento para este sitio.'))));
  }
}

if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('sw.js').catch((e) => console.warn('Sin modo sin conexión:', e));
  });
}
iniciar();
