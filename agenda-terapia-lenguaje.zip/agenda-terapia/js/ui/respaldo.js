// Exportación e importación de respaldos (transferencia manual entre dispositivos).
import { ETIQUETAS, STORES_DATOS, abrirCifrado, cifrarRespaldo, leerArchivo, validarRespaldo } from '../core/backup.js';
import { aviso, campo, check, confirmar, descargar, h, icono, modal } from './dom.js';
import { S, refrescar } from './state.js';

const sello = () => {
  const d = new Date();
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}_${p(d.getHours())}${p(d.getMinutes())}`;
};

/** Entrega el archivo: selector de guardado si existe; si no, descarga normal. Devuelve true si se entregó. */
async function entregar(nombre, texto) {
  if (window.showSaveFilePicker) {
    try {
      const fh = await window.showSaveFilePicker({ suggestedName: nombre, types: [{ description: 'Respaldo de agenda', accept: { 'application/json': ['.json'] } }] });
      const w = await fh.createWritable();
      await w.write(texto);
      await w.close();
      return true;
    } catch (e) {
      if (e && e.name === 'AbortError') return false;
    }
  }
  descargar(nombre, texto, 'application/json');
  return true;
}

export function exportarUI() {
  const cif = check('Proteger el respaldo con contraseña (recomendado)', { checked: true });
  const p1 = h('input', { type: 'password', autocomplete: 'new-password', 'aria-label': 'Contraseña del respaldo' });
  const p2 = h('input', { type: 'password', autocomplete: 'new-password', 'aria-label': 'Repetir contraseña' });
  const bloque = h('div', null, campo('Contraseña del respaldo', p1, 'Mínimo 8 caracteres. Si la olvidas, el archivo NO se puede recuperar.'), campo('Repetir contraseña', p2));
  cif.input.addEventListener('change', () => (bloque.hidden = !cif.input.checked));
  modal({
    titulo: 'Exportar respaldo',
    contenido: h('div', null,
      h('p', null, 'Se creará un archivo con pacientes, citas, series, pagos, paquetes y configuración. No incluye tu PIN de acceso.'),
      cif, bloque,
      h('div', { class: 'aviso warn' }, 'Guarda el archivo fuera de este dispositivo (correo, nube privada, memoria USB). Un respaldo que solo está en este teléfono se pierde con él.')),
    acciones: [
      { texto: 'Cancelar' },
      {
        texto: 'Crear respaldo',
        clase: 'primario',
        icono: 'download',
        onClick: async () => {
          if (cif.input.checked) {
            if (p1.value.length < 8) throw new Error('La contraseña debe tener al menos 8 caracteres.');
            if (p1.value !== p2.value) throw new Error('Las contraseñas no coinciden.');
          }
          const obj = await S.svc.exportarRespaldo();
          const sal = cif.input.checked ? JSON.stringify(await cifrarRespaldo(obj, p1.value)) : JSON.stringify(obj);
          const nombre = `respaldo-agenda-${sello()}${cif.input.checked ? '.cifrado' : ''}.json`;
          const ok = await entregar(nombre, sal);
          if (!ok) return false;
          await S.svc.registrarRespaldoHecho({ archivo: nombre, resultado: 'generado', cifrado: cif.input.checked, contadores: obj.contadores });
          await refrescar();
          aviso('Respaldo generado. Comprueba que el archivo quedó guardado donde esperabas.', 'ok');
        },
      },
    ],
  });
}

export function importarUI(archivo) {
  (async () => {
    try {
      const texto = await archivo.text();
      let { obj, cifrado } = leerArchivo(texto);
      if (cifrado) {
        const pass = await pedirClave();
        if (pass === null) return;
        obj = await abrirCifrado(obj, pass);
      }
      const v = await validarRespaldo(obj);
      if (!v.ok) {
        modal({ titulo: 'No se puede importar', contenido: h('div', null, h('p', null, 'El archivo no pasó la validación; no se modificó nada:'), h('ul', null, ...v.errores.map((e) => h('li', null, e)))), acciones: [{ texto: 'Cerrar', clase: 'primario' }] });
        return;
      }
      mostrarResumen(obj, v);
    } catch (e) {
      modal({ titulo: 'No se puede importar', contenido: h('p', null, e.message), acciones: [{ texto: 'Cerrar', clase: 'primario' }] });
    }
  })();
}

function pedirClave() {
  return new Promise((resolve) => {
    let res = null;
    const i = h('input', { type: 'password', autocomplete: 'off' });
    const m = modal({
      titulo: 'Respaldo protegido',
      contenido: campo('Contraseña del respaldo', i),
      alCerrar: () => resolve(res),
      acciones: [{ texto: 'Cancelar' }, { texto: 'Abrir', clase: 'primario', onClick: () => { res = i.value; } }],
    });
    setTimeout(() => i.focus(), 30);
    return m;
  });
}

async function mostrarResumen(obj, v) {
  const actual = await S.svc.cargar();
  const hayLocal = STORES_DATOS.some((s) => actual[s].length > 0);
  const modo = { v: 'reemplazar' };
  const rReemp = h('input', { type: 'radio', name: 'modo', value: 'reemplazar', checked: true });
  const rComb = h('input', { type: 'radio', name: 'modo', value: 'combinar' });
  const pol = h('select', { 'aria-label': 'Si un registro existe en ambos' }, h('option', { value: 'local' }, 'Conservar el de este dispositivo'), h('option', { value: 'reciente' }, 'Usar el más reciente'));
  const detalle = h('div');
  const pintar = async () => {
    const op = { modo: rComb.checked ? 'combinar' : 'reemplazar', politica: pol.value };
    const r = await S.svc.resumenImportacion(obj, op);
    detalle.replaceChildren(h('div', { class: 'tabla-wrap' }, h('table', { class: 'tabla' },
      h('thead', null, h('tr', null, h('th', null, 'Datos'), h('th', { class: 'num' }, 'En el archivo'), h('th', { class: 'num' }, 'En este dispositivo'), h('th', null, 'Resultado'))),
      h('tbody', null, ...STORES_DATOS.map((s) => {
        const x = r.resumen[s];
        return h('tr', null, h('td', null, ETIQUETAS[s]), h('td', { class: 'num' }, String(v.contadores[s])), h('td', { class: 'num' }, String(r.actual[s])),
          h('td', null, op.modo === 'reemplazar' ? `Se reemplazan (${x.eliminados} se eliminan)` : `${x.nuevos} nuevos · ${x.iguales} iguales · ${x.conflictos} en conflicto${x.reemplazados ? ` (${x.reemplazados} actualizados)` : ''}`));
      })))));
  };
  [rReemp, rComb].forEach((r) => r.addEventListener('change', () => { pol.disabled = !rComb.checked; pintar(); }));
  pol.addEventListener('change', pintar);
  pol.disabled = true;
  const m = modal({
    titulo: 'Importar respaldo',
    ancho: true,
    contenido: h('div', null,
      h('p', null, `Respaldo creado el ${new Date(obj.exportadoEn).toLocaleString('es')} (versión de formato ${obj.version}). La verificación de integridad fue correcta.`),
      hayLocal ? h('div', { class: 'aviso warn', role: 'alert' }, h('strong', null, 'Este dispositivo ya contiene datos. '), 'Antes de continuar se recomienda guardar un respaldo de lo actual. ',
        h('button', { type: 'button', class: 'chico', onClick: exportarUI }, icono('download'), 'Respaldar lo actual primero')) : null,
      h('fieldset', { class: 'card' }, h('legend', null, 'Cómo importar'),
        h('label', { class: 'check' }, rReemp, h('span', null, 'Reemplazar todo: borra los datos de este dispositivo y deja exactamente los del archivo.')),
        h('label', { class: 'check' }, rComb, h('span', null, 'Combinar: agrega lo que no existe aquí (por identificador), sin duplicar.')),
        campo('Si un registro existe en ambos con diferencias', pol)),
      detalle),
    acciones: [
      { texto: 'Cancelar' },
      {
        texto: 'Importar',
        clase: 'primario',
        icono: 'upload',
        onClick: async () => {
          const op = { modo: rComb.checked ? 'combinar' : 'reemplazar', politica: pol.value };
          const ok = await confirmar({
            titulo: op.modo === 'reemplazar' ? 'Confirmar reemplazo' : 'Confirmar combinación',
            mensaje: op.modo === 'reemplazar' ? 'Se borrarán los datos actuales de este dispositivo y se reemplazarán por los del archivo. Esta acción no se puede deshacer.' : 'Se agregarán al dispositivo los registros nuevos del archivo.',
            confirmar: op.modo === 'reemplazar' ? 'Reemplazar datos' : 'Combinar datos', peligro: op.modo === 'reemplazar',
          });
          if (!ok) return false;
          await S.svc.importarRespaldo(obj, op);
          await refrescar();
          aviso('Importación completada.', 'ok');
        },
      },
    ],
  });
  pintar();
  return m;
}
