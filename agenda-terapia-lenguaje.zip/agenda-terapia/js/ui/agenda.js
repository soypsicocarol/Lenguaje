// Vistas de agenda: diaria, semanal y mensual con búsqueda y filtro por estado.
import { ESTADOS } from '../core/constants.js';
import { DIAS_CORTOS, addDays, addMonths, dayOfWeek, endOfMonth, endTime, fmtFechaCorta, fmtFechaLarga, fmtMes, startOfMonth, startOfWeek, toMin } from '../core/dates.js';
import { normText } from '../core/util.js';
import { ocupa } from '../core/schedule.js';
import { h, icono, opciones, anexar } from './dom.js';
import { S, hoy, nombrePaciente, pacienteDe } from './state.js';
import { badge, detalleCita, formBloqueo, formCita, formSerie, rango } from './citas.js';

function citasDe(desde, hasta) {
  const t = normText(S.agenda.texto);
  return S.data.appointments
    .filter((a) => a.fecha >= desde && a.fecha <= hasta)
    .filter((a) => !S.agenda.estado || a.estado === S.agenda.estado)
    .filter((a) => !t || normText(nombrePaciente(pacienteDe(a.patientId))).includes(t))
    .sort((a, b) => (a.fecha + a.inicio).localeCompare(b.fecha + b.inicio));
}
const bloquesDe = (desde, hasta) => S.data.blocks.filter((b) => b.fechaInicio <= hasta && b.fechaFin >= desde);

function filaCita(a) {
  const p = pacienteDe(a.patientId);
  return h('button', { type: 'button', class: `item st-${a.estado}`, 'data-cita': a.id, onClick: () => detalleCita(a.id) },
    h('span', { class: 'hora' }, rango(a).replace(/ [ap]\. m\./g, '').replace(' – ', '–')),
    h('span', { class: 'cuerpo' }, h('strong', null, nombrePaciente(p)), h('small', null, [a.duracion + ' min', a.seriesId ? 'serie' : null, a.pendienteReprogramar ? 'por reprogramar' : null, a.whatsappEstado === 'confirmado' ? 'confirmó por WhatsApp' : null].filter(Boolean).join(' · '))),
    badge(a.estado));
}
function filaBloque(b) {
  return h('button', { type: 'button', class: 'item bloqueo', onClick: () => formBloqueo({ bloque: b }) },
    h('span', { class: 'hora' }, icono('block'), ' Bloqueo'),
    h('span', { class: 'cuerpo' }, h('strong', null, b.motivo), h('small', null, `${fmtFechaCorta(b.fechaInicio)} ${b.horaInicio} → ${fmtFechaCorta(b.fechaFin)} ${b.horaFin}`)));
}

function vistaDia(f) {
  const citas = citasDe(f, f);
  const bl = bloquesDe(f, f);
  const items = [...citas.map((a) => ({ k: a.inicio, el: filaCita(a) })), ...bl.map((b) => ({ k: b.fechaInicio < f ? '00:00' : b.horaInicio, el: filaBloque(b) }))].sort((a, b) => toMin(a.k) - toMin(b.k));
  const activa = citas.filter(ocupa).length;
  return h('div', null,
    h('p', { class: 'muted' }, `${fmtFechaLarga(f)} · ${activa} cita(s) activa(s)`),
    items.length ? items.map((i) => i.el) : h('div', { class: 'vacio' }, h('p', null, 'No hay citas para este día.'), h('button', { type: 'button', class: 'primario', onClick: () => formCita({ fecha: f }) }, icono('plus'), 'Agendar cita')));
}

function vistaSemana(f) {
  const ini = startOfWeek(f);
  const dias = Array.from({ length: 7 }, (_, i) => addDays(ini, i));
  const citas = citasDe(dias[0], dias[6]);
  const bl = bloquesDe(dias[0], dias[6]);
  return h('div', { class: 'semana' }, ...dias.map((d) => {
    const delDia = citas.filter((a) => a.fecha === d);
    return h('section', { class: `dia-col${d === hoy() ? ' hoy' : ''}`, 'aria-label': fmtFechaLarga(d) },
      h('header', null, h('button', { type: 'button', class: 'chico', onClick: () => { S.agenda.fecha = d; S.agenda.vista = 'dia'; S.render(); } }, `${DIAS_CORTOS[dayOfWeek(d)]} ${d.slice(8)}`), h('small', { class: 'muted' }, delDia.filter(ocupa).length ? `${delDia.filter(ocupa).length}` : '')),
      ...delDia.map((a) => h('button', { type: 'button', class: `mini st-${a.estado}`, onClick: () => detalleCita(a.id) }, h('b', null, a.inicio), ' ', nombrePaciente(pacienteDe(a.patientId)), h('br'), h('small', null, ESTADOS[a.estado].corto))),
      ...bl.filter((b) => b.fechaInicio <= d && b.fechaFin >= d).map((b) => h('button', { type: 'button', class: 'mini', onClick: () => formBloqueo({ bloque: b }) }, icono('block'), ' ', b.motivo)));
  }));
}

function vistaMes(f) {
  const ini = startOfMonth(f);
  const gridIni = startOfWeek(ini);
  const fin = endOfMonth(f);
  const gridFin = addDays(startOfWeek(fin), 6);
  const citas = citasDe(gridIni, gridFin);
  const bl = bloquesDe(gridIni, gridFin);
  const celdas = [];
  for (let d = gridIni; d <= gridFin; d = addDays(d, 1)) {
    const n = citas.filter((a) => a.fecha === d && ocupa(a)).length;
    const hayB = bl.some((b) => b.fechaInicio <= d && b.fechaFin >= d);
    celdas.push(h('button', { type: 'button', class: `celda${d.slice(0, 7) !== f.slice(0, 7) ? ' fuera' : ''}${d === hoy() ? ' hoy' : ''}`, 'aria-label': `${fmtFechaLarga(d)}: ${n} cita(s)${hayB ? ', con bloqueo' : ''}`, onClick: () => { S.agenda.fecha = d; S.agenda.vista = 'dia'; S.render(); } },
      h('b', null, +d.slice(8)), n ? h('span', { class: 'n' }, `${n} cita${n === 1 ? '' : 's'}`) : null, hayB ? h('span', null, icono('block'), ' bloqueo') : null));
  }
  return h('div', { class: 'mes' }, ...['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'].map((d) => h('div', { class: 'cab' }, d)), ...celdas);
}

export function vistaAgenda(cont) {
  const A = S.agenda;
  if (!A.fecha) A.fecha = hoy();
  const paso = (n) => {
    A.fecha = A.vista === 'dia' ? addDays(A.fecha, n) : A.vista === 'semana' ? addDays(A.fecha, 7 * n) : addMonths(A.fecha, n).slice(0, 8) + '01';
    S.render();
  };
  const titulo = A.vista === 'dia' ? fmtFechaCorta(A.fecha) : A.vista === 'semana' ? `${fmtFechaCorta(startOfWeek(A.fecha))} – ${fmtFechaCorta(addDays(startOfWeek(A.fecha), 6))}` : fmtMes(A.fecha);
  anexar(cont, 
    h('div', { class: 'page-head' }, h('h1', null, 'Agenda'),
      h('div', { class: 'row' },
        h('button', { type: 'button', class: 'primario', onClick: () => formCita({ fecha: A.fecha }) }, icono('plus'), 'Cita'),
        h('button', { type: 'button', onClick: () => formSerie() }, icono('repeat'), 'Serie semanal'),
        h('button', { type: 'button', onClick: () => formBloqueo({ fecha: A.fecha }) }, icono('block'), 'Bloqueo'))),
    h('div', { class: 'toolbar' },
      h('button', { type: 'button', class: 'icono', 'aria-label': 'Anterior', onClick: () => paso(-1) }, icono('left')),
      h('button', { type: 'button', onClick: () => { A.fecha = hoy(); S.render(); } }, 'Hoy'),
      h('button', { type: 'button', class: 'icono', 'aria-label': 'Siguiente', onClick: () => paso(1) }, icono('right')),
      h('span', { class: 'titulo', 'aria-live': 'polite' }, titulo),
      h('input', { type: 'date', value: A.fecha, 'aria-label': 'Ir a la fecha', style: 'width:auto', onChange: (e) => { if (e.target.value) { A.fecha = e.target.value; S.render(); } } }),
      h('span', { class: 'spacer' }),
      h('div', { class: 'seg', role: 'group', 'aria-label': 'Vista' }, ...[['dia', 'Día'], ['semana', 'Semana'], ['mes', 'Mes']].map(([k, n]) => h('button', { type: 'button', 'aria-pressed': A.vista === k, onClick: () => { A.vista = k; S.render(); } }, n)))),
    h('div', { class: 'filtros' },
      h('input', { type: 'search', placeholder: 'Buscar paciente…', 'aria-label': 'Buscar paciente', value: A.texto, onInput: (e) => { A.texto = e.target.value; clearTimeout(vistaAgenda.t); vistaAgenda.t = setTimeout(() => { S.render(); const el = document.querySelector('input[type=search]'); if (el) { el.focus(); el.setSelectionRange(el.value.length, el.value.length); } }, 250); } }),
      h('select', { 'aria-label': 'Filtrar por estado', onChange: (e) => { A.estado = e.target.value; S.render(); } }, h('option', { value: '' }, 'Todos los estados'), ...opciones(Object.entries(ESTADOS).map(([k, v]) => [k, v.label]), A.estado))),
    A.vista === 'dia' ? vistaDia(A.fecha) : A.vista === 'semana' ? vistaSemana(A.fecha) : vistaMes(A.fecha));
}
