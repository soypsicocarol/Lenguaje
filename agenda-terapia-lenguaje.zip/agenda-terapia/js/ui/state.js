// Estado compartido de la interfaz.
import { ConflictError } from '../core/util.js';
import { aviso, mensajeError } from './dom.js';

export const S = {
  svc: null,
  data: null,
  ajustes: null,
  bloqueado: false,
  ruta: 'inicio',
  param: null,
  agenda: { vista: 'dia', fecha: '', texto: '', estado: '' },
  pagos: { tab: 'pagos', paciente: '', desde: '', hasta: '' },
  reportes: { preset: 'mes', desde: '', hasta: '', paciente: '', gran: 'dia' },
  pacientes: { texto: '', filtro: 'activos' },
  render: () => {},
};

export async function refrescar({ render = true } = {}) {
  S.data = await S.svc.cargar();
  S.ajustes = S.data.settings;
  if (render) S.render();
}

export const pacienteDe = (id) => S.data.patients.find((p) => p.id === id);
export const nombrePaciente = (p) => (p ? `${p.nombre} ${p.apellidos || ''}`.trim() : '(paciente eliminado)');
export const hoy = () => S.svc.hoy();

/** Ejecuta una acción de escritura desde un botón (fuera de un diálogo): refresca y muestra errores como aviso. */
export async function ejecutar(fn, exito = null) {
  try {
    const r = await fn();
    await refrescar();
    if (exito) aviso(exito, 'ok');
    return r ?? true;
  } catch (e) {
    if (e instanceof ConflictError) throw e;
    aviso(mensajeError(e), 'error');
    return null;
  }
}
