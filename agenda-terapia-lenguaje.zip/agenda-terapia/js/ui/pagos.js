// Pagos, paquetes, cobros por período, saldos y reportes.
import { ESTADOS } from '../core/constants.js';
import { addDays, endOfMonth, fmtFechaCorta, fmtMes, startOfMonth, startOfWeek, addMonths } from '../core/dates.js';
import { aCSV } from '../core/csv.js';
import { estadoPaquete, ingresosPorPeriodo, libroPaciente, pagosValidos, proyectado, saldoPaquete, saldosPendientes, totalPorMoneda } from '../core/finance.js';
import { fmtMoney } from '../core/util.js';
import { aviso, campo, confirmar, descargarCSV, h, icono, modal, opciones, pedirTexto, vaciar, anexar } from './dom.js';
import { S, ejecutar, hoy, nombrePaciente, pacienteDe, refrescar } from './state.js';
import { abrirWhatsApp } from './whatsapp.js';

const money = (o) => (o && Object.keys(o).length ? Object.entries(o).map(([m, v]) => fmtMoney(v, m)).join(' · ') : '—');

// ------------------------------------------------------------------ Formulario de pago

export function formPago({ patientId = '', obligacion = null, importe = '', concepto = '', corregir = null } = {}) {
  const pacientes = S.data.patients.filter((p) => p.estado === 'activo' || p.id === (corregir?.patientId || patientId)).sort((a, b) => nombrePaciente(a).localeCompare(nombrePaciente(b)));
  if (!pacientes.length) return aviso('Primero crea un paciente.', 'warn');
  const base = corregir || {};
  const selP = h('select', { disabled: !!corregir }, ...opciones(pacientes.map((p) => [p.id, nombrePaciente(p)]), base.patientId || patientId || pacientes[0].id));
  const fecha = h('input', { type: 'date', value: base.fecha || hoy(), max: hoy(), required: true });
  const imp = h('input', { type: 'number', min: 0, step: '0.01', value: base.importe ?? importe, required: true });
  const mon = h('select', null, ...opciones(S.ajustes.monedas.map((m) => [m, m]), base.moneda || pacienteDe(selP.value)?.moneda || S.ajustes.moneda));
  const met = h('select', null, ...opciones(S.ajustes.metodosPago.map((m) => [m, m]), base.metodo || S.ajustes.metodosPago[0]));
  const con = h('input', { type: 'text', value: base.concepto || concepto, maxlength: 120 });
  const obl = h('select');
  const nota = h('input', { type: 'text', value: base.nota || '', maxlength: 200 });
  const motivo = h('input', { type: 'text', maxlength: 200 });
  const llenarObl = () => {
    const lib = libroPaciente(selP.value, S.data, S.ajustes);
    const pend = lib.obligaciones.filter((o) => o.pendiente > 0 || (corregir?.obligacion && o.tipo === corregir.obligacion.tipo && o.id === corregir.obligacion.id));
    const actual = obligacion || corregir?.obligacion;
    vaciar(obl).append(h('option', { value: '' }, 'Abono general (se aplica al cobro más antiguo)'),
      ...pend.map((o) => h('option', { value: `${o.tipo}:${o.id}`, selected: !!actual && actual.tipo === o.tipo && actual.id === o.id }, `${o.concepto} — pendiente ${fmtMoney(o.pendiente, o.moneda)}`)));
  };
  selP.addEventListener('change', () => {
    mon.value = pacienteDe(selP.value)?.moneda || mon.value;
    llenarObl();
  });
  llenarObl();
  modal({
    titulo: corregir ? 'Corregir pago' : 'Registrar pago',
    contenido: h('div', null,
      corregir ? h('div', { class: 'aviso warn' }, 'El pago original quedará anulado (no se borra) y se creará uno nuevo enlazado, con el motivo que indiques.') : null,
      campo('Paciente', selP),
      h('div', { class: 'form-grid' }, campo('Fecha del pago', fecha), campo('Importe', imp), campo('Moneda', mon), campo('Método de pago', met)),
      campo('Concepto', con), campo('Asociar a un cobro', obl, 'Un pago parcial no marca como saldado un cobro que aún tiene saldo.'), campo('Nota (opcional)', nota),
      corregir ? campo('Motivo de la corrección', motivo) : null),
    acciones: [
      { texto: 'Cancelar' },
      {
        texto: corregir ? 'Guardar corrección' : 'Registrar pago',
        clase: 'primario',
        onClick: async () => {
          const [tipo, id] = obl.value ? obl.value.split(':') : [];
          const datos = { patientId: selP.value, fecha: fecha.value, importe: imp.value, moneda: mon.value, metodo: met.value, concepto: con.value, nota: nota.value, obligacion: id ? { tipo, id } : null };
          if (corregir) await S.svc.corregirPago(corregir.id, datos, motivo.value);
          else await S.svc.registrarPago(datos);
          await refrescar();
          aviso(corregir ? 'Pago corregido.' : 'Pago registrado.', 'ok');
        },
      },
    ],
  });
}

export async function anularPagoUI(p) {
  const motivo = await pedirTexto({ titulo: 'Anular pago', etiqueta: 'Motivo de la anulación', requerido: true, confirmar: 'Anular pago', ayuda: 'El pago se conserva en el historial como anulado y deja de sumar a los ingresos.' });
  if (!motivo) return;
  await ejecutar(() => S.svc.anularPago(p.id, motivo), 'Pago anulado.');
}

// ------------------------------------------------------------------ Paquetes y cobros por período

export function formPaquete(patientId) {
  const p = pacienteDe(patientId);
  const nombre = h('input', { type: 'text', value: 'Paquete de 8 sesiones', required: true });
  const cant = h('input', { type: 'number', min: 1, max: 500, step: 1, value: 8 });
  const precio = h('input', { type: 'number', min: 0, step: '0.01', value: p.tarifa ? p.tarifa * 8 : 0 });
  const compra = h('input', { type: 'date', value: hoy(), max: hoy() });
  const vig = h('input', { type: 'date' });
  const mon = h('select', null, ...opciones(S.ajustes.monedas.map((m) => [m, m]), p.moneda));
  const pagoImp = h('input', { type: 'number', min: 0, step: '0.01', value: '', 'aria-label': 'Importe pagado ahora' });
  const met = h('select', { 'aria-label': 'Método del pago inicial' }, ...opciones(S.ajustes.metodosPago.map((m) => [m, m])));
  modal({
    titulo: `Nuevo paquete · ${nombrePaciente(p)}`,
    contenido: h('div', null,
      campo('Nombre del paquete', nombre),
      h('div', { class: 'form-grid' }, campo('Cantidad de sesiones', cant), campo('Precio', precio), campo('Moneda', mon), campo('Fecha de compra', compra), campo('Vigencia hasta (opcional)', vig)),
      h('fieldset', { class: 'card' }, h('legend', null, 'Pago recibido ahora (opcional)'), h('div', { class: 'form-grid' }, campo('Importe pagado ahora', pagoImp, 'Déjalo vacío si aún no ha pagado.'), campo('Método', met)))),
    acciones: [
      { texto: 'Cancelar' },
      {
        texto: 'Crear paquete',
        clase: 'primario',
        onClick: async () => {
          await S.svc.crearPaquete({ patientId, nombre: nombre.value, cantidadInicial: cant.value, precio: precio.value, moneda: mon.value, fechaCompra: compra.value, vigencia: vig.value }, pagoImp.value ? { importe: pagoImp.value, metodo: met.value, fecha: compra.value } : null);
          await refrescar();
          aviso('Paquete creado.', 'ok');
        },
      },
    ],
  });
}

export function formAjustePaquete(k) {
  const cant = h('input', { type: 'number', step: 1, value: -1 });
  const mot = h('input', { type: 'text', maxlength: 200 });
  const s = saldoPaquete(k, S.data.movements);
  modal({
    titulo: `Ajuste manual · ${k.nombre}`,
    contenido: h('div', null, h('p', null, `Disponibles ahora: ${s.disponibles} de ${s.iniciales}.`), campo('Ajuste de sesiones (positivo suma, negativo resta)', cant), campo('Motivo (obligatorio)', mot)),
    acciones: [
      { texto: 'Cancelar' },
      {
        texto: 'Aplicar ajuste',
        clase: 'primario',
        onClick: async () => {
          const ok = await confirmar({ titulo: 'Confirmar ajuste', mensaje: `Se registrará un ajuste de ${cant.value} sesión(es) con el motivo "${mot.value}". Queda en el historial del paquete.`, confirmar: 'Aplicar' });
          if (!ok) return false;
          await S.svc.ajustarPaquete(k.id, cant.value, mot.value);
          await refrescar();
          aviso('Ajuste registrado.', 'ok');
        },
      },
    ],
  });
}

export function formPlan(patientId, plan = null) {
  const p = pacienteDe(patientId);
  const hoyS = hoy();
  const tipo = h('select', null, ...opciones([['semanal', 'Semanal'], ['mensual', 'Mensual'], ['otro', 'Otro período']], plan?.tipo || 'mensual'));
  const imp = h('input', { type: 'number', min: 0, step: '0.01', value: plan?.importe ?? '' });
  const mon = h('select', null, ...opciones(S.ajustes.monedas.map((m) => [m, m]), plan?.moneda || p.moneda));
  const desde = h('input', { type: 'date', value: plan?.desde || startOfMonth(hoyS) });
  const hasta = h('input', { type: 'date', value: plan?.hasta || endOfMonth(hoyS) });
  const nota = h('input', { type: 'text', value: plan?.nota || '', maxlength: 150 });
  tipo.addEventListener('change', () => {
    if (plan) return;
    if (tipo.value === 'semanal') {
      desde.value = startOfWeek(hoyS);
      hasta.value = addDays(desde.value, 6);
    } else if (tipo.value === 'mensual') {
      desde.value = startOfMonth(hoyS);
      hasta.value = endOfMonth(hoyS);
    }
  });
  modal({
    titulo: `${plan ? 'Editar' : 'Nuevo'} cobro por período · ${nombrePaciente(p)}`,
    contenido: h('div', null, h('div', { class: 'form-grid' }, campo('Tipo', tipo), campo('Importe a cobrar', imp), campo('Moneda', mon), campo('Desde', desde), campo('Hasta', hasta)), campo('Nota (opcional)', nota)),
    acciones: [
      { texto: 'Cancelar' },
      {
        texto: 'Guardar',
        clase: 'primario',
        onClick: async () => {
          const d = { patientId, tipo: tipo.value, importe: imp.value, moneda: mon.value, desde: desde.value, hasta: hasta.value, nota: nota.value };
          if (plan) await S.svc.actualizarPlan(plan.id, d);
          else await S.svc.crearPlan(d);
          await refrescar();
          aviso('Cobro por período guardado.', 'ok');
        },
      },
    ],
  });
}

// ------------------------------------------------------------------ Tablas reutilizables

export function tablaPagos(pagos, { acciones = true, mostrarPaciente = true } = {}) {
  if (!pagos.length) return h('p', { class: 'vacio' }, 'Aún no hay pagos registrados.');
  return h('div', { class: 'tabla-wrap' }, h('table', { class: 'tabla' },
    h('thead', null, h('tr', null, h('th', null, 'Fecha'), mostrarPaciente ? h('th', null, 'Paciente') : null, h('th', null, 'Concepto'), h('th', null, 'Método'), h('th', { class: 'num' }, 'Importe'), h('th', null, 'Estado'), acciones ? h('th', null, '') : null)),
    h('tbody', null, ...pagos.map((p) => h('tr', { class: p.anulado ? 'anulado' : '' },
      h('td', null, p.fecha), mostrarPaciente ? h('td', null, nombrePaciente(pacienteDe(p.patientId))) : null,
      h('td', null, p.concepto || '—', p.nota ? h('small', { class: 'muted' }, ` (${p.nota})`) : null), h('td', null, p.metodo), h('td', { class: 'num' }, fmtMoney(p.importe, p.moneda)),
      h('td', null, p.anulado ? h('span', null, 'Anulado', h('small', { class: 'muted' }, ` · ${p.motivoAnulacion || ''}`)) : p.corrige ? 'Corrección' : 'Válido'),
      acciones ? h('td', null, p.anulado ? null : h('div', { class: 'row' },
        h('button', { type: 'button', class: 'chico', onClick: () => formPago({ corregir: p }) }, 'Corregir'),
        h('button', { type: 'button', class: 'chico peligro', onClick: () => anularPagoUI(p) }, 'Anular'))) : null)))));
}

export function tarjetaPaquete(k, { acciones = true } = {}) {
  const s = saldoPaquete(k, S.data.movements);
  const est = estadoPaquete(k, S.data.movements, hoy());
  const pct = Math.max(0, Math.min(100, (s.disponibles / s.iniciales) * 100));
  return h('div', { class: 'card' },
    h('div', { class: 'row between' }, h('strong', null, k.nombre), h('span', { class: `badge ${est}` }, est[0].toUpperCase() + est.slice(1))),
    h('div', { class: 'muted' }, `${nombrePaciente(pacienteDe(k.patientId))} · comprado ${k.fechaCompra}${k.vigencia ? ` · vigente hasta ${k.vigencia}` : ''} · ${fmtMoney(k.precio, k.moneda)}`),
    h('div', { class: 'progreso', role: 'img', 'aria-label': `${s.disponibles} de ${s.iniciales} disponibles` }, h('i', { style: `width:${pct}%` })),
    h('p', null, `Iniciales: ${s.iniciales} · Consumidas: ${s.consumidas} · `, h('strong', null, `Disponibles: ${s.disponibles}`), s.ajustes ? ` · Ajustes: ${s.ajustes > 0 ? '+' : ''}${s.ajustes}` : ''),
    acciones ? h('div', { class: 'row' },
      h('button', { type: 'button', class: 'chico', onClick: () => formAjustePaquete(k) }, 'Ajuste manual'),
      h('button', { type: 'button', class: 'chico', onClick: () => ejecutar(() => S.svc.cerrarPaquete(k.id, k.estado !== 'cerrado'), k.estado === 'cerrado' ? 'Paquete reabierto.' : 'Paquete cerrado.') }, k.estado === 'cerrado' ? 'Reabrir' : 'Cerrar paquete'),
      h('details', { class: 'det' }, h('summary', null, 'Movimientos'),
        h('ul', null, ...S.data.movements.filter((m) => m.packageId === k.id).sort((a, b) => a.createdAt.localeCompare(b.createdAt)).map((m) => h('li', null, `${m.fecha} · ${m.tipo} ${m.cantidad > 0 && m.tipo === 'ajuste' ? '+' : ''}${m.cantidad} · ${m.motivo}`))))) : null);
}

// ------------------------------------------------------------------ Vista

function rangoPreset(p) {
  const t = hoy();
  if (p === 'hoy') return [t, t];
  if (p === 'semana') return [startOfWeek(t), addDays(startOfWeek(t), 6)];
  if (p === 'mes') return [startOfMonth(t), endOfMonth(t)];
  if (p === 'mes_ant') {
    const a = addMonths(t, -1);
    return [a, endOfMonth(a)];
  }
  return null;
}

export function vistaPagos(cont) {
  const tabs = [['pagos', 'Pagos'], ['saldos', 'Saldos'], ['paquetes', 'Paquetes'], ['reportes', 'Reportes']];
  const t = S.pagos.tab;
  anexar(cont, 
    h('div', { class: 'page-head' }, h('h1', null, 'Pagos y reportes'), h('button', { type: 'button', class: 'primario', onClick: () => formPago() }, icono('plus'), 'Registrar pago')),
    h('div', { class: 'seg', role: 'group', 'aria-label': 'Secciones', style: 'margin-bottom:12px' }, ...tabs.map(([k, n]) => h('button', { type: 'button', 'aria-pressed': t === k, onClick: () => { S.pagos.tab = k; S.render(); } }, n))));
  if (t === 'pagos') anexar(cont, seccionPagos());
  else if (t === 'saldos') anexar(cont, seccionSaldos());
  else if (t === 'paquetes') anexar(cont, seccionPaquetes());
  else anexar(cont, seccionReportes());
}

function seccionPagos() {
  const f = S.pagos;
  const selP = h('select', { 'aria-label': 'Filtrar por paciente', onChange: (e) => { f.paciente = e.target.value; S.render(); } }, h('option', { value: '' }, 'Todos los pacientes'), ...opciones(S.data.patients.map((p) => [p.id, nombrePaciente(p)]), f.paciente));
  const d = h('input', { type: 'date', value: f.desde, 'aria-label': 'Desde', onChange: (e) => { f.desde = e.target.value; S.render(); } });
  const a = h('input', { type: 'date', value: f.hasta, 'aria-label': 'Hasta', onChange: (e) => { f.hasta = e.target.value; S.render(); } });
  const lista = S.data.payments.filter((p) => (!f.paciente || p.patientId === f.paciente) && (!f.desde || p.fecha >= f.desde) && (!f.hasta || p.fecha <= f.hasta)).sort((x, y) => (y.fecha + y.createdAt).localeCompare(x.fecha + x.createdAt));
  const tot = totalPorMoneda(lista, '0000-01-01', '9999-12-31');
  return h('div', null,
    h('div', { class: 'filtros' }, selP, h('label', { class: 'campo' }, h('span', null, 'Desde'), d), h('label', { class: 'campo' }, h('span', null, 'Hasta'), a)),
    h('div', { class: 'card' }, h('div', { class: 'row between' }, h('div', { class: 'kpi' }, h('span', { class: 'v' }, money(tot)), h('span', { class: 'l' }, 'Total cobrado en el filtro (pagos válidos, por moneda)')),
      h('button', { type: 'button', onClick: () => descargarCSV(`pagos-${hoy()}.csv`, csvPagos(lista)) }, icono('download'), 'Exportar CSV')),
    tablaPagos(lista)));
}

const csvPagos = (lista) =>
  aCSV([
    { titulo: 'Fecha', valor: 'fecha' }, { titulo: 'Paciente', valor: (p) => nombrePaciente(pacienteDe(p.patientId)) }, { titulo: 'Concepto', valor: 'concepto' },
    { titulo: 'Método', valor: 'metodo' }, { titulo: 'Moneda', valor: 'moneda' }, { titulo: 'Importe', valor: (p) => p.importe.toFixed(2) },
    { titulo: 'Estado', valor: (p) => (p.anulado ? 'Anulado' : 'Válido') }, { titulo: 'Motivo de anulación', valor: 'motivoAnulacion' }, { titulo: 'Nota', valor: 'nota' },
  ], lista);

function seccionSaldos() {
  const lista = saldosPendientes(S.data, S.ajustes).sort((a, b) => nombrePaciente(a.patient).localeCompare(nombrePaciente(b.patient)));
  const total = {};
  for (const x of lista) for (const [m, v] of Object.entries(x.porMoneda)) total[m] = (total[m] || 0) + v;
  return h('div', null,
    h('div', { class: 'card' }, h('div', { class: 'kpi' }, h('span', { class: 'v' }, money(total)), h('span', { class: 'l' }, 'Saldo pendiente total (por moneda). No incluye sesiones futuras ni importes estimados.'))),
    lista.length ? lista.map((x) => h('div', { class: 'card' }, h('div', { class: 'row between' },
      h('div', null, h('strong', null, nombrePaciente(x.patient)), h('div', { class: 'muted' }, `Pendiente: ${money(x.porMoneda)}`)),
      h('div', { class: 'row' },
        h('button', { type: 'button', class: 'chico', onClick: () => formPago({ patientId: x.patient.id }) }, 'Registrar pago'),
        h('button', { type: 'button', class: 'chico', onClick: () => abrirWhatsApp({ paciente: x.patient, clave: 'saldo' }) }, icono('chat'), 'WhatsApp saldo'),
        h('a', { class: 'btn chico', href: `#/pacientes/${x.patient.id}` }, 'Ver ficha'))))) : h('p', { class: 'vacio' }, 'No hay saldos pendientes.'));
}

function seccionPaquetes() {
  const ks = S.data.packages.slice().sort((a, b) => b.fechaCompra.localeCompare(a.fechaCompra));
  return ks.length ? h('div', { class: 'grid c2' }, ...ks.map((k) => tarjetaPaquete(k))) : h('p', { class: 'vacio' }, 'No hay paquetes. Créalos desde la ficha de un paciente.');
}

function seccionReportes() {
  const r = S.reportes;
  if (r.preset !== 'personalizado') [r.desde, r.hasta] = rangoPreset(r.preset);
  const presets = [['hoy', 'Hoy'], ['semana', 'Esta semana'], ['mes', 'Este mes'], ['mes_ant', 'Mes anterior'], ['personalizado', 'Personalizado']];
  const citas = S.data.appointments.filter((a) => a.fecha >= r.desde && a.fecha <= r.hasta && (!r.paciente || a.patientId === r.paciente));
  const pagos = S.data.payments.filter((p) => (!r.paciente || p.patientId === r.paciente));
  const porEstado = {};
  for (const a of citas) porEstado[a.estado] = (porEstado[a.estado] || 0) + 1;
  const cobrado = totalPorMoneda(pagos, r.desde, r.hasta);
  const proy = proyectado(citas.filter((a) => a.fecha > hoy()), r.desde, r.hasta);
  const pend = {};
  for (const p of S.data.patients) {
    if (r.paciente && p.id !== r.paciente) continue;
    for (const [m, v] of Object.entries(libroPaciente(p.id, S.data, S.ajustes).porMoneda)) if (v.pendiente > 0) pend[m] = (pend[m] || 0) + v.pendiente;
  }
  const grupos = ingresosPorPeriodo(pagos, r.desde, r.hasta, r.gran);
  const claves = Object.keys(grupos).sort();
  const nombreClave = (k) => (r.gran === 'mes' ? fmtMes(k + '-01') : r.gran === 'semana' ? `Semana del ${fmtFechaCorta(k)}` : fmtFechaCorta(k));
  const set = (campoR) => (e) => { r[campoR] = e.target.value; if (campoR === 'desde' || campoR === 'hasta') r.preset = 'personalizado'; S.render(); };
  return h('div', null,
    h('div', { class: 'row', style: 'margin-bottom:10px' }, ...presets.map(([k, n]) => h('button', { type: 'button', class: 'chico', 'aria-pressed': r.preset === k, onClick: () => { r.preset = k; S.render(); } }, n))),
    h('div', { class: 'filtros' },
      h('label', { class: 'campo' }, h('span', null, 'Desde'), h('input', { type: 'date', value: r.desde, onChange: set('desde') })),
      h('label', { class: 'campo' }, h('span', null, 'Hasta'), h('input', { type: 'date', value: r.hasta, onChange: set('hasta') })),
      h('label', { class: 'campo' }, h('span', null, 'Paciente'), h('select', { onChange: set('paciente') }, h('option', { value: '' }, 'Todos'), ...opciones(S.data.patients.map((p) => [p.id, nombrePaciente(p)]), r.paciente))),
      h('label', { class: 'campo' }, h('span', null, 'Agrupar ingresos por'), h('select', { onChange: set('gran') }, ...opciones([['dia', 'Día'], ['semana', 'Semana'], ['mes', 'Mes']], r.gran)))),
    h('p', { class: 'muted' }, `Período: ${r.desde} a ${r.hasta}. Los importes se muestran por moneda y no se suman entre monedas distintas.`),
    h('div', { class: 'grid c3' },
      h('div', { class: 'card kpi' }, h('span', { class: 'v' }, String(porEstado.realizada || 0)), h('span', { class: 'l' }, 'Sesiones realizadas')),
      h('div', { class: 'card kpi' }, h('span', { class: 'v' }, money(cobrado)), h('span', { class: 'l' }, 'Cobrado (pagos registrados)')),
      h('div', { class: 'card kpi' }, h('span', { class: 'v' }, money(pend)), h('span', { class: 'l' }, 'Saldo pendiente actual')),
      h('div', { class: 'card kpi' }, h('span', { class: 'v' }, money(proy)), h('span', { class: 'l' }, 'Proyectado de sesiones futuras (NO cobrado)'))),
    h('div', { class: 'card' }, h('h3', null, 'Citas por estado'), Object.keys(porEstado).length ? h('p', null, Object.entries(porEstado).map(([e, n]) => `${ESTADOS[e].label}: ${n}`).join(' · ')) : h('p', { class: 'muted' }, 'Sin citas en el período.')),
    h('div', { class: 'card' }, h('h3', null, 'Ingresos recibidos'), claves.length
      ? h('div', { class: 'tabla-wrap' }, h('table', { class: 'tabla' }, h('thead', null, h('tr', null, h('th', null, 'Período'), h('th', { class: 'num' }, 'Cobrado'))), h('tbody', null, ...claves.map((k) => h('tr', null, h('td', null, nombreClave(k)), h('td', { class: 'num' }, money(grupos[k])))))))
      : h('p', { class: 'muted' }, 'No hay pagos registrados en el período.')),
    h('div', { class: 'row' },
      h('button', { type: 'button', onClick: () => descargarCSV(`pagos-${r.desde}_${r.hasta}.csv`, csvPagos(pagos.filter((p) => p.fecha >= r.desde && p.fecha <= r.hasta))) }, icono('download'), 'Exportar pagos (CSV)'),
      h('button', { type: 'button', onClick: () => descargarCSV(`citas-${r.desde}_${r.hasta}.csv`, csvCitas(citas)) }, icono('download'), 'Exportar citas (CSV)'),
      h('button', { type: 'button', onClick: () => descargarCSV(`saldos-${hoy()}.csv`, csvSaldos()) }, icono('download'), 'Exportar saldos (CSV)')));
}

const csvCitas = (lista) =>
  aCSV([
    { titulo: 'Fecha', valor: 'fecha' }, { titulo: 'Hora', valor: 'inicio' }, { titulo: 'Duración (min)', valor: 'duracion' }, { titulo: 'Paciente', valor: (a) => nombrePaciente(pacienteDe(a.patientId)) },
    { titulo: 'Estado', valor: (a) => ESTADOS[a.estado].label }, { titulo: 'Serie', valor: (a) => (a.seriesId ? 'Sí' : 'No') }, { titulo: 'Tarifa', valor: (a) => (a.modalidad === 'sesion' ? a.tarifa.toFixed(2) : '') }, { titulo: 'Moneda', valor: 'moneda' },
  ], lista.slice().sort((a, b) => (a.fecha + a.inicio).localeCompare(b.fecha + b.inicio)));

function csvSaldos() {
  const filas = [];
  for (const p of S.data.patients) for (const [m, v] of Object.entries(libroPaciente(p.id, S.data, S.ajustes).porMoneda)) filas.push({ p, m, v });
  return aCSV([
    { titulo: 'Paciente', valor: (f) => nombrePaciente(f.p) }, { titulo: 'Moneda', valor: 'm' }, { titulo: 'Cobros', valor: (f) => f.v.cargos.toFixed(2) },
    { titulo: 'Pagado', valor: (f) => f.v.pagado.toFixed(2) }, { titulo: 'Pendiente', valor: (f) => f.v.pendiente.toFixed(2) }, { titulo: 'A favor', valor: (f) => f.v.aFavor.toFixed(2) },
  ], filas);
}
