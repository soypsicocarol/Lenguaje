// Lista y ficha de pacientes.
import { MODALIDADES } from '../core/constants.js';
import { formatAge, fmtFechaCorta } from '../core/dates.js';
import { estadoPaquete, libroPaciente, saldoPaquete } from '../core/finance.js';
import { normalizarTelefono } from '../core/whatsapp.js';
import { fmtMoney, normText } from '../core/util.js';
import { aviso, campo, confirmar, h, icono, modal, opciones, anexar } from './dom.js';
import { S, ejecutar, hoy, nombrePaciente, pacienteDe, refrescar } from './state.js';
import { badge, detalleCita, formCita, formSerie, rango } from './citas.js';
import { formPago, formPaquete, formPlan, tablaPagos, tarjetaPaquete } from './pagos.js';
import { abrirWhatsApp } from './whatsapp.js';

const money = (o) => Object.entries(o).filter(([, v]) => v > 0).map(([m, v]) => fmtMoney(v, m)).join(' · ');

export function formPaciente(p = null) {
  const v = p || {};
  const nombre = h('input', { type: 'text', value: v.nombre || '', required: true, autocomplete: 'off' });
  const apellidos = h('input', { type: 'text', value: v.apellidos || '', autocomplete: 'off' });
  const nac = h('input', { type: 'date', value: v.fechaNacimiento || '', max: hoy() });
  const edad = h('small', { class: 'muted' }, v.fechaNacimiento ? `Edad: ${formatAge(v.fechaNacimiento, hoy())}` : '');
  nac.addEventListener('input', () => (edad.textContent = nac.value ? `Edad: ${formatAge(nac.value, hoy())}` : ''));
  const rep = h('input', { type: 'text', value: v.representante || '', required: true, autocomplete: 'off' });
  const tel = h('input', { type: 'tel', value: v.telefono || '', placeholder: '+58 414 0000000' });
  const telAyuda = h('small', { class: 'muted' });
  const actTel = () => {
    if (!tel.value.trim()) return (telAyuda.textContent = 'Incluye el código de país. Se usa para abrir WhatsApp.');
    const n = normalizarTelefono(tel.value, S.ajustes.codigoPais);
    telAyuda.textContent = n.ok ? `Se guardará como ${n.e164}` : n.error;
  };
  tel.addEventListener('input', actTel);
  actTel();
  const ing = h('input', { type: 'date', value: v.fechaIngreso || hoy() });
  const frec = h('input', { type: 'text', value: v.frecuencia || '', placeholder: 'Ej.: 2 veces por semana' });
  const mod = h('select', null, ...opciones(Object.entries(MODALIDADES), v.modalidadCobro || 'sesion'));
  const tar = h('input', { type: 'number', min: 0, step: '0.01', value: v.tarifa ?? S.ajustes.tarifaPredeterminada });
  const mon = h('select', null, ...opciones(S.ajustes.monedas.map((m) => [m, m]), v.moneda || S.ajustes.moneda));
  const obs = h('textarea', { rows: 3, maxlength: 400 });
  obs.value = v.notasAdministrativas || '';
  modal({
    titulo: p ? 'Editar paciente' : 'Nuevo paciente',
    ancho: true,
    contenido: h('div', null,
      h('div', { class: 'form-grid' }, campo('Nombre del niño o niña', nombre), campo('Apellidos', apellidos), h('div', null, campo('Fecha de nacimiento', nac), edad)),
      h('div', { class: 'form-grid' }, campo('Representante responsable', rep), h('div', null, campo('Teléfono (con código de país)', tel), telAyuda), campo('Fecha de ingreso', ing)),
      h('div', { class: 'form-grid' }, campo('Frecuencia habitual de atención', frec), campo('Modalidad de cobro', mod), campo('Tarifa predeterminada', tar), campo('Moneda', mon)),
      campo('Observaciones administrativas', obs, 'Solo datos de organización (horarios, preferencias de contacto). No es una historia clínica.')),
    acciones: [
      { texto: 'Cancelar' },
      {
        texto: p ? 'Guardar cambios' : 'Crear paciente',
        clase: 'primario',
        onClick: async () => {
          const datos = { nombre: nombre.value, apellidos: apellidos.value, fechaNacimiento: nac.value, representante: rep.value, telefono: tel.value, fechaIngreso: ing.value, frecuencia: frec.value, modalidadCobro: mod.value, tarifa: tar.value, moneda: mon.value, notasAdministrativas: obs.value };
          const r = p ? await S.svc.actualizarPaciente(p.id, datos) : await S.svc.crearPaciente(datos);
          await refrescar();
          aviso(p ? 'Paciente actualizado.' : 'Paciente creado.', 'ok');
          if (!p) location.hash = `#/pacientes/${r.id}`;
        },
      },
    ],
  });
}

function proximaCita(p) {
  const t = hoy();
  return S.data.appointments.filter((a) => a.patientId === p.id && a.fecha >= t && ['programada', 'confirmada'].includes(a.estado)).sort((a, b) => (a.fecha + a.inicio).localeCompare(b.fecha + b.inicio))[0];
}

export function vistaPacientes(cont) {
  const F = S.pacientes;
  const t = normText(F.texto);
  const lista = S.data.patients
    .filter((p) => (F.filtro === 'todos' ? true : F.filtro === 'activos' ? p.estado === 'activo' : p.estado === 'inactivo'))
    .filter((p) => !t || normText(nombrePaciente(p) + ' ' + p.representante).includes(t))
    .sort((a, b) => nombrePaciente(a).localeCompare(nombrePaciente(b)));
  anexar(cont, 
    h('div', { class: 'page-head' }, h('h1', null, 'Pacientes'), h('button', { type: 'button', class: 'primario', onClick: () => formPaciente() }, icono('plus'), 'Nuevo paciente')),
    h('div', { class: 'filtros' },
      h('input', { type: 'search', placeholder: 'Buscar por nombre o representante…', 'aria-label': 'Buscar paciente', value: F.texto, onInput: (e) => { F.texto = e.target.value; clearTimeout(vistaPacientes.t); vistaPacientes.t = setTimeout(() => { S.render(); const el = document.querySelector('input[type=search]'); if (el) { el.focus(); el.setSelectionRange(el.value.length, el.value.length); } }, 250); } }),
      h('select', { 'aria-label': 'Filtrar por estado', onChange: (e) => { F.filtro = e.target.value; S.render(); } }, ...opciones([['activos', 'Activos'], ['inactivos', 'Inactivos'], ['todos', 'Todos']], F.filtro))),
    h('div', null, lista.length ? lista.map((p) => {
      const l = libroPaciente(p.id, S.data, S.ajustes);
      const pend = money(Object.fromEntries(Object.entries(l.porMoneda).map(([m, v]) => [m, v.pendiente])));
      const nx = proximaCita(p);
      return h('a', { class: 'item paciente', href: `#/pacientes/${p.id}`, style: 'text-decoration:none;color:inherit' },
        h('span', { class: 'cuerpo' }, h('strong', null, nombrePaciente(p)),
          h('small', null, [p.fechaNacimiento ? formatAge(p.fechaNacimiento, hoy()) : null, p.representante, nx ? `Próxima: ${fmtFechaCorta(nx.fecha)} ${nx.inicio}` : 'Sin próxima cita'].filter(Boolean).join(' · '))),
        pend ? h('span', { class: 'badge pendiente' }, `Debe ${pend}`) : null,
        p.estado === 'inactivo' ? h('span', { class: 'badge inactivo' }, 'Inactivo') : null);
    }) : h('div', { class: 'vacio' }, h('p', null, S.data.patients.length ? 'Ningún paciente coincide con el filtro.' : 'Aún no hay pacientes. Crea el primero para empezar a agendar.'))));
}

export function fichaPaciente(cont, id) {
  const p = pacienteDe(id);
  if (!p) {
    anexar(cont, h('div', { class: 'vacio' }, h('p', null, 'No se encontró el paciente.'), h('a', { class: 'btn', href: '#/pacientes' }, 'Volver a pacientes')));
    return;
  }
  const lib = libroPaciente(p.id, S.data, S.ajustes);
  const citas = S.data.appointments.filter((a) => a.patientId === p.id).sort((a, b) => (b.fecha + b.inicio).localeCompare(a.fecha + a.inicio));
  const t = hoy();
  const proximas = citas.filter((a) => a.fecha >= t && ['programada', 'confirmada'].includes(a.estado)).reverse();
  const historial = citas.filter((a) => !proximas.includes(a)).slice(0, 40);
  const pagos = S.data.payments.filter((x) => x.patientId === p.id).sort((a, b) => (b.fecha + b.createdAt).localeCompare(a.fecha + a.createdAt));
  const paquetes = S.data.packages.filter((k) => k.patientId === p.id);
  const planes = S.data.plans.filter((x) => x.patientId === p.id);
  const pend = Object.fromEntries(Object.entries(lib.porMoneda).map(([m, v]) => [m, v.pendiente]));
  const favor = Object.fromEntries(Object.entries(lib.porMoneda).map(([m, v]) => [m, v.aFavor]));
  const cobrado = {};
  for (const x of pagos.filter((y) => !y.anulado)) cobrado[x.moneda] = (cobrado[x.moneda] || 0) + x.importe;

  const filaCita = (a) => h('button', { type: 'button', class: `item st-${a.estado}`, onClick: () => detalleCita(a.id) }, h('span', { class: 'hora' }, fmtFechaCorta(a.fecha)), h('span', { class: 'cuerpo' }, h('strong', null, rango(a)), h('small', null, `${a.duracion} min${a.seriesId ? ' · serie' : ''}`)), badge(a.estado));

  anexar(cont, 
    h('p', null, h('a', { href: '#/pacientes' }, '← Pacientes')),
    h('div', { class: 'page-head' },
      h('div', null, h('h1', null, nombrePaciente(p)), h('div', { class: 'muted' }, [p.fechaNacimiento ? `${formatAge(p.fechaNacimiento, t)} (nac. ${p.fechaNacimiento})` : null, p.estado === 'inactivo' ? 'Inactivo' : 'Activo'].filter(Boolean).join(' · '))),
      h('div', { class: 'row' },
        h('button', { type: 'button', class: 'primario', onClick: () => formCita({ patientId: p.id }) }, icono('plus'), 'Nueva cita'),
        h('button', { type: 'button', onClick: () => formSerie({ patientId: p.id }) }, icono('repeat'), 'Serie semanal'),
        h('button', { type: 'button', onClick: () => abrirWhatsApp({ paciente: p, clave: 'recordatorio' }) }, icono('chat'), 'WhatsApp'),
        h('button', { type: 'button', onClick: () => formPaciente(p) }, icono('edit'), 'Editar'))),
    h('div', { class: 'grid c2' },
      h('div', { class: 'card' }, h('h2', null, 'Datos administrativos'),
        h('p', null, h('strong', null, 'Representante: '), p.representante),
        h('p', null, h('strong', null, 'Teléfono: '), p.telefono || 'Sin teléfono'),
        h('p', null, h('strong', null, 'Ingreso: '), p.fechaIngreso, p.frecuencia ? ` · ${p.frecuencia}` : ''),
        h('p', null, h('strong', null, 'Cobro: '), `${MODALIDADES[p.modalidadCobro]} · tarifa ${fmtMoney(p.tarifa, p.moneda)}`),
        p.notasAdministrativas ? h('p', null, h('strong', null, 'Observaciones: '), p.notasAdministrativas) : null),
      h('div', { class: 'card' }, h('h2', null, 'Resumen de pagos'),
        h('div', { class: 'row between' }, h('div', { class: 'kpi' }, h('span', { class: 'v' }, money(pend) || 'Sin saldo'), h('span', { class: 'l' }, 'Saldo pendiente')), h('div', { class: 'kpi' }, h('span', { class: 'v' }, money(cobrado) || '—'), h('span', { class: 'l' }, 'Cobrado en total'))),
        money(favor) ? h('p', { class: 'aviso ok' }, `Saldo a favor: ${money(favor)}`) : null,
        h('div', { class: 'row' },
          h('button', { type: 'button', class: 'primario', onClick: () => formPago({ patientId: p.id }) }, icono('wallet'), 'Registrar pago'),
          money(pend) ? h('button', { type: 'button', onClick: () => abrirWhatsApp({ paciente: p, clave: 'saldo' }) }, icono('chat'), 'Enviar saldo') : null))),
    lib.obligaciones.some((o) => o.pendiente > 0) ? h('div', { class: 'card' }, h('h2', null, 'Cobros pendientes'),
      h('div', { class: 'tabla-wrap' }, h('table', { class: 'tabla' }, h('tbody', null, ...lib.obligaciones.filter((o) => o.pendiente > 0).map((o) => h('tr', null, h('td', null, o.concepto), h('td', null, h('span', { class: `badge ${o.estado}` }, o.estado === 'parcial' ? 'Parcial' : 'Pendiente')), h('td', { class: 'num' }, `${fmtMoney(o.pendiente, o.moneda)} de ${fmtMoney(o.importe, o.moneda)}`))))))) : null,
    h('div', { class: 'card' }, h('div', { class: 'row between' }, h('h2', null, 'Paquetes de sesiones'), h('button', { type: 'button', class: 'chico', onClick: () => formPaquete(p.id) }, icono('plus'), 'Nuevo paquete')),
      paquetes.length ? h('div', { class: 'grid c2' }, ...paquetes.map((k) => tarjetaPaquete(k))) : h('p', { class: 'muted' }, 'Sin paquetes.')),
    h('div', { class: 'card' }, h('div', { class: 'row between' }, h('h2', null, 'Cobros por período'), h('button', { type: 'button', class: 'chico', onClick: () => formPlan(p.id) }, icono('plus'), 'Nuevo cobro por período')),
      planes.length ? h('div', { class: 'tabla-wrap' }, h('table', { class: 'tabla' }, h('tbody', null, ...planes.map((x) => {
        const o = lib.obligaciones.find((q) => q.tipo === 'plan' && q.id === x.id);
        return h('tr', null, h('td', null, `${x.tipo} · ${x.desde} a ${x.hasta}${x.nota ? ' · ' + x.nota : ''}`), h('td', { class: 'num' }, fmtMoney(x.importe, x.moneda)), h('td', null, x.estado === 'anulado' ? h('span', { class: 'badge inactivo' }, 'Anulado') : o ? h('span', { class: `badge ${o.estado}` }, o.estado) : ''),
          h('td', null, h('div', { class: 'row' }, h('button', { type: 'button', class: 'chico', onClick: () => formPlan(p.id, x) }, 'Editar'), x.estado !== 'anulado' ? h('button', { type: 'button', class: 'chico peligro', onClick: async () => { if (await confirmar({ titulo: 'Anular cobro por período', mensaje: 'El cobro dejará de contarse como pendiente. Los pagos asociados se conservan como abonos generales.', confirmar: 'Anular', peligro: true })) ejecutar(() => S.svc.cambiarEstadoPlan(x.id, 'anulado'), 'Cobro anulado.'); } }, 'Anular') : null)));
      })))) : h('p', { class: 'muted' }, 'Sin cobros por período.')),
    h('div', { class: 'card' }, h('h2', null, `Próximas citas (${proximas.length})`), proximas.length ? proximas.slice(0, 30).map(filaCita) : h('p', { class: 'muted' }, 'Sin citas próximas.')),
    h('div', { class: 'card' }, h('h2', null, 'Historial de citas'), historial.length ? historial.map(filaCita) : h('p', { class: 'muted' }, 'Sin historial.')),
    h('div', { class: 'card' }, h('h2', null, 'Pagos'), tablaPagos(pagos, { mostrarPaciente: false })),
    h('div', { class: 'card' }, h('h2', null, 'Estado del paciente'),
      h('div', { class: 'row' },
        h('button', { type: 'button', onClick: () => ejecutar(() => S.svc.cambiarEstadoPaciente(p.id, p.estado !== 'activo'), p.estado === 'activo' ? 'Paciente inactivado. El historial se conserva.' : 'Paciente activado.') }, p.estado === 'activo' ? 'Inactivar paciente' : 'Activar paciente'),
        h('button', { type: 'button', class: 'peligro', onClick: () => eliminarUI(p) }, icono('trash'), 'Eliminar definitivamente')),
      h('p', { class: 'muted' }, 'Se recomienda inactivar en lugar de eliminar: así se conserva el historial de citas y pagos.')));
}

async function eliminarUI(p) {
  const hu = await S.svc.huellaPaciente(p.id);
  const ok = await confirmar({
    titulo: 'Eliminar paciente definitivamente',
    mensaje: h('div', null,
      h('p', null, `Se borrará a ${nombrePaciente(p)} y todo su historial en este dispositivo: ${hu.citas} cita(s), ${hu.series} serie(s), ${hu.pagos} pago(s), ${hu.cobros} cobro(s) por período, ${hu.paquetes} paquete(s) y ${hu.movimientos} movimiento(s) de paquete.`),
      h('p', null, h('strong', null, 'No se puede deshacer.'), ' Si dudas, exporta un respaldo antes o usa "Inactivar paciente".')),
    confirmar: 'Eliminar todo', peligro: true, escribir: 'ELIMINAR',
  });
  if (!ok) return;
  if (await ejecutar(() => S.svc.eliminarPaciente(p.id), 'Paciente eliminado.')) location.hash = '#/pacientes';
}
