// Utilidades de interfaz: construcción segura del DOM (sin innerHTML con datos), iconos, diálogos y avisos.

const SVG = 'http://www.w3.org/2000/svg';
const ICONOS = {
  home: 'M3 9.5 12 3l9 6.5V20a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z',
  calendar: 'M8 2v4M16 2v4M3 10h18M5 4h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2z',
  users: 'M17 21v-2a4 4 0 0 0-4-4H7a4 4 0 0 0-4 4v2M10 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM21 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75',
  wallet: 'M3 7a2 2 0 0 1 2-2h14v4M3 7v12a2 2 0 0 0 2 2h16V9H5a2 2 0 0 1-2-2zM17 15h.01',
  settings: 'M4 21v-7M4 10V3M12 21v-9M12 8V3M20 21v-5M20 12V3M1 14h6M9 8h6M17 16h6',
  plus: 'M12 5v14M5 12h14',
  left: 'm15 18-6-6 6-6',
  right: 'm9 18 6-6-6-6',
  x: 'M18 6 6 18M6 6l12 12',
  check: 'M20 6 9 17l-5-5',
  chat: 'M21 11.5a8.4 8.4 0 0 1-9 8.4 8.5 8.5 0 0 1-3.8-.9L3 20l1.1-4.9A8.4 8.4 0 0 1 3 11.5 8.5 8.5 0 0 1 12 3a8.4 8.4 0 0 1 9 8.5z',
  edit: 'M12 20h9M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z',
  trash: 'M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6M10 11v6M14 11v6',
  lock: 'M5 11h14v10H5zM8 11V7a4 4 0 0 1 8 0v4',
  download: 'M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3',
  upload: 'M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M17 8l-5-5-5 5M12 3v12',
  clock: 'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18zM12 7v5l3 2',
  alert: 'M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0zM12 9v4M12 17h.01',
  repeat: 'm17 2 4 4-4 4M3 11V9a3 3 0 0 1 3-3h15M7 22l-4-4 4-4M21 13v2a3 3 0 0 1-3 3H3',
  block: 'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18zM5.6 5.6l12.8 12.8',
  search: 'M11 19a8 8 0 1 0 0-16 8 8 0 0 0 0 16zM21 21l-4.3-4.3',
  info: 'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18zM12 16v-4M12 8h.01',
  user: 'M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2M12 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8z',
  package: 'M21 8 12 3 3 8v8l9 5 9-5zM3 8l9 5 9-5M12 13v8',
  shield: 'M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z',
  file: 'M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8zM14 2v6h6M8 13h8M8 17h8',
  ext: 'M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6M15 3h6v6M10 14 21 3',
  undo: 'M3 7v6h6M3 13a9 9 0 1 0 3-7.7L3 8',
};

export function icono(nombre) {
  const s = document.createElementNS(SVG, 'svg');
  s.setAttribute('viewBox', '0 0 24 24');
  s.setAttribute('class', 'ico');
  s.setAttribute('aria-hidden', 'true');
  for (const d of (ICONOS[nombre] || '').split(/(?=M)/)) {
    if (!d) continue;
    const p = document.createElementNS(SVG, 'path');
    p.setAttribute('d', d);
    s.append(p);
  }
  return s;
}

function agregar(el, hijos) {
  for (const h of hijos.flat(Infinity)) {
    if (h == null || h === false) continue;
    el.append(h instanceof Node ? h : document.createTextNode(String(h)));
  }
}

/** Agrega hijos ignorando null/false y aplanando arreglos (Element.append convertiría null en texto). */
export const anexar = (el, ...hijos) => agregar(el, hijos);

/** h('div', {class:'x', onClick: fn}, hijos...) */
export function h(tag, attrs, ...hijos) {
  const el = document.createElement(tag);
  let valor;
  if (attrs) {
    for (const [k, v] of Object.entries(attrs)) {
      if (v == null || v === false) continue;
      if (k === 'class') el.className = v;
      else if (k === 'value') valor = v;
      else if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2).toLowerCase(), v);
      else if (['checked', 'disabled', 'selected', 'readOnly', 'required', 'open'].includes(k)) el[k] = !!v;
      else el.setAttribute(k, v === true ? '' : v);
    }
  }
  agregar(el, hijos);
  if (valor !== undefined) el.value = valor;
  return el;
}

export const vaciar = (el) => {
  while (el.firstChild) el.removeChild(el.firstChild);
  return el;
};

/** Campo etiquetado: la etiqueta envuelve al control para que sea accesible y fácil de pulsar. */
export function campo(etiqueta, control, ayuda = null, clase = '') {
  return h('label', { class: 'campo ' + clase }, h('span', null, etiqueta), control, ayuda ? h('small', null, ayuda) : null);
}
export const check = (etiqueta, props = {}) => {
  const i = h('input', { type: 'checkbox', ...props });
  return Object.assign(h('label', { class: 'check' }, i, h('span', null, etiqueta)), { input: i });
};

export const opciones = (pares, sel) => pares.map(([v, t]) => h('option', { value: v, selected: v === sel }, t));

// ---------------------------------------------------------------- Avisos

export function aviso(msg, tipo = '') {
  const cont = document.getElementById('toasts');
  const t = h('div', { class: `toast ${tipo}`, role: tipo === 'error' ? 'alert' : 'status' }, msg);
  cont.append(t);
  setTimeout(() => t.remove(), tipo === 'error' || tipo === 'warn' ? 7000 : 3800);
}

export function mensajeError(e) {
  if (e && e.name === 'QuotaExceededError') return 'El almacenamiento del dispositivo está lleno. Libera espacio o exporta un respaldo y borra datos antiguos.';
  if (e && e.name === 'ValidationError') return e.message;
  return 'Ocurrió un error inesperado: ' + (e && e.message ? e.message : e);
}

// ---------------------------------------------------------------- Diálogos

/**
 * Abre un diálogo modal. contenido: Node. acciones: [{texto, clase, onClick(cerrar) -> false para no cerrar}]
 * Devuelve {el, cuerpo, cerrar, error(msg)}.
 */
export function modal({ titulo, contenido, acciones = [], ancho = false, alCerrar = null }) {
  const dlg = h('dialog', { class: ancho ? 'ancho' : '', 'aria-labelledby': 'dlg-t' });
  const cuerpo = h('div', { class: 'dlg-b' }, contenido);
  const err = h('div', { class: 'err', role: 'alert', hidden: true });
  const cerrar = () => {
    if (dlg.open) dlg.close();
  };
  const pie = h('div', { class: 'dlg-f' });
  for (const a of acciones) {
    const b = h('button', { type: 'button', class: a.clase || '', 'data-accion': a.texto, onClick: async () => {
      err.hidden = true;
      b.disabled = true;
      try {
        const r = a.onClick ? await a.onClick(cerrar, { error }) : undefined;
        if (r !== false) cerrar();
      } catch (e) {
        error(mensajeError(e));
      } finally {
        b.disabled = false;
      }
    } }, a.icono ? icono(a.icono) : null, a.texto);
    pie.append(b);
  }
  function error(msg) {
    err.textContent = msg;
    err.hidden = false;
    err.scrollIntoView({ block: 'nearest' });
  }
  dlg.append(
    h('div', { class: 'dlg' },
      h('div', { class: 'dlg-h' }, h('h2', { id: 'dlg-t' }, titulo), h('button', { type: 'button', class: 'icono', 'aria-label': 'Cerrar', onClick: cerrar }, icono('x'))),
      cuerpo,
      h('div', { style: 'padding:0 16px' }, err),
      acciones.length ? pie : null),
  );
  dlg.addEventListener('close', () => {
    dlg.remove();
    if (alCerrar) alCerrar();
  });
  document.body.append(dlg);
  dlg.showModal();
  return { el: dlg, cuerpo, cerrar, error };
}

/** Confirmación. opciones: {titulo, mensaje (string|Node), confirmar, peligro, escribir} -> Promise<boolean> */
export function confirmar({ titulo, mensaje, confirmar: txt = 'Confirmar', peligro = false, escribir = null, cancelar = 'Cancelar' }) {
  return new Promise((resolve) => {
    let ok = false;
    const entrada = escribir ? h('input', { type: 'text', 'aria-label': `Escribe ${escribir} para continuar`, autocomplete: 'off' }) : null;
    const cont = h('div', null, typeof mensaje === 'string' ? h('p', null, mensaje) : mensaje, escribir ? campo(`Escribe ${escribir} para continuar`, entrada) : null);
    modal({
      titulo,
      contenido: cont,
      alCerrar: () => resolve(ok),
      acciones: [
        { texto: cancelar },
        {
          texto: txt,
          clase: peligro ? 'peligro solido' : 'primario',
          onClick: (_c, { error }) => {
            if (escribir && entrada.value.trim() !== escribir) {
              error(`Escribe exactamente ${escribir} para confirmar.`);
              return false;
            }
            ok = true;
          },
        },
      ],
    });
  });
}

/** Pide un texto corto. Devuelve string (puede ser vacío) o null si se cancela. */
export function pedirTexto({ titulo, etiqueta, requerido = false, ayuda = null, confirmar: txt = 'Aceptar', multilinea = true }) {
  return new Promise((resolve) => {
    let res = null;
    const ctl = multilinea ? h('textarea', { rows: 3 }) : h('input', { type: 'text' });
    modal({
      titulo,
      contenido: campo(etiqueta, ctl, ayuda),
      alCerrar: () => resolve(res),
      acciones: [
        { texto: 'Cancelar' },
        {
          texto: txt,
          clase: 'primario',
          onClick: (_c, { error }) => {
            if (requerido && !ctl.value.trim()) {
              error('Este dato es obligatorio.');
              return false;
            }
            res = ctl.value.trim();
          },
        },
      ],
    });
    setTimeout(() => ctl.focus(), 30);
  });
}

// ---------------------------------------------------------------- Descargas

export function descargar(nombre, contenido, mime = 'text/plain') {
  const blob = contenido instanceof Blob ? contenido : new Blob([contenido], { type: mime + ';charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = h('a', { href: url, download: nombre });
  document.body.append(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
}
export const descargarCSV = (nombre, csv) => descargar(nombre, '﻿' + csv, 'text/csv');
