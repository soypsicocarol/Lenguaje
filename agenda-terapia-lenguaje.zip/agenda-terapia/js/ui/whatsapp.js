// WhatsApp manual: arma el mensaje editable y abre el chat. Nunca envía ni afirma que se envió.
import { TEMPLATE_LABELS } from '../core/constants.js';
import { fmtFechaLarga, fmtHora } from '../core/dates.js';
import { libroPaciente } from '../core/finance.js';
import { aplicarPlantilla, enlaceWhatsApp, normalizarTelefono } from '../core/whatsapp.js';
import { fmtMoney } from '../core/util.js';
import { aviso, campo, h, modal, opciones } from './dom.js';
import { S, nombrePaciente, hoy } from './state.js';

function textoSaldo(p) {
  const l = libroPaciente(p.id, S.data, S.ajustes);
  const partes = Object.entries(l.porMoneda).filter(([, v]) => v.pendiente > 0).map(([m, v]) => fmtMoney(v.pendiente, m));
  return partes.join(' y ');
}

function proximaCita(p) {
  const t = hoy();
  return S.data.appointments
    .filter((a) => a.patientId === p.id && a.fecha >= t && ['programada', 'confirmada'].includes(a.estado))
    .sort((a, b) => (a.fecha + a.inicio).localeCompare(b.fecha + b.inicio))[0];
}

/** Abre el diálogo de mensaje. claveInicial: confirmacion | recordatorio | cambio | cancelacion | saldo */
export function abrirWhatsApp({ paciente, cita = null, clave = 'recordatorio' }) {
  const tel = normalizarTelefono(paciente.telefono || '', S.ajustes.codigoPais);
  if (!tel.ok) {
    modal({
      titulo: 'WhatsApp',
      contenido: h('p', null, `${nombrePaciente(paciente)} no tiene un teléfono válido con código de país. Edita la ficha del paciente y agrégalo (por ejemplo +58 414 0000000).`),
      acciones: [{ texto: 'Entendido', clase: 'primario' }],
    });
    return;
  }
  const c = cita || (clave === 'saldo' ? null : proximaCita(paciente));
  const vars = () => ({
    nino: paciente.nombre,
    representante: paciente.representante,
    consultorio: S.ajustes.consultorio,
    fecha: c ? fmtFechaLarga(c.fecha) : '',
    hora: c ? fmtHora(c.inicio) : '',
    saldo: textoSaldo(paciente),
  });
  const sel = h('select', { 'aria-label': 'Plantilla' }, ...opciones(Object.entries(TEMPLATE_LABELS), clave));
  const area = h('textarea', { rows: 7, 'aria-label': 'Mensaje' });
  const nota = h('div');
  const cargar = () => {
    area.value = aplicarPlantilla(S.ajustes.plantillas[sel.value], vars());
    nota.replaceChildren();
    if (sel.value === 'saldo' && !textoSaldo(paciente)) nota.append(h('div', { class: 'aviso warn' }, 'Este paciente no tiene saldo pendiente registrado; revisa el texto antes de enviarlo.'));
    if (sel.value !== 'saldo' && !c) nota.append(h('div', { class: 'aviso' }, 'No hay una cita próxima: completa la fecha y la hora en el mensaje si hace falta.'));
  };
  sel.addEventListener('change', cargar);
  cargar();
  modal({
    titulo: `WhatsApp · ${paciente.representante}`,
    contenido: h('div', null,
      h('p', { class: 'muted' }, `Se abrirá el chat con ${tel.e164}. Revisa y edita el mensaje: lo envías tú desde WhatsApp.`),
      campo('Plantilla', sel), campo('Mensaje', area), nota),
    acciones: [
      { texto: 'Cancelar' },
      {
        texto: 'Abrir WhatsApp',
        clase: 'primario',
        icono: 'chat',
        onClick: () => {
          const a = h('a', { href: enlaceWhatsApp(tel.digits, area.value), target: '_blank', rel: 'noopener noreferrer' });
          document.body.append(a);
          a.click();
          a.remove();
          aviso('Se intentó abrir WhatsApp con el mensaje. Envíalo desde allí: la agenda no sabe si se envió. Si no abrió, revisa que WhatsApp esté instalado o que haya conexión.', 'ok');
        },
      },
    ],
  });
}
