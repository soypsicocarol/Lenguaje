// Interfaz de citas: detalle, formulario, reprogramación, series y bloqueos.
import { ESTADOS, ESTADOS_MODIFICABLES, MODALIDADES, WA_ESTADOS } from '../core/constants.js';
import { DIAS_CORTOS, addDays, dayOfWeek, endTime, fmtFechaCorta, fmtFechaLarga, fmtHora, nombreDia } from '../core/dates.js';
import { estadoPaquete, libroPaciente, saldoPaquete } from '../core/finance.js';
import { detectarProblemas, hayConflicto } from '../core/schedule.js';
import { ConflictError, fmtMoney, uid } from '../core/util.js';
import { aviso, campo, check, confirmar, h, icono, modal, opciones, pedirTexto, vaciar } from './dom.js';
import { S, hoy, nombrePaciente, pacienteDe, refrescar } from './state.js';
import { abrirWhatsApp } from './whatsapp.js';
import { formPago } from './pagos.js';

const CANCELADO = Symbol('cancelado');

export const badge = (estado) => h('span', { class: `badge ${estado}` }, ESTADOS[estado]?.label || estado);
export const rango = (a) => `${fmtHora(a.inicio)} – ${fmtHora(endTime(a.inicio, a.duracion))}`;

function listaConflictos(info) {
  const items = [];
  for (const a of info.citas || []) items.push(`Cita con ${nombrePaciente(pacienteDe(a.patientId))}: ${fmtFechaCorta(a.fecha)}, ${rango(a)}`);
  for (const b of info.bloqueos || []) items.push(`Horario bloqueado (${b.motivo}): ${fmtFechaCorta(b.fechaInicio)} ${b.horaInicio} a ${fmtFechaCorta(b.fechaFin)} ${b.horaFin}`);
  return items;
}

/** Muestra la advertencia y pide confirmación explícita. */
export function confirmarConflicto(info) {
  let cuerpo;
  if (info.porFecha) {
    cuerpo = h('div', null,
      h('p', null, `${info.porFecha.length} cita(s) tienen conflicto de horario:`),
      h('ul', null, ...info.porFecha.slice(0, 12).map((c) => h('li', null, `${fmtFechaCorta(c.fecha)} ${c.inicio}: `, listaConflictos(c).join('; ')))),
      info.porFecha.length > 12 ? h('p', { class: 'muted' }, `… y ${info.porFecha.length - 12} más.`) : null);
  } else {
    cuerpo = h('div', null, h('p', null, 'Esta cita choca con:'), h('ul', null, ...listaConflictos(info).map((t) => h('li', null, t))));
  }
  cuerpo.append(h('p', null, 'Solo continúa si realmente quieres guardar la cita aunque se solape.'));
  return confirmar({ titulo: 'Conflicto de horario', mensaje: cuerpo, confirmar: 'Guardar de todos modos', peligro: true, cancelar: 'Volver y cambiar' });
}

/** Ejecuta fn(permitir). Si hay conflicto, pide confirmación y reintenta. Devuelve CANCELADO si el usuario desiste. */
async function conConflicto(fn) {
  try {
    return await fn(false);
  } catch (e) {
    if (!(e instanceof ConflictError)) throw e;
    if (!(await confirmarConflicto(e.info))) return CANCELADO;
    return fn(true);
  }
}

function duraciones(actual) {
  const s = new Set([...(S.ajustes.duracionesAdicionales || []), S.ajustes.duracionPredeterminada, actual].filter(Boolean));
  return [...s].sort((a, b) => a - b).map((n) => [String(n), `${n} min`]);
}

function textoHints(candidato, patientId) {
  const out = h('div');
  const pr = detectarProblemas(candidato, S.data, {}, S.ajustes);
  if (hayConflicto(pr)) out.append(h('div', { class: 'aviso danger', role: 'alert' }, h('strong', null, 'Conflicto de horario'), h('ul', null, ...listaConflictos(pr).map((t) => h('li', null, t)))));
  else if (pr.horario) out.append(h('div', { class: 'aviso warn' }, pr.horario === 'dia_inactivo' ? 'Ese día está fuera de tu horario de atención.' : 'La cita queda fuera de tu horario de atención.'));
  const p = pacienteDe(patientId);
  if (p && p.modalidadCobro === 'paquete') {
    const disp = S.data.packages.filter((k) => k.patientId === p.id && estadoPaquete(k, S.data.movements, candidato.fecha) === 'activo').reduce((s, k) => s + saldoPaquete(k, S.data.movements).disponibles, 0);
    out.append(h('div', { class: disp > 0 ? 'aviso' : 'aviso warn' }, disp > 0 ? `Paquete activo: ${disp} sesión(es) disponible(s).` : 'Este paciente no tiene un paquete activo con sesiones disponibles.'));
  }
  return out;
}

// ------------------------------------------------------------------ Formulario de cita

/** Crear o editar una cita. opciones: {patientId, fecha, inicio} para crear; {cita} para editar. */
export function formCita({ cita = null, patientId = '', fecha = null, inicio = null } = {}) {
  const editando = !!cita;
  const activos = S.data.patients.filter((p) => p.estado === 'activo' || (cita && p.id === cita.patientId)).sort((a, b) => nombrePaciente(a).localeCompare(nombrePaciente(b)));
  if (!editando && !activos.length) {
    aviso('Primero crea un paciente activo.', 'warn');
    return;
  }
  const selP = h('select', { disabled: editando }, ...opciones(activos.map((p) => [p.id, nombrePaciente(p)]), cita?.patientId || patientId || activos[0].id));
  const f = h('input', { type: 'date', value: cita?.fecha || fecha || hoy(), required: true });
  const i = h('input', { type: 'time', value: cita?.inicio || inicio || '09:00', required: true, step: 300 });
  const d = h('select', null, ...opciones(duraciones(cita?.duracion), String(cita?.duracion || S.ajustes.duracionPredeterminada)));
  const tarifa = h('input', { type: 'number', min: 0, step: '0.01', value: cita ? cita.tarifa : '' });
  const nota = h('textarea', { rows: 2, maxlength: 300 }, cita?.nota || '');
  nota.value = cita?.nota || '';
  const hints = h('div');
  const alcance = cita?.seriesId
    ? h('fieldset', { class: 'card' }, h('legend', null, 'Esta cita pertenece a una serie. Aplicar cambios a:'),
        ...[['esta', 'Solo esta cita'], ['futuras', 'Esta y las citas futuras'], ['toda', 'Toda la serie (solo citas sin atender)']].map(([v, t], k) =>
          h('label', { class: 'check' }, h('input', { type: 'radio', name: 'alcance', value: v, checked: k === 0 }), h('span', null, t))))
    : null;
  const sincronizarTarifa = () => {
    if (!editando) {
      const p = pacienteDe(selP.value);
      tarifa.value = p ? p.tarifa : '';
    }
  };
  const act = () => {
    vaciar(hints).append(textoHints({ id: cita?.id || '__n', fecha: f.value, inicio: i.value, duracion: Number(d.value) }, selP.value));
  };
  selP.addEventListener('change', () => {
    sincronizarTarifa();
    act();
  });
  [f, i, d].forEach((x) => x.addEventListener('input', act));
  sincronizarTarifa();
  act();
  const monedaTxt = () => (pacienteDe(selP.value)?.moneda || S.ajustes.moneda);
  modal({
    titulo: editando ? 'Editar cita' : 'Nueva cita',
    contenido: h('div', null,
      campo('Paciente', selP),
      h('div', { class: 'form-grid' }, campo('Fecha', f), campo('Hora de inicio', i), campo('Duración (min)', d)),
      h('div', { class: 'form-grid' }, campo(`Tarifa prevista (${monedaTxt()})`, tarifa, 'Aplica a pacientes con pago por sesión.')),
      campo('Nota administrativa (opcional)', nota, 'Evita escribir contenido clínico: esta agenda es administrativa.'),
      alcance, hints),
    acciones: [
      { texto: 'Cancelar' },
      {
        texto: 'Guardar cita',
        clase: 'primario',
        onClick: async () => {
          const datos = { patientId: selP.value, fecha: f.value, inicio: i.value, duracion: Number(d.value), tarifa: tarifa.value === '' ? undefined : Number(tarifa.value), nota: nota.value };
          const r = await conConflicto((permitir) => {
            if (!editando) return S.svc.crearCita(datos, { permitirConflicto: permitir });
            if (cita.seriesId) {
              const al = document.querySelector('input[name=alcance]:checked')?.value || 'esta';
              return S.svc.editarCitaSerie(cita.id, al, { fecha: datos.fecha, inicio: datos.inicio, duracion: datos.duracion, nota: datos.nota }, { permitirConflicto: permitir }).then(async (x) => {
                if (datos.tarifa !== undefined) await S.svc.actualizarCita(cita.id, { tarifa: datos.tarifa });
                return x;
              });
            }
            return S.svc.actualizarCita(cita.id, datos, { permitirConflicto: permitir });
          });
          if (r === CANCELADO) return false;
          await refrescar();
          aviso(editando ? 'Cita actualizada.' : 'Cita guardada.', 'ok');
        },
      },
    ],
  });
}

// ------------------------------------------------------------------ Reprogramar

export function formReprogramar(cita) {
  const f = h('input', { type: 'date', value: cita.fecha, required: true });
  const i = h('input', { type: 'time', value: cita.inicio, step: 300 });
  const d = h('select', null, ...opciones(duraciones(cita.duracion), String(cita.duracion)));
  const hints = h('div');
  const act = () => vaciar(hints).append(textoHints({ id: '__n', fecha: f.value, inicio: i.value, duracion: Number(d.value) }, cita.patientId));
  [f, i, d].forEach((x) => x.addEventListener('input', act));
  act();
  modal({
    titulo: 'Reprogramar cita',
    contenido: h('div', null,
      h('p', null, `Cita original: ${fmtFechaLarga(cita.fecha)}, ${rango(cita)}. Quedará marcada como reprogramada y vinculada a la nueva; no se contará como realizada.`),
      h('div', { class: 'form-grid' }, campo('Nueva fecha', f), campo('Nueva hora', i), campo('Duración (min)', d)), hints),
    acciones: [
      { texto: 'Cancelar' },
      {
        texto: 'Reprogramar',
        clase: 'primario',
        onClick: async () => {
          const r = await conConflicto((permitir) => S.svc.reprogramarCita(cita.id, { fecha: f.value, inicio: i.value, duracion: Number(d.value) }, { permitirConflicto: permitir }));
          if (r === CANCELADO) return false;
          await refrescar();
          aviso('Cita reprogramada.', 'ok');
        },
      },
    ],
  });
}

// ------------------------------------------------------------------ Detalle de cita

export function detalleCita(id) {
  const a0 = S.data.appointments.find((x) => x.id === id);
  if (!a0) return;
  const m = modal({ titulo: 'Detalle de la cita', contenido: h('div'), ancho: true, acciones: [{ texto: 'Cerrar' }] });
  const pintar = () => {
    const a = S.data?.appointments.find((x) => x.id === id);
    if (!a) return m.cerrar();
    vaciar(m.cuerpo).append(vista(a));
  };
  async function cambiar(a, estado) {
    let motivo = '';
    if (estado.startsWith('cancelada')) {
      const t = await pedirTexto({ titulo: 'Motivo de la cancelación', etiqueta: 'Motivo (opcional)', confirmar: 'Guardar cancelación' });
      if (t === null) return;
      motivo = t;
    }
    try {
      const r = await S.svc.cambiarEstadoCita(a.id, estado, { motivo });
      await refrescar();
      if (r.aviso === 'sin_paquete') aviso('No hay un paquete activo con sesiones disponibles: no se descontó ninguna sesión.', 'warn');
      else aviso(`Estado: ${ESTADOS[estado].label}.`, 'ok');
    } catch (e) {
      aviso(e.message, 'error');
    }
    pintar();
  }
  function vista(a) {
    const p = pacienteDe(a.patientId);
    const serie = a.seriesId ? S.data.series.find((s) => s.id === a.seriesId) : null;
    const esMod = ESTADOS_MODIFICABLES.includes(a.estado);
    const origen = a.reprogramadaDe ? S.data.appointments.find((x) => x.id === a.reprogramadaDe) : null;
    const destino = a.reprogramadaA ? S.data.appointments.find((x) => x.id === a.reprogramadaA) : null;
    const lib = p ? libroPaciente(p.id, S.data, S.ajustes) : null;
    const ob = lib?.obligaciones.find((o) => o.tipo === 'cita' && o.id === a.id);
    const wa = h('select', { 'aria-label': 'Estado del contacto por WhatsApp', onChange: async (e) => {
      try {
        await S.svc.marcarWhatsApp(a.id, e.target.value);
        await refrescar();
        pintar();
      } catch (er) {
        aviso(er.message, 'error');
      }
    } }, ...opciones(Object.entries(WA_ESTADOS), a.whatsappEstado || 'pendiente'));
    return h('div', { class: 'stack' },
      h('div', { class: 'row between' },
        h('div', null, h('h3', null, nombrePaciente(p)), h('div', { class: 'muted' }, `${fmtFechaLarga(a.fecha)} · ${rango(a)} (${a.duracion} min)`)),
        badge(a.estado)),
      a.pendienteReprogramar ? h('div', { class: 'aviso warn' }, 'Cancelada por la terapeuta: pendiente de reprogramar.') : null,
      origen ? h('div', { class: 'aviso' }, `Reprogramada desde ${fmtFechaCorta(origen.fecha)} ${origen.inicio}.`) : null,
      destino ? h('div', { class: 'aviso' }, `Reprogramada para ${fmtFechaCorta(destino.fecha)} ${destino.inicio}.`) : null,
      a.motivoCancelacion ? h('p', null, h('strong', null, 'Motivo: '), a.motivoCancelacion) : null,
      a.nota ? h('p', null, h('strong', null, 'Nota: '), a.nota) : null,
      h('p', { class: 'muted' },
        serie ? h('span', null, icono('repeat'), ` Parte de una serie semanal (${serie.dias.map((d) => DIAS_CORTOS[d.dia]).join(', ')}). `) : 'Cita individual. ',
        `Cobro: ${MODALIDADES[a.modalidad] || a.modalidad}`, a.modalidad === 'sesion' ? ` · Tarifa ${fmtMoney(a.tarifa, a.moneda)}` : '',
        ob ? ` · ${ob.estado === 'pagada' ? 'Pagada' : ob.estado === 'parcial' ? `Pago parcial (pendiente ${fmtMoney(ob.pendiente, ob.moneda)})` : 'Sin pagar'}` : ''),
      h('fieldset', { class: 'card' }, h('legend', null, 'Registrar resultado'),
        h('div', { class: 'row' }, ...['confirmada', 'realizada', 'cancelada_representante', 'cancelada_terapeuta', 'inasistencia', 'programada']
          .filter((e) => a.estado !== 'reprogramada')
          .map((e) => h('button', { type: 'button', 'aria-pressed': a.estado === e, onClick: () => cambiar(a, e) }, ESTADOS[e].label)))),
      h('div', { class: 'row' },
        h('button', { type: 'button', onClick: () => { m.cerrar(); abrirWhatsApp({ paciente: p, cita: a, clave: a.estado.startsWith('cancelada') ? 'cancelacion' : a.estado === 'confirmada' ? 'recordatorio' : 'confirmacion' }); } }, icono('chat'), 'WhatsApp'),
        h('label', { class: 'row' }, h('span', { class: 'muted' }, 'Contacto:'), wa),
        a.estado !== 'reprogramada' ? h('button', { type: 'button', onClick: () => { m.cerrar(); formCita({ cita: a }); } }, icono('edit'), 'Editar') : null,
        ['programada', 'confirmada', 'cancelada_terapeuta', 'cancelada_representante'].includes(a.estado) ? h('button', { type: 'button', onClick: () => { m.cerrar(); formReprogramar(a); } }, icono('clock'), 'Reprogramar') : null,
        a.modalidad === 'sesion' ? h('button', { type: 'button', onClick: () => { m.cerrar(); formPago({ patientId: a.patientId, obligacion: { tipo: 'cita', id: a.id }, importe: ob ? ob.pendiente : a.tarifa, concepto: `Sesión ${a.fecha}` }); } }, icono('wallet'), 'Registrar pago') : null,
        h('button', { type: 'button', class: 'peligro', onClick: async () => {
          const ok = await confirmar({ titulo: 'Eliminar cita', mensaje: 'La cita se borrará de la agenda. Si ya descontó una sesión de un paquete, se devolverá. Los pagos registrados se conservan. Para conservar el historial, mejor cámbiala a cancelada.', confirmar: 'Eliminar cita', peligro: true });
          if (!ok) return;
          try {
            await S.svc.eliminarCita(a.id);
            await refrescar();
            aviso('Cita eliminada.', 'ok');
            m.cerrar();
          } catch (e) {
            aviso(e.message, 'error');
          }
        } }, icono('trash'), 'Eliminar')),
      serie && esMod ? h('details', { class: 'det' }, h('summary', null, 'Opciones de la serie'),
        h('div', { class: 'row' },
          h('button', { type: 'button', onClick: async () => {
            const ok = await confirmar({ titulo: 'Excluir esta fecha', mensaje: `Se quitará la cita del ${fmtFechaLarga(a.fecha)} y no se volverá a generar (pausa o vacaciones). La serie continúa.`, confirmar: 'Excluir fecha', peligro: true });
            if (!ok) return;
            try {
              await S.svc.excluirFechasSerie(serie.id, [a.fecha]);
              await refrescar();
              aviso('Fecha excluida de la serie.', 'ok');
              m.cerrar();
            } catch (e) {
              aviso(e.message, 'error');
            }
          } }, 'Excluir esta fecha'),
          h('button', { type: 'button', onClick: () => { m.cerrar(); formExcluirRango(serie); } }, 'Pausa o vacaciones…'),
          h('button', { type: 'button', class: 'peligro', onClick: async () => {
            const futuras = S.data.appointments.filter((x) => x.seriesId === serie.id && x.fecha >= a.fecha && ESTADOS_MODIFICABLES.includes(x.estado)).length;
            const ok = await confirmar({ titulo: 'Finalizar serie desde aquí', mensaje: `Se eliminarán ${futuras} cita(s) sin atender desde el ${fmtFechaLarga(a.fecha)}. Las citas pasadas y con resultado se conservan.`, confirmar: 'Finalizar serie', peligro: true });
            if (!ok) return;
            try {
              await S.svc.finalizarSerieDesde(a.id);
              await refrescar();
              aviso('Serie finalizada.', 'ok');
              m.cerrar();
            } catch (e) {
              aviso(e.message, 'error');
            }
          } }, 'Finalizar serie desde aquí'),
          h('button', { type: 'button', onClick: () => { m.cerrar(); formExtender(serie); } }, 'Extender serie…'))) : null,
      h('details', { class: 'det' }, h('summary', null, `Historial de cambios (${a.historial.length})`),
        h('ul', null, ...a.historial.map((x) => h('li', null, `${new Date(x.en).toLocaleString('es')} · ${x.tipo}${x.de ? ` · ${x.de} → ${x.a}` : ''}${x.nota ? ` · ${x.nota}` : ''}`)))));
  }
  pintar();
}

function formExcluirRango(serie) {
  const d1 = h('input', { type: 'date', required: true });
  const d2 = h('input', { type: 'date', required: true });
  modal({
    titulo: 'Pausa o vacaciones de la serie',
    contenido: h('div', null, h('p', null, 'Se quitarán las citas sin atender de la serie dentro del rango y no se volverán a generar.'), h('div', { class: 'form-grid' }, campo('Desde', d1), campo('Hasta', d2))),
    acciones: [
      { texto: 'Cancelar' },
      {
        texto: 'Excluir rango',
        clase: 'primario',
        onClick: async () => {
          if (!d1.value || !d2.value || d2.value < d1.value) throw new Error('Revisa el rango de fechas.');
          const fechas = [];
          for (let f = d1.value; f <= d2.value && fechas.length < 400; f = addDays(f, 1)) fechas.push(f);
          const r = await S.svc.excluirFechasSerie(serie.id, fechas);
          await refrescar();
          aviso(`${r.eliminadas} cita(s) quitadas${r.conservadas ? `; ${r.conservadas} con resultado se conservaron` : ''}.`, 'ok');
        },
      },
    ],
  });
}

function formExtender(serie) {
  const d = h('input', { type: 'date', required: true });
  modal({
    titulo: 'Extender serie',
    contenido: h('div', null, h('p', null, 'Se agregarán las citas que falten hasta la nueva fecha, sin repetir las existentes ni las fechas excluidas.'), campo('Nueva fecha final', d)),
    acciones: [
      { texto: 'Cancelar' },
      {
        texto: 'Extender',
        clase: 'primario',
        onClick: async () => {
          const r = await conConflicto((permitir) => S.svc.extenderSerie(serie.id, d.value, { permitirConflicto: permitir }));
          if (r === CANCELADO) return false;
          await refrescar();
          aviso(`${r.creadas} cita(s) agregadas.`, 'ok');
        },
      },
    ],
  });
}

// ------------------------------------------------------------------ Serie semanal

export function formSerie({ patientId = '' } = {}) {
  const activos = S.data.patients.filter((p) => p.estado === 'activo').sort((a, b) => nombrePaciente(a).localeCompare(nombrePaciente(b)));
  if (!activos.length) {
    aviso('Primero crea un paciente activo.', 'warn');
    return;
  }
  const idSerie = uid(); // se fija al abrir: guardar dos veces la misma serie no duplica citas
  const selP = h('select', null, ...opciones(activos.map((p) => [p.id, nombrePaciente(p)]), patientId || activos[0].id));
  const orden = [1, 2, 3, 4, 5, 6, 0];
  const dias = orden.map((dow) => {
    const c = h('input', { type: 'checkbox', 'aria-label': nombreDia(dow)[0].toUpperCase() + nombreDia(dow).slice(1) });
    const t = h('input', { type: 'time', value: '15:00', step: 300, 'aria-label': `Hora del ${nombreDia(dow)}` });
    return { dow, c, t, el: h('div', { class: 'd' }, c, h('span', null, nombreDia(dow)[0].toUpperCase() + nombreDia(dow).slice(1)), t) };
  });
  const dur = h('select', { 'aria-label': 'Duración (min)' }, ...opciones(duraciones(), String(S.ajustes.duracionPredeterminada)));
  const ini = h('input', { type: 'date', value: hoy(), required: true, 'aria-label': 'Fecha de inicio' });
  const rSem = h('input', { type: 'radio', name: 'fin', value: 'semanas', checked: true });
  const nSem = h('input', { type: 'number', min: 1, max: 104, value: 8, 'aria-label': 'Número de semanas' });
  const rFec = h('input', { type: 'radio', name: 'fin', value: 'fecha' });
  const fFin = h('input', { type: 'date', 'aria-label': 'Fecha final' });
  const nota = h('input', { type: 'text', maxlength: 200, 'aria-label': 'Nota de la serie' });
  const previa = h('div');
  let filas = [];
  const sel = new Map();

  const entrada = () => ({
    id: idSerie,
    patientId: selP.value,
    dias: dias.filter((x) => x.c.checked).map((x) => ({ dia: x.dow, hora: x.t.value })),
    duracion: Number(dur.value),
    fechaInicio: ini.value,
    semanas: rSem.checked ? Number(nSem.value) : null,
    fechaFin: rFec.checked ? fFin.value || null : null,
    nota: nota.value,
  });

  let ticket = 0;
  let enCurso = Promise.resolve();
  // La vista previa anterior se conserva hasta que llegue la nueva (evita saltos de diseño). El botón no se
  // desactiva mientras se recalcula: al pulsarlo se espera el cálculo en curso (así un 'change' por perder el foco no anula el clic).
  const actualizar = () => (enCurso = correr());
  async function correr() {
    const mio = ++ticket;
    const inp = entrada();
    if (!inp.dias.length) {
      boton.disabled = true;
      vaciar(previa).append(h('p', { class: 'muted' }, 'Elige al menos un día para ver las citas que se crearán.'));
      return;
    }
    let nuevas;
    try {
      nuevas = await S.svc.vistaPreviaSerie(inp);
    } catch (e) {
      if (mio === ticket) {
        boton.disabled = true;
        vaciar(previa).append(h('div', { class: 'aviso warn' }, e.message));
      }
      return;
    }
    if (mio !== ticket) return; // llegó una respuesta más reciente: se descarta ésta
    filas = nuevas;
    vaciar(previa);
    for (const r of filas) if (!sel.has(r.clave)) sel.set(r.clave, true);
    const tabla = h('table', { class: 'tabla' }, h('thead', null, h('tr', null, h('th', null, 'Crear'), h('th', null, 'Fecha'), h('th', null, 'Hora'), h('th', null, 'Aviso'))),
      h('tbody', null, ...filas.map((r) => {
        const cb = h('input', { type: 'checkbox', checked: sel.get(r.clave) && !r.existe, disabled: r.existe, 'aria-label': `Incluir ${r.fecha}`, onChange: () => { sel.set(r.clave, cb.checked); resumen(); } });
        return h('tr', null, h('td', null, cb), h('td', null, fmtFechaCorta(r.fecha)), h('td', null, `${r.inicio}–${endTime(r.inicio, inp.duracion)}`),
          h('td', null, r.conflicto ? h('span', { class: 'badge inasistencia' }, 'Conflicto') : r.problemas.horario ? h('span', { class: 'badge cancelada_terapeuta' }, 'Fuera de horario') : r.existe ? 'Ya existe' : ''));
      })));
    previa.append(h('p', null, h('strong', null, 'Vista previa: '), `${filas.length} cita(s) según las reglas.`), h('div', { class: 'tabla-wrap' }, tabla));
    // desmarcar por defecto las que tienen conflicto
    for (const r of filas) if (r.conflicto && !yaVista.has(r.clave)) { sel.set(r.clave, false); yaVista.add(r.clave); }
    previa.querySelectorAll('tbody input[type=checkbox]').forEach((cb, k) => (cb.checked = !!sel.get(filas[k].clave) && !filas[k].existe));
    resumen();
  }
  const yaVista = new Set();
  const seleccion = () => filas.filter((r) => sel.get(r.clave) && !r.existe);
  function resumen() {
    const n = seleccion().length;
    boton.textContent = n ? `Crear ${n} cita${n === 1 ? '' : 's'}` : 'Crear citas';
    boton.disabled = n === 0;
    const conf = seleccion().filter((r) => r.conflicto).length;
    resumenEl.textContent = conf ? `${conf} de las seleccionadas tienen conflicto: se pedirá confirmación.` : '';
  }
  const resumenEl = h('div', { class: 'aviso warn', role: 'status' });
  resumenEl.hidden = false;
  const boton = h('button', { type: 'button', class: 'primario', disabled: true }, 'Crear citas');

  const form = h('div', null,
    campo('Paciente', selP),
    h('fieldset', { class: 'card' }, h('legend', null, 'Días y horas de la semana'), h('div', { class: 'dias-sel' }, ...dias.map((x) => x.el))),
    h('div', { class: 'form-grid' }, campo('Duración (min)', dur), campo('Fecha de inicio', ini)),
    h('fieldset', { class: 'card' }, h('legend', null, 'Hasta cuándo'),
      h('div', { class: 'row' }, h('label', { class: 'check' }, rSem, h('span', null, 'Durante')), nSem, h('span', null, 'semanas')),
      h('div', { class: 'row' }, h('label', { class: 'check' }, rFec, h('span', null, 'Hasta la fecha')), fFin)),
    campo('Nota administrativa de la serie (opcional)', nota),
    previa, resumenEl);
  form.addEventListener('input', actualizar);
  form.addEventListener('change', actualizar);

  const m = modal({
    titulo: 'Serie de sesiones semanales',
    ancho: true,
    contenido: form,
    acciones: [{ texto: 'Cancelar' }],
  });
  boton.addEventListener('click', async () => {
    boton.disabled = true;
    try {
      await enCurso;
      const incl = seleccion().map((r) => r.clave);
      const r = await conConflicto((permitir) => S.svc.crearSerie(entrada(), { incluir: incl, permitirConflicto: permitir }));
      if (r === CANCELADO) {
        boton.disabled = false;
        return;
      }
      await refrescar();
      aviso(r.yaExistia ? 'Esta serie ya estaba guardada: no se duplicó.' : `Serie creada: ${r.creadas} cita(s).`, 'ok');
      m.cerrar();
    } catch (e) {
      m.error(e.message);
      boton.disabled = false;
    }
  });
  m.el.querySelector('.dlg-f').append(boton);
  // el patient por defecto con tarifa/modalidad etc. se toman al crear
  actualizar();
}

// ------------------------------------------------------------------ Bloqueos

export function formBloqueo({ bloque = null, fecha = null } = {}) {
  const ini = bloque?.fechaInicio || fecha || hoy();
  const fi = h('input', { type: 'date', value: ini, required: true });
  const hi = h('input', { type: 'time', value: bloque?.horaInicio || '12:00', step: 300 });
  const ff = h('input', { type: 'date', value: bloque?.fechaFin || ini, required: true });
  const hf = h('input', { type: 'time', value: bloque && bloque.horaFin !== '24:00' ? bloque.horaFin : '13:00', step: 300 });
  const todo = check('Todo el día (los días indicados completos)', { checked: !!bloque && bloque.horaInicio === '00:00' && bloque.horaFin === '24:00' });
  const motivo = h('input', { type: 'text', value: bloque?.motivo || '', maxlength: 120, placeholder: 'Descanso, reunión, vacaciones…' });
  const sync = () => (hi.disabled = hf.disabled = todo.input.checked);
  todo.input.addEventListener('change', sync);
  sync();
  const acciones = [{ texto: 'Cancelar' }];
  if (bloque) {
    acciones.push({
      texto: 'Eliminar bloqueo',
      clase: 'peligro',
      onClick: async () => {
        await S.svc.eliminarBloqueo(bloque.id);
        await refrescar();
        aviso('Bloqueo eliminado.', 'ok');
      },
    });
  }
  acciones.push({
    texto: 'Guardar bloqueo',
    clase: 'primario',
    onClick: async () => {
      const datos = { fechaInicio: fi.value, horaInicio: todo.input.checked ? '00:00' : hi.value, fechaFin: ff.value, horaFin: todo.input.checked ? '24:00' : hf.value, motivo: motivo.value };
      if (bloque) await S.svc.actualizarBloqueo(bloque.id, datos);
      else {
        const r = await S.svc.crearBloqueo(datos);
        if (r.citasAfectadas) aviso(`Atención: ${r.citasAfectadas} cita(s) existentes caen dentro del bloqueo. Revísalas o reprográmalas.`, 'warn');
      }
      await refrescar();
    },
  });
  modal({
    titulo: bloque ? 'Editar bloqueo' : 'Bloquear horario',
    contenido: h('div', null, campo('Motivo', motivo), h('div', { class: 'form-grid' }, campo('Fecha de inicio', fi), campo('Hora de inicio', hi), campo('Fecha final', ff), campo('Hora final', hf)), todo),
    acciones,
  });
}
