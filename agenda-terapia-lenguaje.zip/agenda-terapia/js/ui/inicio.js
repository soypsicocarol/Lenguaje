// Panel de inicio.
import { addDays, endOfMonth, fmtFechaCorta, fmtFechaLarga, startOfMonth, startOfWeek } from '../core/dates.js';
import { estadoPaquete, libroPaciente, saldoPaquete, saldosPendientes, totalPorMoneda } from '../core/finance.js';
import { fmtMoney } from '../core/util.js';
import { h, icono, anexar } from './dom.js';
import { S, hoy, nombrePaciente, pacienteDe } from './state.js';
import { badge, detalleCita, formCita, formSerie, rango } from './citas.js';

const money = (o) => (Object.keys(o).length ? Object.entries(o).map(([m, v]) => fmtMoney(v, m)).join(' · ') : '—');

export function filaMini(a, conFecha = false) {
  return h('button', { type: 'button', class: `item st-${a.estado}`, onClick: () => detalleCita(a.id) },
    h('span', { class: 'hora' }, conFecha ? fmtFechaCorta(a.fecha) : a.inicio),
    h('span', { class: 'cuerpo' }, h('strong', null, nombrePaciente(pacienteDe(a.patientId))), h('small', null, rango(a))), badge(a.estado));
}

export function vistaInicio(cont, { instalar }) {
  const t = hoy();
  const d = S.data;
  const avisos = [];
  if (!S.pinActivo) avisos.push(h('div', { class: 'card banner aviso warn' }, h('div', null, h('strong', null, 'Protege el acceso. '), 'Esta agenda guarda datos de menores en este dispositivo. Configura un PIN o contraseña.'), h('a', { class: 'btn', href: '#/config' }, icono('lock'), 'Configurar PIN')));
  const hayDatos = d.patients.length > 0;
  const ur = S.ajustes.ultimoRespaldo;
  const dias = ur ? Math.floor((Date.now() - new Date(ur.fecha).getTime()) / 86400000) : null;
  if (hayDatos && (dias === null || dias >= 7)) avisos.push(h('div', { class: 'card banner aviso warn' }, h('div', null, h('strong', null, dias === null ? 'Aún no has hecho un respaldo. ' : `Tu último respaldo fue hace ${dias} días. `), 'Si borras los datos del navegador o pierdes el teléfono, no hay forma de recuperarlos sin un respaldo.'), h('a', { class: 'btn', href: '#/config' }, icono('download'), 'Hacer respaldo')));
  if (instalar.disponible()) avisos.push(h('div', { class: 'card banner aviso' }, h('div', null, 'Puedes instalar la agenda en este dispositivo para abrirla como una app.'), h('button', { type: 'button', onClick: instalar.lanzar }, 'Instalar')));

  const hoyC = d.appointments.filter((a) => a.fecha === t).sort((a, b) => a.inicio.localeCompare(b.inicio));
  const manana = addDays(t, 1);
  const prox = d.appointments.filter((a) => a.fecha > t && a.fecha <= addDays(t, 7) && ['programada', 'confirmada'].includes(a.estado)).sort((a, b) => (a.fecha + a.inicio).localeCompare(b.fecha + b.inicio));
  const porConfirmar = d.appointments.filter((a) => a.fecha >= t && a.fecha <= addDays(t, 3) && a.estado === 'programada' && a.whatsappEstado !== 'confirmado').sort((a, b) => (a.fecha + a.inicio).localeCompare(b.fecha + b.inicio));
  const porReprog = d.appointments.filter((a) => a.pendienteReprogramar);
  const recientes = d.appointments.filter((a) => a.fecha < t && a.fecha >= addDays(t, -14) && ['cancelada_representante', 'cancelada_terapeuta', 'inasistencia'].includes(a.estado)).sort((a, b) => b.fecha.localeCompare(a.fecha));
  const mes = [startOfMonth(t), endOfMonth(t)];
  const sem = [startOfWeek(t), addDays(startOfWeek(t), 6)];
  const realizadasMes = d.appointments.filter((a) => a.estado === 'realizada' && a.fecha >= mes[0] && a.fecha <= mes[1]).length;
  const saldos = saldosPendientes(d, S.ajustes);
  const totalPend = {};
  for (const s of saldos) for (const [m, v] of Object.entries(s.porMoneda)) totalPend[m] = (totalPend[m] || 0) + v;
  const paquetes = d.packages.filter((k) => estadoPaquete(k, d.movements, t) === 'activo');

  anexar(cont, 
    h('div', { class: 'page-head' }, h('div', null, h('h1', null, 'Inicio'), h('div', { class: 'muted' }, fmtFechaLarga(t))),
      h('div', { class: 'row' }, h('button', { type: 'button', class: 'primario', onClick: () => formCita() }, icono('plus'), 'Nueva cita'), h('button', { type: 'button', onClick: () => formSerie() }, icono('repeat'), 'Serie semanal'))),
    ...avisos,
    !hayDatos ? h('div', { class: 'card vacio' }, h('h2', null, 'Bienvenida'), h('p', null, 'Empieza creando tu primer paciente. También puedes cargar datos de demostración (ficticios) desde Configuración para explorar la app.'), h('a', { class: 'btn primario', href: '#/pacientes' }, 'Ir a Pacientes')) : null,
    h('div', { class: 'card' }, h('h2', null, `Hoy (${hoyC.filter((a) => !['cancelada_representante', 'cancelada_terapeuta', 'reprogramada'].includes(a.estado)).length} activas)`), hoyC.length ? hoyC.map((a) => filaMini(a)) : h('p', { class: 'muted' }, 'No hay citas hoy.')),
    h('div', { class: 'grid c2' },
      h('div', { class: 'card' }, h('h2', null, 'Por confirmar (próximos 3 días)'), porConfirmar.length ? porConfirmar.slice(0, 8).map((a) => filaMini(a, true)) : h('p', { class: 'muted' }, 'Nada pendiente de confirmar.')),
      h('div', { class: 'card' }, h('h2', null, 'Próximas sesiones (7 días)'), prox.length ? prox.slice(0, 8).map((a) => filaMini(a, true)) : h('p', { class: 'muted' }, 'Sin sesiones en los próximos 7 días.'))),
    porReprog.length ? h('div', { class: 'card' }, h('h2', null, 'Por reprogramar (canceladas por ti)'), porReprog.map((a) => filaMini(a, true))) : null,
    h('div', { class: 'card' }, h('h2', null, 'Cancelaciones e inasistencias recientes (14 días)'), recientes.length ? recientes.slice(0, 8).map((a) => filaMini(a, true)) : h('p', { class: 'muted' }, 'Ninguna.')),
    h('div', { class: 'grid c3' },
      h('div', { class: 'card kpi' }, h('span', { class: 'v' }, String(realizadasMes)), h('span', { class: 'l' }, 'Sesiones realizadas este mes')),
      h('div', { class: 'card kpi' }, h('span', { class: 'v' }, money(totalPorMoneda(d.payments, t, t))), h('span', { class: 'l' }, 'Cobrado hoy')),
      h('div', { class: 'card kpi' }, h('span', { class: 'v' }, money(totalPorMoneda(d.payments, sem[0], sem[1]))), h('span', { class: 'l' }, 'Cobrado esta semana')),
      h('div', { class: 'card kpi' }, h('span', { class: 'v' }, money(totalPorMoneda(d.payments, mes[0], mes[1]))), h('span', { class: 'l' }, 'Cobrado este mes')),
      h('div', { class: 'card kpi' }, h('span', { class: 'v' }, money(totalPend)), h('span', { class: 'l' }, `Saldos pendientes (${saldos.length} paciente${saldos.length === 1 ? '' : 's'})`)),
      h('div', { class: 'card kpi' }, h('span', { class: 'v' }, String(paquetes.length)), h('span', { class: 'l' }, 'Paquetes activos'))),
    paquetes.length ? h('div', { class: 'card' }, h('h2', null, 'Paquetes activos'), h('div', { class: 'tabla-wrap' }, h('table', { class: 'tabla' }, h('tbody', null, ...paquetes.map((k) => {
      const s = saldoPaquete(k, d.movements);
      return h('tr', null, h('td', null, nombrePaciente(pacienteDe(k.patientId))), h('td', null, k.nombre), h('td', { class: 'num' }, h('strong', null, `${s.disponibles} de ${s.iniciales} disponibles`)), h('td', null, s.disponibles <= 2 ? h('span', { class: 'badge parcial' }, 'Por agotarse') : ''));
    }))))) : null);
}
