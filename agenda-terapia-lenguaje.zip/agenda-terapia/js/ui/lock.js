// Pantalla de bloqueo con PIN o contraseña local. Es un bloqueo de la interfaz, no cifra la base de datos.
import { aviso, campo, confirmar, h, icono } from './dom.js';
import { S } from './state.js';

const CLAVE = 'agenda.intentos';
const leer = () => {
  try {
    return JSON.parse(localStorage.getItem(CLAVE)) || { n: 0, hasta: 0 };
  } catch {
    return { n: 0, hasta: 0 };
  }
};
const guardar = (x) => {
  try {
    localStorage.setItem(CLAVE, JSON.stringify(x));
  } catch {
    /* sin almacenamiento: se sigue sin bloqueo temporal */
  }
};

export function pantallaBloqueo(root, alDesbloquear) {
  const pin = h('input', { type: 'password', autocomplete: 'current-password', 'aria-label': 'PIN o contraseña', autofocus: true });
  const msg = h('div', { class: 'err', role: 'alert', hidden: true });
  const btn = h('button', { type: 'submit', class: 'primario' }, icono('lock'), 'Entrar');
  const mostrar = (t) => {
    msg.textContent = t;
    msg.hidden = !t;
  };
  const form = h('form', { onSubmit: async (e) => {
    e.preventDefault();
    const est = leer();
    const falta = est.hasta - Date.now();
    if (falta > 0) return mostrar(`Demasiados intentos. Espera ${Math.ceil(falta / 1000)} s.`);
    btn.disabled = true;
    try {
      if (await S.svc.verificarPin(pin.value)) {
        guardar({ n: 0, hasta: 0 });
        await alDesbloquear();
        return;
      }
      const n = est.n + 1;
      const espera = n >= 5 ? Math.min(300, 15 * 2 ** (n - 5)) : 0;
      guardar({ n, hasta: espera ? Date.now() + espera * 1000 : 0 });
      mostrar(espera ? `PIN incorrecto. Espera ${espera} s antes de volver a intentar.` : `PIN o contraseña incorrectos (${n}).`);
      pin.value = '';
    } finally {
      btn.disabled = false;
    }
  } }, campo('PIN o contraseña', pin), msg, h('div', { class: 'row' }, btn));
  root.replaceChildren(h('div', { class: 'lock' }, h('div', { class: 'card' },
    h('h1', null, 'Agenda bloqueada'), h('p', { class: 'muted' }, 'Escribe tu PIN o contraseña para continuar.'), form,
    h('details', { class: 'det' }, h('summary', null, 'Olvidé mi PIN'),
      h('p', null, 'No hay forma de recuperar el PIN. La única salida es borrar todos los datos de este dispositivo y luego restaurar un respaldo.'),
      h('button', { type: 'button', class: 'peligro', onClick: async () => {
        const ok = await confirmar({ titulo: 'Borrar todos los datos', mensaje: 'Se borrarán pacientes, citas, pagos y configuración de este dispositivo. Después podrás importar un respaldo desde Configuración. Esta acción no se puede deshacer.', confirmar: 'Borrar todo', peligro: true, escribir: 'BORRAR TODO' });
        if (!ok) return;
        await S.svc.borrarTodo();
        guardar({ n: 0, hasta: 0 });
        aviso('Datos borrados. Ya puedes usar la app o restaurar un respaldo.', 'ok');
        await alDesbloquear();
      } }, 'Borrar todos los datos')))));
  setTimeout(() => pin.focus(), 30);
}
