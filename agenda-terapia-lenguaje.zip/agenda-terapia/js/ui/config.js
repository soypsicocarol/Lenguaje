// Configuración, seguridad, respaldo y datos de demostración.
import { DEFAULT_SETTINGS, DEFAULT_TEMPLATES, ESTADOS, TEMPLATE_LABELS, APP_VERSION } from '../core/constants.js';
import { DIAS_CORTOS, nombreDia } from '../core/dates.js';
import { aviso, campo, confirmar, h, icono, modal, mensajeError, opciones, anexar } from './dom.js';
import { S, refrescar } from './state.js';
import { exportarUI, importarUI } from './respaldo.js';
import { borrarDemo, cargarDemo } from '../demo.js';

const lista = (s) => s.split(/[,\n]/).map((x) => x.trim()).filter(Boolean);

async function guardar(parcial, ok = 'Configuración guardada.') {
  try {
    await S.svc.guardarAjustes(parcial);
    await refrescar();
    aviso(ok, 'ok');
  } catch (e) {
    aviso(mensajeError(e), 'error');
  }
}

const seccion = (titulo, ...hijos) => h('section', { class: 'card' }, h('h2', null, titulo), ...hijos);
const guardarBtn = (fn) => h('button', { type: 'button', class: 'primario', onClick: fn }, 'Guardar');

export function vistaConfig(cont, { instalar }) {
  const A = S.ajustes;
  const cons = h('input', { type: 'text', value: A.consultorio, maxlength: 80 });
  const cp = h('input', { type: 'text', value: A.codigoPais, inputmode: 'numeric', maxlength: 4 });
  const monedas = h('input', { type: 'text', value: A.monedas.join(', ') });
  const mon = h('select', null, ...opciones(A.monedas.map((m) => [m, m]), A.moneda));
  const tar = h('input', { type: 'number', min: 0, step: '0.01', value: A.tarifaPredeterminada });
  const dur = h('input', { type: 'number', min: 5, max: 480, step: 5, value: A.duracionPredeterminada });
  const durs = h('input', { type: 'text', value: A.duracionesAdicionales.join(', ') });
  const metodos = h('textarea', { rows: 4 });
  metodos.value = A.metodosPago.join('\n');
  const horas = [1, 2, 3, 4, 5, 6, 0].map((i) => ({
    i,
    a: h('input', { type: 'checkbox', checked: A.horario[i].activo, 'aria-label': `Atiendo el ${nombreDia(i)}` }),
    d: h('input', { type: 'time', value: A.horario[i].desde, 'aria-label': `${nombreDia(i)} desde` }),
    h: h('input', { type: 'time', value: A.horario[i].hasta, 'aria-label': `${nombreDia(i)} hasta` }),
  }));
  const tpl = Object.fromEntries(Object.keys(TEMPLATE_LABELS).map((k) => [k, h('textarea', { rows: 3 })]));
  for (const k of Object.keys(tpl)) tpl[k].value = A.plantillas[k];
  const regP = {};
  const regC = {};
  const filasReglas = [['realizada', 'realizada'], ['canceladaRepresentante', 'cancelada_representante'], ['canceladaTerapeuta', 'cancelada_terapeuta'], ['inasistencia', 'inasistencia']].map(([k, est]) => {
    regP[k] = h('input', { type: 'checkbox', checked: A.reglasPaquete[k], 'aria-label': `${ESTADOS[est].label}: descuenta del paquete` });
    regC[k] = h('input', { type: 'checkbox', checked: A.reglasCobro[k], 'aria-label': `${ESTADOS[est].label}: genera cobro` });
    return h('tr', null, h('td', null, ESTADOS[est].label), h('td', null, regP[k]), h('td', null, regC[k]));
  });
  const auto = h('input', { type: 'number', min: 0, max: 240, value: A.autobloqueoMin });
  const archivo = h('input', { type: 'file', accept: '.json,application/json', hidden: true, 'aria-label': 'Archivo de respaldo', onChange: (e) => { if (e.target.files[0]) importarUI(e.target.files[0]); e.target.value = ''; } });
  const ur = A.ultimoRespaldo;
  const persist = h('span', { class: 'muted' }, 'Comprobando…');
  (async () => {
    try {
      const ok = navigator.storage?.persisted ? await navigator.storage.persisted() : null;
      persist.textContent = ok === null ? 'No disponible en este navegador.' : ok ? 'Protegido contra borrado automático.' : 'El navegador podría borrarlo si necesita espacio.';
    } catch {
      persist.textContent = 'No disponible.';
    }
  })();

  anexar(cont, 
    h('div', { class: 'page-head' }, h('h1', null, 'Configuración')),
    seccion('Consultorio',
      h('div', { class: 'form-grid' }, campo('Nombre del consultorio', cons), campo('Código de país predeterminado', cp, 'Se usa para teléfonos escritos sin código (sin +).')),
      guardarBtn(() => guardar({ consultorio: cons.value.trim(), codigoPais: cp.value.trim() }))),
    seccion('Moneda y tarifas',
      h('div', { class: 'form-grid' }, campo('Monedas habilitadas', monedas, 'Códigos de 3 letras separados por coma (USD, VES, EUR).'), campo('Moneda predeterminada', mon), campo('Tarifa predeterminada', tar)),
      guardarBtn(() => {
        const ms = lista(monedas.value.toUpperCase());
        guardar({ monedas: ms, moneda: ms.includes(mon.value) ? mon.value : ms[0], tarifaPredeterminada: Number(tar.value) || 0 });
      })),
    seccion('Sesiones',
      h('div', { class: 'form-grid' }, campo('Duración habitual (min)', dur), campo('Otras duraciones (min)', durs, 'Separadas por coma: 30, 45, 60.')),
      guardarBtn(() => guardar({ duracionPredeterminada: Number(dur.value), duracionesAdicionales: lista(durs.value).map(Number) }))),
    seccion('Horario de atención',
      h('div', { class: 'tabla-wrap' }, h('table', { class: 'tabla' }, h('tbody', null, ...horas.map((x) => h('tr', null, h('td', null, h('label', { class: 'check' }, x.a, h('span', null, nombreDia(x.i)[0].toUpperCase() + nombreDia(x.i).slice(1)))), h('td', null, x.d), h('td', null, x.h)))))),
      h('p', { class: 'muted' }, 'Fuera de este horario la app solo avisa; no impide agendar.'),
      guardarBtn(() => guardar({ horario: Object.fromEntries(horas.map((x) => [x.i, { activo: x.a.checked, desde: x.d.value, hasta: x.h.value }])) }))),
    seccion('Métodos de pago',
      campo('Uno por línea', metodos), guardarBtn(() => guardar({ metodosPago: lista(metodos.value) }))),
    seccion('Reglas de paquetes y cobro',
      h('p', { class: 'muted' }, 'Define qué estados de cita descuentan una sesión del paquete y cuáles generan cobro (pacientes por sesión). Los cambios aplican desde ahora; no reescriben lo ya registrado.'),
      h('div', { class: 'tabla-wrap' }, h('table', { class: 'tabla' }, h('thead', null, h('tr', null, h('th', null, 'Estado de la cita'), h('th', null, 'Descuenta del paquete'), h('th', null, 'Genera cobro'))), h('tbody', null, ...filasReglas))),
      guardarBtn(() => guardar({ reglasPaquete: Object.fromEntries(Object.entries(regP).map(([k, i]) => [k, i.checked])), reglasCobro: Object.fromEntries(Object.entries(regC).map(([k, i]) => [k, i.checked])) }))),
    seccion('Plantillas de WhatsApp',
      h('p', { class: 'muted' }, 'Variables: {nino} {representante} {fecha} {hora} {consultorio} {saldo}. Siempre podrás editar el mensaje antes de abrir WhatsApp.'),
      ...Object.entries(TEMPLATE_LABELS).map(([k, n]) => campo(n, tpl[k])),
      h('div', { class: 'row' }, guardarBtn(() => guardar({ plantillas: Object.fromEntries(Object.keys(tpl).map((k) => [k, tpl[k].value])) })),
        h('button', { type: 'button', onClick: () => guardar({ plantillas: { ...DEFAULT_TEMPLATES } }, 'Plantillas restablecidas.') }, 'Restablecer plantillas'))),
    seccionSeguridad(auto),
    seccion('Respaldo y transferencia',
      h('p', null, ur ? `Último respaldo: ${new Date(ur.fecha).toLocaleString('es')} · ${ur.archivo}${ur.cifrado ? ' (cifrado)' : ''} · ${ur.resultado}.` : 'Aún no has generado un respaldo.'),
      h('div', { class: 'aviso warn' }, 'Si borras los datos del navegador, desinstalas la app o pierdes el dispositivo, perderás la información si no tienes un respaldo.'),
      h('div', { class: 'row' }, h('button', { type: 'button', class: 'primario', onClick: exportarUI }, icono('download'), 'Exportar respaldo'), h('button', { type: 'button', onClick: () => archivo.click() }, icono('upload'), 'Importar respaldo'), archivo),
      h('p', null, h('strong', null, 'Almacenamiento: '), persist),
      h('details', { class: 'det' }, h('summary', null, 'Cómo pasar los datos a otro dispositivo'),
        h('ol', null, h('li', null, 'En el dispositivo de origen: Configuración → Exportar respaldo (con contraseña).'), h('li', null, 'Envía el archivo al otro dispositivo (correo, nube privada, USB).'), h('li', null, 'En el dispositivo nuevo: abre la app → Configuración → Importar respaldo y elige el archivo.'), h('li', null, 'Revisa el resumen, elige "Reemplazar todo" (o "Combinar") y confirma.'), h('li', null, 'Cada dispositivo guarda su propia copia: los cambios posteriores no se sincronizan solos.')))),
    seccion('Instalación y datos de demostración',
      instalar.disponible() ? h('p', null, h('button', { type: 'button', onClick: instalar.lanzar }, 'Instalar la app en este dispositivo')) : h('p', { class: 'muted' }, 'Para instalar: en Chrome (Android) abre el menú ⋮ → "Instalar app" o "Añadir a pantalla de inicio". En computadora, usa el icono de instalar de la barra de direcciones.'),
      h('div', { class: 'row' },
        h('button', { type: 'button', onClick: async () => { await cargarDemo(S.svc); await refrescar(); aviso('Datos de demostración (ficticios) cargados.', 'ok'); } }, 'Cargar datos de demostración'),
        h('button', { type: 'button', onClick: async () => { if (!(await confirmar({ titulo: 'Quitar demostración', mensaje: 'Se eliminarán solo los pacientes de demostración y todo su historial.', confirmar: 'Quitar', peligro: true }))) return; const n = await borrarDemo(S.svc); await refrescar(); aviso(`${n} paciente(s) de demostración eliminados.`, 'ok'); } }, 'Quitar datos de demostración'))),
    seccion('Acerca de y límites',
      h('p', null, `Versión ${APP_VERSION}. Todo se guarda localmente en este dispositivo (IndexedDB). No hay servidor, cuenta ni sincronización; no se envían datos a terceros.`),
      h('ul', null,
        h('li', null, 'El PIN bloquea la pantalla, pero la base de datos del navegador no está cifrada: alguien con acceso al dispositivo desbloqueado podría leerla.'),
        h('li', null, 'Los respaldos cifrados (AES-256) solo son seguros si la contraseña lo es y la guardas aparte.'),
        h('li', null, 'Usa un dispositivo con bloqueo de pantalla propio; evita dispositivos compartidos.')),
      h('button', { type: 'button', class: 'peligro', onClick: async () => {
        if (!(await confirmar({ titulo: 'Borrar todos los datos', mensaje: 'Se borrará TODO de este dispositivo: pacientes, citas, pagos, configuración y PIN. Exporta un respaldo antes si quieres conservar algo.', confirmar: 'Borrar todo', peligro: true, escribir: 'BORRAR TODO' }))) return;
        await S.svc.borrarTodo();
        S.pinActivo = false;
        await refrescar();
        aviso('Todos los datos fueron borrados.', 'ok');
      } }, icono('trash'), 'Borrar todos los datos')));
}

function seccionSeguridad(auto) {
  const pin = S.pinActivo;
  const abrir = (modo) => {
    const actual = h('input', { type: 'password', autocomplete: 'current-password' });
    const n1 = h('input', { type: 'password', autocomplete: 'new-password' });
    const n2 = h('input', { type: 'password', autocomplete: 'new-password' });
    modal({
      titulo: modo === 'quitar' ? 'Quitar PIN' : pin ? 'Cambiar PIN' : 'Crear PIN o contraseña',
      contenido: h('div', null, pin ? campo('PIN actual', actual) : null, modo === 'quitar' ? null : h('div', null, campo('Nuevo PIN o contraseña (mínimo 4 caracteres)', n1), campo('Repetir', n2))),
      acciones: [
        { texto: 'Cancelar' },
        {
          texto: 'Guardar',
          clase: 'primario',
          onClick: async () => {
            if (pin && !(await S.svc.verificarPin(actual.value))) throw new Error('El PIN actual no es correcto.');
            if (modo === 'quitar') {
              await S.svc.quitarPin(actual.value);
              S.pinActivo = false;
            } else {
              if (n1.value !== n2.value) throw new Error('Los PIN no coinciden.');
              await S.svc.definirPin(n1.value);
              S.pinActivo = true;
            }
            await refrescar();
            aviso('Seguridad actualizada.', 'ok');
          },
        },
      ],
    });
  };
  return seccion('Seguridad de acceso',
    h('p', null, pin ? 'El acceso está protegido con PIN o contraseña.' : 'El acceso no está protegido. Se recomienda crear un PIN.'),
    h('div', { class: 'row' },
      h('button', { type: 'button', class: 'primario', onClick: () => abrir('definir') }, icono('lock'), pin ? 'Cambiar PIN' : 'Crear PIN'),
      pin ? h('button', { type: 'button', onClick: () => abrir('quitar') }, 'Quitar PIN') : null,
      pin ? h('button', { type: 'button', onClick: () => S.bloquearAhora() }, 'Bloquear ahora') : null),
    campo('Bloquear tras (minutos sin uso; 0 = nunca)', auto),
    guardarBtn(() => guardar({ autobloqueoMin: Number(auto.value) })),
    h('p', { class: 'muted' }, 'Límite: el PIN protege la pantalla de la app. No cifra los datos guardados en el navegador. Si lo olvidas no hay recuperación: solo borrar datos y restaurar un respaldo.'));
}
