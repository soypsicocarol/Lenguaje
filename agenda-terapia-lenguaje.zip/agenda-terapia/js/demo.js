// Datos FICTICIOS de demostración. Todos los pacientes llevan demo:true para borrarlos fácilmente.

export async function cargarDemo(S) {
  const t = S.hoy();
  const lunes = t; // las series arrancan hoy para que Inicio y Agenda muestren citas enseguida
  const a = await S.crearPaciente({ nombre: 'Luna', apellidos: 'Ejemplo Uno', fechaNacimiento: '2020-05-10', representante: 'Representante Ficticio A', telefono: '+58 414 0000001', modalidadCobro: 'sesion', tarifa: 20, frecuencia: '2 veces por semana', demo: true });
  const b = await S.crearPaciente({ nombre: 'Mateo', apellidos: 'Ejemplo Dos', fechaNacimiento: '2019-02-20', representante: 'Representante Ficticio B', telefono: '+58 424 0000002', modalidadCobro: 'paquete', tarifa: 18, demo: true });
  const c = await S.crearPaciente({ nombre: 'Sofía', apellidos: 'Ejemplo Tres', fechaNacimiento: '2021-08-01', representante: 'Representante Ficticio C', telefono: '+58 412 0000003', modalidadCobro: 'periodo', tarifa: 80, demo: true });
  await S.crearSerie({ patientId: a.id, dias: [{ dia: 1, hora: '15:00' }, { dia: 4, hora: '15:00' }], duracion: 45, fechaInicio: lunes, semanas: 4 }, { permitirConflicto: true });
  await S.crearSerie({ patientId: b.id, dias: [{ dia: 2, hora: '10:00' }], duracion: 45, fechaInicio: lunes, semanas: 8 }, { permitirConflicto: true });
  await S.crearSerie({ patientId: c.id, dias: [{ dia: 3, hora: '16:00' }], duracion: 30, fechaInicio: lunes, semanas: 6 }, { permitirConflicto: true });
  await S.crearPaquete({ patientId: b.id, nombre: 'Paquete de 8 sesiones', cantidadInicial: 8, precio: 144 }, { importe: 72, metodo: 'Transferencia' });
}

export async function borrarDemo(S) {
  const d = await S.cargar();
  let n = 0;
  for (const p of d.patients.filter((x) => x.demo)) {
    await S.eliminarPaciente(p.id);
    n++;
  }
  return n;
}
