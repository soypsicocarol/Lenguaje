# Agenda de Terapia del Lenguaje

Agenda local (PWA) para una terapeuta del lenguaje: sesiones recurrentes y variables, asistencia,
pagos (por sesión, por período, abonos y paquetes), WhatsApp manual, reportes y respaldos.
**Sin Firebase, sin servidor, sin sincronización y sin analítica.** Los datos viven en el dispositivo (IndexedDB).

Implementa el *Brief funcional v1.0 (26/10/2026)*: Fase 1 (MVP) completa.

## Cómo ejecutarla

No hay dependencias ni compilación: son archivos estáticos (HTML + CSS + JavaScript con módulos).

```bash
node scripts/serve.mjs 8080      # http://localhost:8080/   (requiere Node 18+)
npm test                          # 28 pruebas de lógica (Node, sin navegador)
npm run test:e2e                  # 14 pruebas en Chromium real (requiere Playwright)
npm run build                     # copia lo publicable a dist/
```

> Los *service workers* (uso sin conexión) y la instalación solo funcionan en **HTTPS o `localhost`**.

## Cómo instalarla en el teléfono Android (uso diario)

1. Publica la carpeta `dist/` (o la raíz del proyecto) en cualquier hosting estático con HTTPS
   (GitHub Pages, Netlify, Cloudflare Pages, tu propio dominio…). El hosting solo entrega los archivos de la app;
   **nunca recibe datos de pacientes**.
2. Abre la dirección en Chrome del Android (necesita Internet solo esta primera vez).
3. Menú ⋮ → **Instalar app** (o *Añadir a pantalla de inicio*). Queda como una app con su icono.
4. Ábrela una vez con conexión para que guarde todos los archivos. Desde entonces funciona sin Internet.
5. Al abrir por primera vez: **Configuración → crear PIN** y **Exportar respaldo**.

Alternativa sin hosting: conectar el teléfono por USB y usar *Chrome DevTools → Port forwarding* hacia `localhost:8080`.

En computadora: Chrome/Edge → icono de instalar en la barra de direcciones (o Configuración → *Instalar*).

**Actualizar la app:** publica los archivos nuevos y cambia `VERSION` en `sw.js`; la versión nueva se activa al volver a abrirla. Los datos no se tocan.

## Qué incluye

| Módulo | Contenido |
|---|---|
| Inicio | Citas de hoy, por confirmar, próximas, por reprogramar, cancelaciones/inasistencias recientes, cobrado hoy/semana/mes, saldos, paquetes por agotarse, avisos de PIN y respaldo |
| Agenda | Vistas día/semana/mes, búsqueda y filtro por estado, citas, series semanales (1 a 7 días/semana) con vista previa, bloqueos (descansos, vacaciones), advertencia de conflictos |
| Series | Edición de una cita, de "esta y las futuras" o de toda la serie; excluir fechas/pausas; finalizar o extender; sin duplicados al guardar de nuevo |
| Pacientes | Ficha administrativa, edad calculada (no guardada), inactivar (recomendado) o eliminar con confirmación escrita y recuento de consecuencias |
| Asistencia | Programada, confirmada, realizada, cancelada (representante / terapeuta → "por reprogramar"), inasistencia, reprogramada (vinculada, nunca cuenta doble) con historial |
| Pagos | Pagos parciales/completos, múltiples pagos por cobro, pagos inmutables (se **anulan o corrigen** con motivo), cobros por período, paquetes con movimientos y ajustes manuales con motivo |
| WhatsApp | Botón en la ficha y en la cita; plantillas editables; abre `wa.me` con el texto prellenado; **no envía** ni afirma que se envió; estado de contacto manual |
| Reportes | Período, paciente y agrupación; cobrado ≠ pendiente ≠ proyectado; **monedas nunca se suman entre sí**; CSV de pagos, citas y saldos |
| Seguridad | PIN/contraseña (PBKDF2), bloqueo automático y manual, límite de intentos, respaldos cifrados AES-256-GCM, validación de integridad |
| Respaldo | Exportar (con o sin contraseña), importar con resumen y confirmación, *Reemplazar* o *Combinar* sin duplicar |

## Estructura

```
index.html · manifest.webmanifest · sw.js · icons/ · css/styles.css
js/app.js                arranque, rutas, bloqueo automático
js/db.js                 IndexedDB (y almacén en memoria para pruebas)
js/services.js           todas las operaciones de escritura (atómicas, con candado)
js/demo.js               datos ficticios opcionales (fáciles de quitar)
js/core/                 lógica pura y probada: dates, schedule, finance, whatsapp, csv, crypto, backup, constants, util
js/ui/                   pantallas (inicio, agenda, citas, pacientes, pagos, config, respaldo, lock, whatsapp, dom, state)
tests/logic.test.mjs     pruebas de lógica      ·  tests/e2e.mjs  pruebas en navegador
scripts/serve.mjs · build.mjs
docs/SEGURIDAD.md · docs/PRUEBAS.md
```

## Decisiones técnicas relevantes

- **Fechas**: se guardan como fecha local `AAAA-MM-DD` + hora local `HH:MM` + duración. Una cita "lunes 3:00 p. m." no se mueve por cambios de huso u horario de verano.
- **Dinero**: importes redondeados a centésimas; los saldos se calculan siempre a partir de cobros (citas realizadas por sesión, períodos, paquetes) menos pagos válidos. Un pago nunca se infiere de que la cita se haya realizado.
- **Tarifa congelada por cita**: la cita guarda la tarifa/moneda/modalidad vigentes al crearla; cambiar la tarifa del paciente no reescribe el historial.
- **Paquetes idempotentes**: el consumo se recalcula a partir del estado de la cita (un movimiento neto por cita). Guardar, editar o repetir "realizada" no descuenta dos veces; deshacer devuelve la sesión.
- **Series**: cada cita guarda `seriesId` y la fecha original generada (`serieClave`). "Esta y las futuras" divide la serie en dos; las citas editadas individualmente no se tocan.
- **Respaldo**: JSON versionado con huella SHA-256; el PIN no viaja en el respaldo. El archivo se valida por completo antes de modificar nada.
- **Código de país por defecto +58** (editable en Configuración) para teléfonos escritos sin `+`.
- **CSP estricta** (`default-src 'self'`): la app no puede hacer peticiones a otros sitios.

## Límites conocidos

Ver `docs/SEGURIDAD.md`. En resumen: el PIN bloquea la interfaz pero **no cifra** IndexedDB; sin respaldo, borrar datos del navegador o perder el teléfono implica perder todo; cada dispositivo es independiente (no hay sincronización); no hay recuperación de PIN olvidado; las reglas de consumo/cobro no se aplican retroactivamente; los bloqueos no se repiten automáticamente (se crea uno por rango); WhatsApp depende de que la app esté instalada y haya conexión.

## Datos de demostración

Configuración → *Cargar datos de demostración* crea 3 pacientes ficticios con series y un paquete; *Quitar datos de demostración* los borra por completo. No uses datos reales hasta haber probado un respaldo y su restauración.
