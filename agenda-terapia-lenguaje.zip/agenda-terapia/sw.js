// Service worker: guarda los archivos de la app para que abra sin Internet.
// Los DATOS no pasan por aquí: viven en IndexedDB. Cambia VERSION al publicar cambios.
const VERSION = 'v1.0.0';
const CACHE = `agenda-lenguaje-${VERSION}`;
const ARCHIVOS = [
  './', 'index.html', 'manifest.webmanifest', 'css/styles.css',
  'icons/icon.svg', 'icons/icon-192.png', 'icons/icon-512.png', 'icons/icon-maskable-512.png', 'icons/apple-touch-icon.png',
  'js/app.js', 'js/db.js', 'js/services.js', 'js/demo.js',
  'js/core/util.js', 'js/core/dates.js', 'js/core/constants.js', 'js/core/schedule.js', 'js/core/finance.js',
  'js/core/whatsapp.js', 'js/core/csv.js', 'js/core/crypto.js', 'js/core/backup.js',
  'js/ui/dom.js', 'js/ui/state.js', 'js/ui/inicio.js', 'js/ui/agenda.js', 'js/ui/citas.js', 'js/ui/pacientes.js',
  'js/ui/pagos.js', 'js/ui/config.js', 'js/ui/respaldo.js', 'js/ui/lock.js', 'js/ui/whatsapp.js',
];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(ARCHIVOS)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys().then((ks) => Promise.all(ks.filter((k) => k.startsWith('agenda-lenguaje-') && k !== CACHE).map((k) => caches.delete(k)))).then(() => self.clients.claim()),
  );
});

self.addEventListener('fetch', (e) => {
  const req = e.request;
  if (req.method !== 'GET' || new URL(req.url).origin !== self.location.origin) return;
  e.respondWith(
    caches.match(req, { ignoreSearch: true }).then(
      (hit) =>
        hit ||
        fetch(req)
          .then((res) => {
            if (res.ok) caches.open(CACHE).then((c) => c.put(req, res.clone()));
            return res;
          })
          .catch(() => (req.mode === 'navigate' ? caches.match('index.html') : Response.error())),
    ),
  );
});
