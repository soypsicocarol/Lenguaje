// Servidor estático mínimo para desarrollo y pruebas: node scripts/serve.mjs [puerto] [carpeta]
import http from 'node:http';
import { readFile, stat } from 'node:fs/promises';
import { extname, join, normalize, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json', '.webmanifest': 'application/manifest+json', '.svg': 'image/svg+xml', '.png': 'image/png' };

export function iniciarServidor(puerto = 8080, carpeta = fileURLToPath(new URL('..', import.meta.url))) {
  const base = resolve(carpeta);
  const srv = http.createServer(async (req, res) => {
    try {
      let ruta = decodeURIComponent(new URL(req.url, 'http://x').pathname);
      if (ruta.endsWith('/')) ruta += 'index.html';
      const abs = normalize(join(base, ruta));
      if (!abs.startsWith(base)) throw new Error('fuera');
      if (!(await stat(abs)).isFile()) throw new Error('no archivo');
      res.writeHead(200, { 'Content-Type': MIME[extname(abs)] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
      res.end(await readFile(abs));
    } catch {
      res.writeHead(404);
      res.end('No encontrado');
    }
  });
  return new Promise((ok) => srv.listen(puerto, () => ok(srv)));
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const p = Number(process.argv[2]) || 8080;
  await iniciarServidor(p, process.argv[3]);
  console.log(`Agenda disponible en http://localhost:${p}/`);
}
