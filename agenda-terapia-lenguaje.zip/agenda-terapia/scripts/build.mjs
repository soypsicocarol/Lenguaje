// La app no necesita compilación: son archivos estáticos. Este script copia lo publicable a dist/.
import { cp, mkdir, rm } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { join } from 'node:path';

const raiz = fileURLToPath(new URL('..', import.meta.url));
const dist = join(raiz, 'dist');
await rm(dist, { recursive: true, force: true });
await mkdir(dist, { recursive: true });
for (const f of ['index.html', 'manifest.webmanifest', 'sw.js', 'css', 'icons', 'js']) await cp(join(raiz, f), join(dist, f), { recursive: true });
console.log('Versión instalable lista en dist/ (sírvela por HTTPS o localhost).');
