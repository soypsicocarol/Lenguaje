// Pruebas de la lógica pura (sin base de datos).
import { test, describe } from 'node:test';
import assert from 'node:assert/strict';
import { addDays, addMonths, ageFrom, dow, fmtAge, fmtTime, isValidDate, isValidTime, startOfWeek, diffDays, endOfMonth } from '../js/core/dates.js';
import { parseAmount, fmtMoney, sum } from '../js/core/money.js';
import { generateOccurrences, activeOccurrences, validateSeries, resolveEnd } from '../js/domain/recurrence.js';
import { findConflicts, blockIntervalsForDate, validateBlock } from '../js/domain/conflicts.js';
import { normalizePhone, buildWhatsAppLink, fillTemplate } from '../js/domain/whatsapp.js';
import { obligationSummary, balancesByCurrency, incomeReport, estimatedScheduled } from '../js/domain/finance.js';
import { packageSummary, pickPackage } from '../js/domain/packages.js';
import { toCSV, csvCell } from '../js/domain/csv.js';
import { mergeSettings } from '../js/core/defaults.js';

describe('fechas', () => {
  test('validación y aritmética', () => {
    assert.ok(isValidDate('2026-02-28'));
    assert.ok(!isValidDate('2026-02-30'));
    assert.ok(!isValidDate('26-02-01'));
    assert.ok(isValidTime('09:05'));
    assert.ok(!isValidTime('24:00'));
    assert.equal(addDays('2026-12-31', 1), '2027-01-01');
    assert.equal(addMonths('2026-01-31', 1), '2026-02-28');
    assert.equal(dow('2026-11-02'), 1); // lunes
    assert.equal(startOfWeek('2026-11-08'), '2026-11-02'); // domingo -> lunes anterior
    assert.equal(diffDays('2026-03-01', '2026-03-29'), 28);
    assert.equal(endOfMonth('2026-02-10'), '2026-02-28');
  });
  test('cambio de hora no desfasa los días (DST)', () => {
    // Marzo/noviembre de EE. UU. cambian la hora: sumar 7 días siempre da el mismo día de semana.
    let d = '2026-03-02';
    for (let i = 0; i < 60; i++) {
      d = addDays(d, 7);
      assert.equal(dow(d), 1);
    }
  });
  test('la edad se calcula desde la fecha de nacimiento', () => {
    assert.deepEqual(ageFrom('2020-03-14', '2026-03-13'), { years: 5, months: 11 });
    assert.deepEqual(ageFrom('2020-03-14', '2026-03-14'), { years: 6, months: 0 });
    assert.equal(fmtAge('2020-03-14', '2026-10-26'), '6 años y 7 meses');
    assert.equal(fmtAge('2026-08-01', '2026-10-26'), '2 meses');
  });
  test('formato de hora', () => {
    assert.equal(fmtTime('15:00'), '3:00 p. m.');
    assert.equal(fmtTime('00:30'), '12:30 a. m.');
    assert.equal(fmtTime('12:00'), '12:00 p. m.');
  });
});

describe('dinero', () => {
  test('parseAmount acepta formatos habituales', () => {
    assert.equal(parseAmount('12,50'), 12.5);
    assert.equal(parseAmount('12.50'), 12.5);
    assert.equal(parseAmount('1.234,56'), 1234.56);
    assert.equal(parseAmount('1,234.56'), 1234.56);
    assert.ok(Number.isNaN(parseAmount('abc')));
    assert.ok(Number.isNaN(parseAmount('-5')));
    assert.ok(Number.isNaN(parseAmount('')));
  });
  test('sumas sin error de coma flotante', () => {
    assert.equal(sum([0.1, 0.2]), 0.3);
    assert.equal(sum([19.99, 0.01, 0.1]), 20.1);
  });
  test('formato con código de moneda', () => {
    assert.equal(fmtMoney(1234.5, 'USD'), '1234,50 USD'.replace('1234', new Intl.NumberFormat('es').format(1234)));
  });
});

describe('recurrencia', () => {
  const dias = [{ dow: 1, inicio: '15:00', duracion: 45 }, { dow: 4, inicio: '15:00', duracion: 45 }];
  test('lunes y jueves durante 4 semanas = 8 fechas correctas', () => {
    const s = { id: 's1', fechaInicio: '2026-11-02', dias, repeticiones: 4 };
    const occ = generateOccurrences(s).map((o) => o.fecha);
    assert.deepEqual(occ, ['2026-11-02', '2026-11-05', '2026-11-09', '2026-11-12', '2026-11-16', '2026-11-19', '2026-11-23', '2026-11-26']);
  });
  test('empezar a mitad de semana: cada día aparece exactamente n veces', () => {
    const s = { id: 's1', fechaInicio: '2026-11-04', dias, repeticiones: 4 }; // miércoles
    const occ = generateOccurrences(s);
    assert.equal(occ.filter((o) => o.dow === 1).length, 4);
    assert.equal(occ.filter((o) => o.dow === 4).length, 4);
  });
  test('fecha final y semanas: gana la más temprana', () => {
    const s = { fechaInicio: '2026-11-02', repeticiones: 10, fechaFin: '2026-11-15' };
    assert.equal(resolveEnd(s), '2026-11-15');
  });
  test('excepciones y vacaciones se omiten', () => {
    const s = { id: 's1', fechaInicio: '2026-11-02', dias, repeticiones: 4, excepciones: ['2026-11-05'], pausas: [{ desde: '2026-11-16', hasta: '2026-11-20' }] };
    const occ = activeOccurrences(s).map((o) => o.fecha);
    assert.ok(!occ.includes('2026-11-05'));
    assert.ok(!occ.includes('2026-11-16') && !occ.includes('2026-11-19'));
    assert.equal(occ.length, 5);
  });
  test('serie abierta usa el horizonte', () => {
    const s = { id: 's1', fechaInicio: '2026-11-02', dias: [dias[0]] };
    assert.equal(activeOccurrences(s, { horizon: '2026-11-30' }).length, 5);
    assert.throws(() => generateOccurrences(s));
  });
  test('validación', () => {
    assert.ok(validateSeries({ patientId: 'p', fechaInicio: '2026-11-02', dias: [] }).length > 0);
    assert.ok(validateSeries({ patientId: 'p', fechaInicio: '2026-11-02', dias: [dias[0], dias[0]] }).length > 0);
    assert.ok(validateSeries({ patientId: 'p', fechaInicio: '2026-11-02', dias, fechaFin: '2026-10-01' }).length > 0);
    assert.equal(validateSeries({ patientId: 'p', fechaInicio: '2026-11-02', dias, repeticiones: 4 }).length, 0);
    assert.ok(validateSeries({ patientId: 'p', fechaInicio: '2026-11-02', dias, repeticiones: 0.5 }).length > 0);
  });
});

describe('conflictos', () => {
  const a = { id: 'a1', fecha: '2026-11-02', inicio: '15:00', duracion: 45, estado: 'programada' };
  test('detecta solape y permite citas contiguas', () => {
    assert.equal(findConflicts({ fecha: '2026-11-02', inicio: '15:30', duracion: 45 }, { appointments: [a] }).citas.length, 1);
    assert.equal(findConflicts({ fecha: '2026-11-02', inicio: '15:45', duracion: 45 }, { appointments: [a] }).citas.length, 0);
    assert.equal(findConflicts({ fecha: '2026-11-03', inicio: '15:00', duracion: 45 }, { appointments: [a] }).citas.length, 0);
  });
  test('las citas canceladas o reprogramadas no ocupan horario', () => {
    for (const estado of ['cancelada_representante', 'cancelada_terapeuta', 'reprogramada']) {
      assert.equal(findConflicts({ fecha: '2026-11-02', inicio: '15:00', duracion: 45 }, { appointments: [{ ...a, estado }] }).citas.length, 0);
    }
  });
  test('ignora la propia cita al editarla', () => {
    assert.equal(findConflicts({ fecha: '2026-11-02', inicio: '15:10', duracion: 45 }, { appointments: [a], ignoreId: 'a1' }).citas.length, 0);
  });
  test('bloqueos únicos, de varios días y recurrentes', () => {
    const unico = { fechaInicio: '2026-11-03', fechaFin: '2026-11-03', horaInicio: '12:00', horaFin: '14:00' };
    assert.equal(findConflicts({ fecha: '2026-11-03', inicio: '13:00', duracion: 30 }, { blocks: [unico] }).bloqueos.length, 1);
    assert.equal(findConflicts({ fecha: '2026-11-03', inicio: '14:00', duracion: 30 }, { blocks: [unico] }).bloqueos.length, 0);
    const vacaciones = { fechaInicio: '2026-12-21', fechaFin: '2026-12-26', todoElDia: true };
    assert.equal(findConflicts({ fecha: '2026-12-24', inicio: '09:00', duracion: 30 }, { blocks: [vacaciones] }).bloqueos.length, 1);
    assert.equal(findConflicts({ fecha: '2026-12-27', inicio: '09:00', duracion: 30 }, { blocks: [vacaciones] }).bloqueos.length, 0);
    const rec = { fechaInicio: '2026-11-02', fechaFin: '2026-11-02', horaInicio: '12:00', horaFin: '13:00', repite: { dias: [1, 3], hasta: '2026-12-31' } };
    assert.deepEqual(blockIntervalsForDate(rec, '2026-11-09'), [[720, 780]]);
    assert.deepEqual(blockIntervalsForDate(rec, '2026-11-10'), []);
    assert.deepEqual(blockIntervalsForDate(rec, '2027-01-04'), []);
    assert.ok(validateBlock({ fechaInicio: '2026-11-03', fechaFin: '2026-11-03', horaInicio: '14:00', horaFin: '12:00' }).length > 0);
  });
  test('fuera del horario de atención', () => {
    const horario = mergeSettings().horario;
    assert.equal(findConflicts({ fecha: '2026-11-07', inicio: '10:00', duracion: 30 }, { horario }).fueraDeHorario, true); // sábado
    assert.equal(findConflicts({ fecha: '2026-11-02', inicio: '16:45', duracion: 30 }, { horario }).fueraDeHorario, true);
    assert.equal(findConflicts({ fecha: '2026-11-02', inicio: '10:00', duracion: 30 }, { horario }).fueraDeHorario, false);
  });
});

describe('WhatsApp manual', () => {
  test('normaliza teléfonos', () => {
    assert.equal(normalizePhone('+58 414-123 4567').digits, '584141234567');
    assert.equal(normalizePhone('0414 1234567', '58').digits, '584141234567');
    assert.equal(normalizePhone('4141234567', '58').digits, '584141234567');
    assert.equal(normalizePhone('0058 414 1234567').digits, '584141234567');
    assert.equal(normalizePhone('+1 305 555 0100').digits, '13055550100');
    assert.ok(!normalizePhone('123').ok);
    assert.ok(!normalizePhone('abc').ok);
    assert.ok(!normalizePhone('').ok);
  });
  test('el texto se codifica correctamente en el enlace', () => {
    const url = buildWhatsAppLink('584141234567', 'Hola & ¿qué tal? 100% #1\nlínea 2');
    assert.ok(url.startsWith('https://wa.me/584141234567?text='));
    const decoded = decodeURIComponent(url.split('?text=')[1]);
    assert.equal(decoded, 'Hola & ¿qué tal? 100% #1\nlínea 2');
    assert.ok(!url.includes(' ') && !url.includes('\n'));
  });
  test('plantillas: variables y marcadores para lo que falta', () => {
    assert.equal(fillTemplate('Hola {nino}, el {fecha}', { nino: 'Luna', fecha: '' }), 'Hola Luna, el [fecha]');
  });
});

describe('finanzas', () => {
  const ob = { id: 'o1', importe: 100, moneda: 'USD', estado: 'activa' };
  const pay = (importe, extra = {}) => ({ id: Math.random().toString(), importe, moneda: 'USD', obligacionId: 'o1', estado: 'vigente', fecha: '2026-11-02', ...extra });
  test('saldo pendiente, parcial y saldada', () => {
    assert.equal(obligationSummary(ob, []).estado, 'pendiente');
    const p = obligationSummary(ob, [pay(30.1)]);
    assert.equal(p.pendiente, 69.9);
    assert.equal(p.estado, 'parcial');
    assert.equal(obligationSummary(ob, [pay(30.1), pay(69.9)]).estado, 'saldada');
  });
  test('pagos anulados no cuentan', () => {
    assert.equal(obligationSummary(ob, [pay(100, { estado: 'anulado' })]).pendiente, 100);
  });
  test('sobrepago queda a favor', () => {
    const s = obligationSummary(ob, [pay(120)]);
    assert.equal(s.aFavor, 20);
    assert.equal(s.pendiente, 0);
  });
  test('monedas separadas, nunca sumadas', () => {
    const obs = [ob, { id: 'o2', importe: 50, moneda: 'VES', estado: 'activa' }];
    const b = balancesByCurrency(obs, [pay(40)]);
    assert.equal(b.USD.pendiente, 60);
    assert.equal(b.VES.pendiente, 50);
    const inc = incomeReport([pay(40), pay(10, { moneda: 'VES', obligacionId: 'o2' })], '2026-11-01', '2026-11-30');
    assert.equal(inc.USD.total, 40);
    assert.equal(inc.VES.total, 10);
  });
  test('ingresos: solo pagos recibidos en el período', () => {
    const inc = incomeReport([pay(40, { fecha: '2026-11-02' }), pay(60, { fecha: '2026-12-01' }), pay(25, { fecha: '2026-11-03', estado: 'anulado' })], '2026-11-01', '2026-11-30');
    assert.equal(inc.USD.total, 40);
    assert.deepEqual(inc.USD.mes, { '2026-11': 40 });
  });
  test('el estimado es solo de citas abiertas y se calcula aparte', () => {
    const patients = [{ id: 'p1', modalidadCobro: 'sesion', tarifa: 20, moneda: 'USD' }, { id: 'p2', modalidadCobro: 'paquete', tarifa: 15, moneda: 'USD' }];
    const appts = [
      { patientId: 'p1', fecha: '2026-11-09', estado: 'programada' },
      { patientId: 'p1', fecha: '2026-11-10', estado: 'confirmada' },
      { patientId: 'p1', fecha: '2026-11-11', estado: 'realizada' },
      { patientId: 'p2', fecha: '2026-11-12', estado: 'programada' },
    ];
    assert.deepEqual(estimatedScheduled(appts, patients, { moneda: 'USD' }, '2026-11-01', '2026-11-30'), { USD: 40 });
  });
});

describe('paquetes (cálculo)', () => {
  const pkg = { id: 'k1', cantidadInicial: 8, fechaCompra: '2026-11-01', estado: 'activo' };
  test('disponibles = iniciales - consumidas + ajustes', () => {
    const movs = [
      { packageId: 'k1', tipo: 'consumo', delta: -1 },
      { packageId: 'k1', tipo: 'consumo', delta: -1 },
      { packageId: 'k1', tipo: 'devolucion', delta: 1 },
      { packageId: 'k1', tipo: 'ajuste', delta: 2 },
    ];
    const s = packageSummary(pkg, movs, '2026-11-10');
    assert.deepEqual([s.iniciales, s.consumidas, s.ajustes, s.disponibles, s.estado], [8, 1, 2, 9, 'activo']);
  });
  test('estados: agotado y vencido; elección del paquete', () => {
    assert.equal(packageSummary({ ...pkg, cantidadInicial: 1 }, [{ packageId: 'k1', tipo: 'consumo', delta: -1 }], '2026-11-10').estado, 'agotado');
    assert.equal(packageSummary({ ...pkg, vigencia: '2026-11-05' }, [], '2026-11-10').estado, 'vencido');
    assert.equal(pickPackage([{ ...pkg, vigencia: '2026-11-05' }], [], '2026-11-10', '2026-11-10'), null);
    assert.equal(pickPackage([pkg], [], '2026-11-10', '2026-11-10').id, 'k1');
  });
});

describe('CSV', () => {
  test('escapa separadores, comillas y fórmulas', () => {
    assert.equal(csvCell('a;b'), '"a;b"');
    assert.equal(csvCell('di "hola"'), '"di ""hola"""');
    assert.equal(csvCell('=SUM(A1)'), "'=SUM(A1)");
    assert.equal(csvCell(12.5), '12.5');
    const csv = toCSV(['A', 'B'], [[1, 'x']]);
    assert.ok(csv.startsWith('﻿A;B\r\n'));
  });
});
