// Utilidades de prueba: base de datos IndexedDB falsa (en memoria) y datos ficticios.
import 'fake-indexeddb/auto';
import { IDBFactory, IDBKeyRange } from 'fake-indexeddb';
import { initStore, closeStore } from '../js/core/store.js';
import { savePatient } from '../js/domain/patients.js';

let n = 0;
export async function freshDB() {
  closeStore();
  await initStore(`test-db-${Date.now()}-${n++}`, { indexedDB: new IDBFactory(), IDBKeyRange });
}

export async function mkPatient(over = {}) {
  return savePatient({
    nombre: 'Niño', apellidos: 'Prueba', fechaNacimiento: '2020-01-15', representante: 'Representante Prueba',
    telefono: '+58 400 0000000', fechaIngreso: '2026-01-05', modalidadCobro: 'sesion', tarifa: 20, moneda: 'USD', ...over,
  });
}

// Fechas fijas de prueba (2026): lunes 2026-11-02
export const LUN = '2026-11-02';
