// Pruebas de lógica (sin navegador): criterios de aceptación del brief sobre una base en memoria.
// Ejecutar: node --test tests/logic.test.mjs
import test from 'node:test';
import assert from 'node:assert/strict';
import { crearMemoria } from '../js/db.js';
import { crearServicios } from '../js/services.js';
import { ConflictError, ValidationError } from '../js/core/util.js';
import { formatAge, addDays, dayOfWeek, startOfWeek } from '../js/core/dates.js';
import { libroPaciente, ingresosPorPeriodo, saldoPaquete, totalPorMoneda, proyectado } from '../js/core/finance.js';
import { normalizarTelefono, enlaceWhatsApp, aplicarPlantilla } from '../js/core/whatsapp.js';
import { cifrarRespaldo, abrirCifrado, validarRespaldo, leerArchivo } from '../js/core/backup.js';
import { hashSecreto, verificarSecreto } from '../js/core/crypto.js';
import { aCSV } from '../js/core/csv.js';

// "Hoy" simulado: martes 27 oct 2026, 10:00 hora local. Lunes siguiente: 2 nov 2026.
const AHORA = new Date(2026, 9, 27, 10, 0, 0);
function nuevo() {
  const db = crearMemoria();
  let n = 0;
  const S = crearServicios(db, { ahora: () => AHORA, nuevoId: () => 'id-' + ++n });
  return { db, S };
}
const paciente = (S, extra = {}) =>
  S.crearPaciente({ nombre: 'Luna', apellidos: 'Prueba Ficticia', fechaNacimiento: '2020-03-15', representante: 'Rep. Ficticio', telefono: '0414-5550101', modalidadCobro: 'sesion', tarifa: 20, ...extra });
const serieInput = (patientId, extra = {}) => ({ id: 'serie-1', patientId, dias: [{ dia: 1, hora: '15:00' }, { dia: 4, hora: '15:00' }], duracion: 45, fechaInicio: '2026-11-02', semanas: 4, ...extra });

test('Paciente: crear, editar, buscar datos, edad calculada e inactivar', async () => {
  const { S } = nuevo();
  const p = await paciente(S);
  assert.equal(p.telefono, '+584145550101');
  assert.equal(p.estado, 'activo');
  assert.equal(formatAge('2020-03-15', '2026-10-27'), '6 años 7 meses');
  assert.equal(p.edad, undefined, 'no se almacena una edad fija');
  const e = await S.actualizarPaciente(p.id, { ...p, representante: 'Otra Persona' });
  assert.equal(e.representante, 'Otra Persona');
  await S.cambiarEstadoPaciente(p.id, false);
  const d = await S.cargar();
  assert.equal(d.patients[0].estado, 'inactivo');
  await assert.rejects(() => S.crearCita({ patientId: p.id, fecha: '2026-11-02', inicio: '15:00', duracion: 45 }), ValidationError);
  await assert.rejects(() => S.crearPaciente({ nombre: '', representante: 'x' }), ValidationError);
  await assert.rejects(() => S.crearPaciente({ nombre: 'A', representante: 'B', telefono: '123' }), ValidationError);
});

test('Eliminar paciente: borra en cascada y informa la huella', async () => {
  const { S } = nuevo();
  const p = await paciente(S);
  await S.crearCita({ patientId: p.id, fecha: '2026-11-03', inicio: '10:00', duracion: 45 });
  await S.registrarPago({ patientId: p.id, fecha: '2026-10-27', importe: 5, metodo: 'Efectivo' });
  const h = await S.huellaPaciente(p.id);
  assert.equal(h.citas, 1);
  assert.equal(h.pagos, 1);
  await S.eliminarPaciente(p.id);
  const d = await S.cargar();
  assert.equal(d.patients.length + d.appointments.length + d.payments.length, 0);
});

test('Recurrencia: lunes y jueves durante 4 semanas generan las fechas correctas sin duplicados', async () => {
  const { S } = nuevo();
  const p = await paciente(S);
  const inp = serieInput(p.id);
  const prev = await S.vistaPreviaSerie(inp);
  assert.deepEqual(prev.map((r) => r.fecha), ['2026-11-02', '2026-11-05', '2026-11-09', '2026-11-12', '2026-11-16', '2026-11-19', '2026-11-23', '2026-11-26']);
  const r = await S.crearSerie(inp);
  assert.equal(r.creadas, 8);
  // guardar de nuevo la misma serie no duplica
  const r2 = await S.crearSerie(inp);
  assert.equal(r2.yaExistia, true);
  const d = await S.cargar();
  assert.equal(d.appointments.length, 8);
  assert.equal(new Set(d.appointments.map((a) => a.fecha + a.inicio)).size, 8);
  assert.ok(d.appointments.every((a) => a.seriesId === 'serie-1'));
});

test('Recurrencia: 4 semanas desde un miércoles también da 4 lunes y 4 jueves', async () => {
  const { S } = nuevo();
  const p = await paciente(S);
  const prev = await S.vistaPreviaSerie(serieInput(p.id, { fechaInicio: '2026-11-04' }));
  assert.equal(prev.length, 8);
  assert.equal(prev.filter((r) => dayOfWeek(r.fecha) === 1).length, 4);
  assert.equal(prev.filter((r) => dayOfWeek(r.fecha) === 4).length, 4);
});

test('Recurrencia: fecha final, excepciones y validaciones', async () => {
  const { S } = nuevo();
  const p = await paciente(S);
  const prev = await S.vistaPreviaSerie(serieInput(p.id, { semanas: null, fechaFin: '2026-11-10', excepciones: ['2026-11-05'] }));
  assert.deepEqual(prev.map((r) => r.fecha), ['2026-11-02', '2026-11-09']);
  await assert.rejects(() => S.vistaPreviaSerie(serieInput(p.id, { semanas: null })), ValidationError);
  await assert.rejects(() => S.vistaPreviaSerie(serieInput(p.id, { dias: [] })), ValidationError);
  await assert.rejects(() => S.vistaPreviaSerie(serieInput(p.id, { fechaFin: '2026-10-01', semanas: null })), ValidationError);
});

test('Edición individual: cambia una sola cita y las demás quedan iguales', async () => {
  const { S } = nuevo();
  const p = await paciente(S);
  await S.crearSerie(serieInput(p.id));
  const antes = (await S.cargar()).appointments;
  const objetivo = antes.find((a) => a.fecha === '2026-11-09');
  await S.editarCitaSerie(objetivo.id, 'esta', { fecha: '2026-11-10', inicio: '16:00', duracion: 60 });
  const despues = (await S.cargar()).appointments;
  const cambiada = despues.find((a) => a.id === objetivo.id);
  assert.deepEqual([cambiada.fecha, cambiada.inicio, cambiada.duracion, cambiada.editadaIndividual], ['2026-11-10', '16:00', 60, true]);
  for (const a of antes.filter((x) => x.id !== objetivo.id)) {
    const b = despues.find((x) => x.id === a.id);
    assert.deepEqual([b.fecha, b.inicio, b.duracion], [a.fecha, a.inicio, a.duracion]);
  }
});

test('Edición de futuras: las pasadas (anteriores) no se modifican y la serie se divide sin duplicar', async () => {
  const { S } = nuevo();
  const p = await paciente(S);
  await S.crearSerie(serieInput(p.id));
  const antes = (await S.cargar()).appointments;
  const desde = antes.find((a) => a.fecha === '2026-11-16'); // lunes
  await S.editarCitaSerie(desde.id, 'futuras', { fecha: '2026-11-16', inicio: '17:00', duracion: 30 });
  const d = await S.cargar();
  for (const a of d.appointments) {
    if (a.fecha < '2026-11-16') {
      const o = antes.find((x) => x.id === a.id);
      assert.deepEqual([a.fecha, a.inicio, a.duracion], [o.fecha, o.inicio, o.duracion], 'las anteriores no cambian');
    }
  }
  const lunes = d.appointments.filter((a) => dayOfWeek(a.fecha) === 1 && a.fecha >= '2026-11-16');
  assert.ok(lunes.every((a) => a.inicio === '17:00' && a.duracion === 30));
  const jueves = d.appointments.filter((a) => dayOfWeek(a.fecha) === 4 && a.fecha >= '2026-11-16');
  assert.ok(jueves.every((a) => a.inicio === '15:00' && a.duracion === 30), 'jueves conserva la hora y toma la duración');
  assert.equal(d.appointments.length, 8);
  assert.equal(d.series.length, 2);
  const A = d.series.find((s) => s.id === 'serie-1');
  assert.equal(A.fechaFin, '2026-11-15');
});

test('Edición de toda la serie con cambio de día desplaza las citas modificables', async () => {
  const { S } = nuevo();
  const p = await paciente(S);
  await S.crearSerie(serieInput(p.id));
  const lunes = (await S.cargar()).appointments.find((a) => a.fecha === '2026-11-02');
  await S.editarCitaSerie(lunes.id, 'toda', { fecha: '2026-11-03', inicio: '15:00', duracion: 45 }); // lunes -> martes
  const d = await S.cargar();
  const dows = [...new Set(d.appointments.map((a) => dayOfWeek(a.fecha)))].sort();
  assert.deepEqual(dows, [2, 4]);
  assert.equal(d.appointments.length, 8);
});

test('Conflictos: dos citas solapadas generan advertencia y solo se guardan con confirmación', async () => {
  const { S } = nuevo();
  const p = await paciente(S);
  const q = await paciente(S, { nombre: 'Sol' });
  await S.crearCita({ patientId: p.id, fecha: '2026-11-02', inicio: '15:00', duracion: 45 });
  await assert.rejects(
    () => S.crearCita({ patientId: q.id, fecha: '2026-11-02', inicio: '15:30', duracion: 45 }),
    (e) => e instanceof ConflictError && e.info.citas.length === 1,
  );
  assert.equal((await S.cargar()).appointments.length, 1);
  // adyacentes NO chocan
  await S.crearCita({ patientId: q.id, fecha: '2026-11-02', inicio: '15:45', duracion: 45 });
  await S.crearCita({ patientId: q.id, fecha: '2026-11-02', inicio: '15:30', duracion: 10 }, { permitirConflicto: true });
  assert.equal((await S.cargar()).appointments.length, 3);
});

test('Bloqueos: advierten al crear una cita dentro del horario bloqueado y permiten editar/eliminar', async () => {
  const { S } = nuevo();
  const p = await paciente(S);
  const b = await S.crearBloqueo({ fechaInicio: '2026-11-02', horaInicio: '12:00', fechaFin: '2026-11-02', horaFin: '14:00', motivo: 'Reunión' });
  await assert.rejects(() => S.crearCita({ patientId: p.id, fecha: '2026-11-02', inicio: '13:00', duracion: 45 }), (e) => e instanceof ConflictError && e.info.bloqueos.length === 1);
  await S.actualizarBloqueo(b.bloqueo.id, { fechaInicio: '2026-11-02', horaInicio: '12:00', fechaFin: '2026-11-02', horaFin: '12:30', motivo: 'Reunión corta' });
  await S.crearCita({ patientId: p.id, fecha: '2026-11-02', inicio: '13:00', duracion: 45 });
  // vacaciones de varios días
  await S.crearBloqueo({ fechaInicio: '2026-12-24', horaInicio: '00:00', fechaFin: '2026-12-27', horaFin: '24:00', motivo: 'Vacaciones' });
  await assert.rejects(() => S.crearCita({ patientId: p.id, fecha: '2026-12-26', inicio: '09:00', duracion: 45 }), ConflictError);
  await S.eliminarBloqueo(b.bloqueo.id);
  assert.equal((await S.cargar()).blocks.length, 1);
  await assert.rejects(() => S.crearBloqueo({ fechaInicio: '2026-11-02', horaInicio: '14:00', horaFin: '13:00', motivo: 'x' }), ValidationError);
});

test('Series con conflicto: la vista previa los marca y no se crean sin confirmación', async () => {
  const { S } = nuevo();
  const p = await paciente(S);
  const q = await paciente(S, { nombre: 'Sol' });
  await S.crearCita({ patientId: q.id, fecha: '2026-11-05', inicio: '15:00', duracion: 45 });
  const prev = await S.vistaPreviaSerie(serieInput(p.id));
  assert.deepEqual(prev.filter((r) => r.conflicto).map((r) => r.fecha), ['2026-11-05']);
  await assert.rejects(() => S.crearSerie(serieInput(p.id)), ConflictError);
  const r = await S.crearSerie(serieInput(p.id), { incluir: prev.filter((x) => !x.conflicto).map((x) => x.clave) });
  assert.equal(r.creadas, 7);
});

test('Asistencia y paquete: 8 sesiones bajan a 7 una sola vez aunque se guarde/edite de nuevo', async () => {
  const { S } = nuevo();
  const p = await paciente(S, { modalidadCobro: 'paquete' });
  const k = await S.crearPaquete({ patientId: p.id, nombre: 'Paquete 8', cantidadInicial: 8, precio: 120 });
  const { cita } = await S.crearCita({ patientId: p.id, fecha: '2026-10-26', inicio: '09:00', duracion: 45 });
  await S.cambiarEstadoCita(cita.id, 'realizada');
  await S.cambiarEstadoCita(cita.id, 'realizada');
  await S.actualizarCita(cita.id, { nota: 'edición posterior' });
  await S.cambiarEstadoCita(cita.id, 'confirmada'); // deshacer devuelve la sesión
  await S.cambiarEstadoCita(cita.id, 'realizada'); // y vuelve a descontar una sola vez
  let d = await S.cargar();
  const s = saldoPaquete(d.packages[0], d.movements);
  assert.equal(s.disponibles, 7);
  assert.equal(s.consumidas, 1);
  assert.equal(k.cantidadInicial, 8);
});

test('Cancelación e inasistencia: el efecto en el paquete sigue la regla configurada', async () => {
  const { S } = nuevo();
  const p = await paciente(S, { modalidadCobro: 'paquete' });
  await S.crearPaquete({ patientId: p.id, nombre: 'P', cantidadInicial: 8, precio: 0 });
  const mk = async (hora) => (await S.crearCita({ patientId: p.id, fecha: '2026-10-20', inicio: hora, duracion: 45 })).cita;
  const a = await mk('09:00');
  const b = await mk('10:00');
  const c = await mk('11:00');
  await S.cambiarEstadoCita(a.id, 'cancelada_representante', { motivo: 'Enfermo' });
  await S.cambiarEstadoCita(b.id, 'inasistencia');
  let d = await S.cargar();
  assert.equal(saldoPaquete(d.packages[0], d.movements).disponibles, 8, 'por defecto no descuentan');
  await S.guardarAjustes({ reglasPaquete: { canceladaRepresentante: true, inasistencia: true } });
  await S.cambiarEstadoCita(c.id, 'cancelada_terapeuta');
  await S.cambiarEstadoCita(a.id, 'programada');
  await S.cambiarEstadoCita(a.id, 'cancelada_representante');
  await S.cambiarEstadoCita(b.id, 'programada');
  await S.cambiarEstadoCita(b.id, 'inasistencia');
  d = await S.cargar();
  assert.equal(saldoPaquete(d.packages[0], d.movements).disponibles, 6, 'cancelada repr. e inasistencia descuentan 1 cada una, sin duplicar');
  assert.equal(d.appointments.find((x) => x.id === c.id).pendienteReprogramar, true, 'cancelada por terapeuta queda para reprogramar');
});

test('Reprogramar: la original queda vinculada y no se cuentan dos sesiones realizadas', async () => {
  const { S } = nuevo();
  const p = await paciente(S);
  const o = (await S.crearCita({ patientId: p.id, fecha: '2026-11-03', inicio: '10:00', duracion: 45 })).cita;
  const r = await S.reprogramarCita(o.id, { fecha: '2026-11-04', inicio: '11:00' });
  assert.equal(r.original.estado, 'reprogramada');
  assert.equal(r.original.reprogramadaA, r.nueva.id);
  assert.equal(r.nueva.reprogramadaDe, o.id);
  assert.equal(r.nueva.estado, 'programada');
  const d = await S.cargar();
  assert.equal(d.appointments.filter((a) => a.estado === 'realizada').length, 0);
  // la original ya no ocupa horario
  await S.crearCita({ patientId: p.id, fecha: '2026-11-03', inicio: '10:00', duracion: 45 });
  await assert.rejects(() => S.cambiarEstadoCita(o.id, 'realizada'), ValidationError);
  assert.ok(r.original.historial.length >= 2, 'conserva trazabilidad');
});

test('Cobro por sesión: pago parcial calcula el saldo pendiente y distingue cobrado de proyectado', async () => {
  const { S } = nuevo();
  const p = await paciente(S, { tarifa: 20 });
  const a = (await S.crearCita({ patientId: p.id, fecha: '2026-10-26', inicio: '09:00', duracion: 45 })).cita;
  const b = (await S.crearCita({ patientId: p.id, fecha: '2026-10-27', inicio: '09:00', duracion: 45 })).cita;
  await S.crearCita({ patientId: p.id, fecha: '2026-11-03', inicio: '09:00', duracion: 45 }); // futura
  await S.cambiarEstadoCita(a.id, 'realizada');
  await S.cambiarEstadoCita(b.id, 'realizada');
  let d = await S.cargar();
  let l = libroPaciente(p.id, d, d.settings);
  assert.equal(l.porMoneda.USD.cargos, 40);
  assert.equal(l.porMoneda.USD.pendiente, 40);
  assert.equal(totalPorMoneda(d.payments, '2026-01-01', '2026-12-31').USD, undefined, 'sin pagos no hay ingreso');
  await S.registrarPago({ patientId: p.id, fecha: '2026-10-27', importe: 15, metodo: 'Efectivo', obligacion: { tipo: 'cita', id: a.id } });
  d = await S.cargar();
  l = libroPaciente(p.id, d, d.settings);
  assert.equal(l.porMoneda.USD.pagado, 15);
  assert.equal(l.porMoneda.USD.pendiente, 25);
  assert.equal(l.obligaciones.find((o) => o.id === a.id).estado, 'parcial');
  assert.equal(l.obligaciones.find((o) => o.id === b.id).estado, 'pendiente');
  // abono general se aplica al más antiguo
  await S.registrarPago({ patientId: p.id, fecha: '2026-10-27', importe: 30, metodo: 'Transferencia' });
  d = await S.cargar();
  l = libroPaciente(p.id, d, d.settings);
  assert.equal(l.porMoneda.USD.pendiente, 0);
  assert.equal(l.porMoneda.USD.aFavor ?? 0, 5);
  // ingresos: solo pagos
  assert.deepEqual(totalPorMoneda(d.payments, '2026-10-01', '2026-10-31'), { USD: 45 });
  assert.deepEqual(proyectado(d.appointments, '2026-11-01', '2026-11-30'), { USD: 20 });
  assert.deepEqual(ingresosPorPeriodo(d.payments, '2026-10-01', '2026-10-31', 'mes'), { '2026-10': { USD: 45 } });
  assert.deepEqual(ingresosPorPeriodo(d.payments, '2026-10-01', '2026-10-31', 'semana'), { [startOfWeek('2026-10-27')]: { USD: 45 } });
});

test('Pagos: no se aceptan fechas futuras ni importes inválidos; las correcciones quedan registradas', async () => {
  const { S } = nuevo();
  const p = await paciente(S);
  await assert.rejects(() => S.registrarPago({ patientId: p.id, fecha: '2026-11-30', importe: 10, metodo: 'Efectivo' }), ValidationError);
  await assert.rejects(() => S.registrarPago({ patientId: p.id, fecha: '2026-10-27', importe: 0, metodo: 'Efectivo' }), ValidationError);
  const pago = await S.registrarPago({ patientId: p.id, fecha: '2026-10-27', importe: 10, metodo: 'Efectivo' });
  await assert.rejects(() => S.corregirPago(pago.id, { fecha: '2026-10-27', importe: 12, metodo: 'Efectivo' }, ''), ValidationError);
  const nuevoPago = await S.corregirPago(pago.id, { fecha: '2026-10-27', importe: 12, metodo: 'Efectivo' }, 'Error de digitación');
  let d = await S.cargar();
  assert.equal(d.payments.length, 2, 'el original se conserva');
  const viejo = d.payments.find((x) => x.id === pago.id);
  assert.equal(viejo.anulado, true);
  assert.equal(viejo.reemplazadoPor, nuevoPago.id);
  assert.equal(totalPorMoneda(d.payments, '2026-10-01', '2026-10-31').USD, 12);
  await S.anularPago(nuevoPago.id, 'Devuelto');
  d = await S.cargar();
  assert.deepEqual(totalPorMoneda(d.payments, '2026-10-01', '2026-10-31'), {});
});

test('Monedas: los totales de monedas distintas no se mezclan', async () => {
  const { S } = nuevo();
  await S.guardarAjustes({ monedas: ['USD', 'VES'] });
  const p = await paciente(S);
  await S.registrarPago({ patientId: p.id, fecha: '2026-10-27', importe: 10, metodo: 'Efectivo', moneda: 'USD' });
  await S.registrarPago({ patientId: p.id, fecha: '2026-10-27', importe: 400, metodo: 'Pago móvil', moneda: 'VES' });
  const d = await S.cargar();
  assert.deepEqual(totalPorMoneda(d.payments, '2026-10-01', '2026-10-31'), { USD: 10, VES: 400 });
  await assert.rejects(() => S.registrarPago({ patientId: p.id, fecha: '2026-10-27', importe: 1, metodo: 'x', moneda: 'EUR' }), ValidationError);
});

test('Cobro por período y paquete con pago: obligaciones y saldo', async () => {
  const { S } = nuevo();
  const p = await paciente(S, { modalidadCobro: 'periodo' });
  const plan = await S.crearPlan({ patientId: p.id, tipo: 'mensual', importe: 100, desde: '2026-10-01', hasta: '2026-10-31' });
  await S.registrarPago({ patientId: p.id, fecha: '2026-10-27', importe: 40, metodo: 'Efectivo', obligacion: { tipo: 'plan', id: plan.id } });
  const q = await paciente(S, { nombre: 'Sol', modalidadCobro: 'paquete' });
  await S.crearPaquete({ patientId: q.id, nombre: 'P12', cantidadInicial: 12, precio: 200 }, { importe: 50, metodo: 'Efectivo' });
  const d = await S.cargar();
  assert.equal(libroPaciente(p.id, d, d.settings).porMoneda.USD.pendiente, 60);
  assert.equal(libroPaciente(q.id, d, d.settings).porMoneda.USD.pendiente, 150);
  await S.cambiarEstadoPlan(plan.id, 'anulado');
  const d2 = await S.cargar();
  assert.equal(libroPaciente(p.id, d2, d2.settings).porMoneda.USD?.pendiente ?? 0, 0);
});

test('Paquete: ajuste manual exige motivo y no deja saldos negativos; eliminar cita realizada devuelve la sesión', async () => {
  const { S } = nuevo();
  const p = await paciente(S, { modalidadCobro: 'paquete' });
  const k = await S.crearPaquete({ patientId: p.id, nombre: 'P', cantidadInicial: 2, precio: 0 });
  await assert.rejects(() => S.ajustarPaquete(k.id, -1, ''), ValidationError);
  await assert.rejects(() => S.ajustarPaquete(k.id, -5, 'x'), ValidationError);
  await S.ajustarPaquete(k.id, 1, 'Cortesía');
  const c = (await S.crearCita({ patientId: p.id, fecha: '2026-10-20', inicio: '09:00', duracion: 45 })).cita;
  await S.cambiarEstadoCita(c.id, 'realizada');
  let d = await S.cargar();
  assert.equal(saldoPaquete(d.packages[0], d.movements).disponibles, 2);
  await S.eliminarCita(c.id);
  d = await S.cargar();
  assert.equal(saldoPaquete(d.packages[0], d.movements).disponibles, 3);
});

test('Sin paquete disponible: se avisa y no se inventa un descuento', async () => {
  const { S } = nuevo();
  const p = await paciente(S, { modalidadCobro: 'paquete' });
  const c = (await S.crearCita({ patientId: p.id, fecha: '2026-10-20', inicio: '09:00', duracion: 45 })).cita;
  const r = await S.cambiarEstadoCita(c.id, 'realizada');
  assert.equal(r.aviso, 'sin_paquete');
  assert.equal((await S.cargar()).movements.length, 0);
});

test('Serie: excluir fechas, finalizar desde una cita y extender sin duplicar', async () => {
  const { S } = nuevo();
  const p = await paciente(S);
  await S.crearSerie(serieInput(p.id));
  const r = await S.excluirFechasSerie('serie-1', ['2026-11-05', '2026-11-09']);
  assert.equal(r.eliminadas, 2);
  let d = await S.cargar();
  assert.equal(d.appointments.length, 6);
  const desde = d.appointments.find((a) => a.fecha === '2026-11-19');
  const f = await S.finalizarSerieDesde(desde.id);
  assert.equal(f.eliminadas, 3);
  d = await S.cargar();
  assert.equal(d.appointments.length, 3);
  const e = await S.extenderSerie('serie-1', '2026-11-30');
  d = await S.cargar();
  assert.equal(e.creadas, 4, 'respeta excepciones y no repite existentes');
  assert.equal(new Set(d.appointments.map((a) => a.fecha)).size, d.appointments.length);
  assert.ok(!d.appointments.some((a) => a.fecha === '2026-11-05'));
});

test('WhatsApp: normaliza teléfonos, codifica el texto y no inventa datos faltantes', () => {
  assert.deepEqual(normalizarTelefono('+58 414-555.0101'), { ok: true, digits: '584145550101', e164: '+584145550101' });
  assert.equal(normalizarTelefono('00584145550101').digits, '584145550101');
  assert.equal(normalizarTelefono('0414 5550101', '58').digits, '584145550101');
  assert.equal(normalizarTelefono('4145550101', '').ok, false);
  assert.equal(normalizarTelefono('12', '58').ok, false);
  const txt = aplicarPlantilla('Hola {representante}, {nino} el {fecha} a las {hora}. ¿Ok?', { representante: 'Ana', nino: 'Luna', fecha: 'lun 2 nov' });
  assert.equal(txt, 'Hola Ana, Luna el lun 2 nov a las. ¿Ok?');
  const url = enlaceWhatsApp('584145550101', 'Hola & adiós ñ\n¿Sí?');
  assert.equal(url, 'https://wa.me/584145550101?text=' + encodeURIComponent('Hola & adiós ñ\n¿Sí?'));
});

test('Respaldo: exporta, valida, detecta alteraciones y restaura con relaciones intactas', async () => {
  const A = nuevo();
  const p = await paciente(A.S, { modalidadCobro: 'paquete' });
  await A.S.crearPaquete({ patientId: p.id, nombre: 'P8', cantidadInicial: 8, precio: 80 }, { importe: 80, metodo: 'Efectivo' });
  await A.S.crearSerie(serieInput(p.id));
  const c = (await A.S.crearCita({ patientId: p.id, fecha: '2026-10-20', inicio: '09:00', duracion: 45 })).cita;
  await A.S.cambiarEstadoCita(c.id, 'realizada');
  await A.S.definirPin('1234');
  const resp = JSON.parse(JSON.stringify(await A.S.exportarRespaldo()));
  assert.equal(resp.formato, 'agenda-terapia-lenguaje-respaldo');
  assert.equal(resp.contadores.appointments, 9);
  assert.ok(!('hash' in resp.datos.settings) && !JSON.stringify(resp).includes('"salt"'), 'no incluye el PIN');
  assert.deepEqual((await validarRespaldo(resp)).ok, true);

  // alteración -> falla integridad
  const roto = JSON.parse(JSON.stringify(resp));
  roto.datos.patients[0].nombre = 'Alterado';
  assert.equal((await validarRespaldo(roto)).ok, false);
  const sinSeccion = JSON.parse(JSON.stringify(resp));
  delete sinSeccion.datos.payments;
  assert.equal((await validarRespaldo(sinSeccion)).ok, false);
  const futura = JSON.parse(JSON.stringify(resp));
  futura.version = 99;
  assert.equal((await validarRespaldo(futura)).ok, false);
  assert.throws(() => leerArchivo('no es json'));
  assert.throws(() => leerArchivo('{"formato":"otra-cosa"}'));

  // restaurar en una instalación de prueba
  const B = nuevo();
  const sum = await B.S.resumenImportacion(resp, { modo: 'reemplazar' });
  assert.equal(sum.resumen.appointments.nuevos, 9);
  assert.equal(sum.actual.patients, 0);
  await B.S.importarRespaldo(resp, { modo: 'reemplazar' });
  const dA = await A.S.cargar();
  const dB = await B.S.cargar();
  for (const s of ['patients', 'appointments', 'series', 'payments', 'packages', 'movements']) assert.deepEqual(dB[s].sort((x, y) => x.id.localeCompare(y.id)), dA[s].sort((x, y) => x.id.localeCompare(y.id)), s);
  assert.equal(await B.S.leerSeguridad(), null, 'el PIN no se transfiere');
  assert.ok(await A.S.leerSeguridad());

  // combinar sin duplicar
  const antes = (await B.S.cargar()).appointments.length;
  const m = await B.S.importarRespaldo(resp, { modo: 'combinar', politica: 'local' });
  assert.equal(m.appointments.nuevos, 0);
  assert.equal(m.appointments.iguales, antes);
  assert.equal((await B.S.cargar()).appointments.length, antes);
  // combinar con un registro nuevo y un conflicto
  const resp2 = JSON.parse(JSON.stringify(resp));
  resp2.datos.patients[0].representante = 'Cambiado';
  resp2.datos.patients[0].updatedAt = '2999-01-01T00:00:00.000Z';
  resp2.integridad.hash = (await (await import('../js/core/crypto.js')).sha256Hex(JSON.stringify(resp2.datos)));
  const m2 = await B.S.importarRespaldo(resp2, { modo: 'combinar', politica: 'local' });
  assert.equal(m2.patients.conflictos, 1);
  assert.equal((await B.S.cargar()).patients[0].representante, 'Rep. Ficticio');
  await B.S.importarRespaldo(resp2, { modo: 'combinar', politica: 'reciente' });
  assert.equal((await B.S.cargar()).patients[0].representante, 'Cambiado');
});

test('Respaldo cifrado: se descifra solo con la contraseña correcta', async () => {
  const { S } = nuevo();
  await paciente(S);
  const resp = await S.exportarRespaldo();
  const env = await cifrarRespaldo(resp, 'clave-segura-123');
  assert.equal(env.cifrado, true);
  assert.ok(!JSON.stringify(env).includes('Luna'), 'el contenido no queda legible');
  await assert.rejects(() => abrirCifrado(env, 'otra-clave'), /incorrecta/);
  const abierto = await abrirCifrado(env, 'clave-segura-123');
  assert.equal((await validarRespaldo(abierto)).ok, true);
  const alterado = { ...env, contenido: env.contenido.slice(0, -4) + 'AAAA' };
  await assert.rejects(() => abrirCifrado(alterado, 'clave-segura-123'));
});

test('PIN: se guarda como hash con sal, valida y se puede quitar solo con el PIN correcto', async () => {
  const { S, db } = nuevo();
  await assert.rejects(() => S.definirPin('12'), ValidationError);
  await S.definirPin('2468');
  const reg = await db.get('settings', 'seguridad');
  assert.ok(reg.hash && reg.salt && !JSON.stringify(reg).includes('2468'));
  assert.equal(await S.verificarPin('2468'), true);
  assert.equal(await S.verificarPin('0000'), false);
  assert.equal(await verificarSecreto('x', await hashSecreto('x')), true);
  await assert.rejects(() => S.quitarPin('0000'), ValidationError);
  await S.quitarPin('2468');
  assert.equal(await S.leerSeguridad(), null);
});

test('CSV: escapa comillas y neutraliza fórmulas', () => {
  const csv = aCSV([{ titulo: 'a', valor: 'a' }, { titulo: 'b', valor: 'b' }], [{ a: '=1+1', b: 'dice "hola", ok' }, { a: -5, b: '@x' }]);
  assert.equal(csv, 'a,b\r\n\'=1+1,"dice ""hola"", ok"\r\n-5,\'@x\r\n');
});

test('Atomicidad: un fallo no deja datos a medias', async () => {
  const { S, db } = nuevo();
  const p = await paciente(S);
  const original = db.batch.bind(db);
  db.batch = async () => {
    throw new Error('Disco lleno');
  };
  await assert.rejects(() => S.crearCita({ patientId: p.id, fecha: '2026-11-03', inicio: '10:00', duracion: 45 }), /Disco lleno/);
  db.batch = original;
  assert.equal((await S.cargar()).appointments.length, 0);
  await S.crearCita({ patientId: p.id, fecha: '2026-11-03', inicio: '10:00', duracion: 45 });
  assert.equal((await S.cargar()).appointments.length, 1);
});

test('Fechas: aritmética estable en cambios de horario de verano', () => {
  assert.equal(addDays('2026-03-07', 1), '2026-03-08');
  assert.equal(addDays('2026-11-01', 1), '2026-11-02');
  assert.equal(startOfWeek('2026-11-01'), '2026-10-26');
  assert.equal(dayOfWeek('2026-11-02'), 1);
});
