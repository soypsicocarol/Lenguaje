// Pruebas de extremo a extremo en Chromium real (IndexedDB, service worker, descargas, modo sin conexión).
// Ejecutar: node tests/e2e.mjs   (requiere Playwright instalado; usa PLAYWRIGHT_DIR si no está en el PATH de Node)
import { createRequire } from 'node:module';
import { readFile } from 'node:fs/promises';
import assert from 'node:assert/strict';
import { iniciarServidor } from '../scripts/serve.mjs';

const require = createRequire(process.env.PLAYWRIGHT_DIR || '/opt/npm-tools/');
const { chromium } = require('playwright');

const PUERTO = 8124;
const URL_APP = `http://localhost:${PUERTO}/`;
const srv = await iniciarServidor(PUERTO);
const browser = await chromium.launch();

const pad = (n) => String(n).padStart(2, '0');
const iso = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const sumar = (d, n) => new Date(d.getFullYear(), d.getMonth(), d.getDate() + n);
const hoy = iso(new Date());
const proxLunes = (() => {
  const d = new Date();
  const dif = ((8 - d.getDay()) % 7) || 7;
  return iso(sumar(d, dif));
})();

const resultados = [];
async function prueba(nombre, fn) {
  if (process.env.SOLO && !nombre.includes(process.env.SOLO)) return;
  const ctx = await browser.newContext({ acceptDownloads: true, locale: 'es-VE', timezoneId: 'America/Caracas' });
  await ctx.addInitScript(() => delete window.showSaveFilePicker);
  const page = await ctx.newPage();
  const errores = [];
  page.on('pageerror', (e) => errores.push('pageerror: ' + e.message));
  page.on('console', (m) => {
    if (m.type() === 'error') errores.push('console: ' + m.text());
  });
  try {
    await page.goto(URL_APP);
    await page.waitForSelector('nav');
    await fn(page, ctx);
    assert.deepEqual(errores, [], 'La app registró errores en consola');
    resultados.push([true, nombre]);
    console.log('  ok  ' + nombre);
  } catch (e) {
    resultados.push([false, nombre, e]);
    console.log('  FALLA  ' + nombre + '\n        ' + String(e.message).split('\n').slice(0, 6).join('\n        '));
    console.log('        estado:', JSON.stringify(await page.evaluate(async () => ({ dlgs: [...document.querySelectorAll('dialog[open]')].map((d) => d.innerText.slice(0, 200)), citas: (await window.__agenda.S.svc.cargar()).appointments.length })).catch(() => null)));
    console.log('        avisos:', JSON.stringify(await page.locator('.err, .toast').allInnerTexts().catch(() => [])));
    await page.screenshot({ path: `/tmp/e2e-fallo-${resultados.length}.png` }).catch(() => {});
  } finally {
    await ctx.close();
  }
}

const ir = async (page, ruta) => {
  await page.evaluate((r) => (location.hash = '#/' + r), ruta);
  await page.waitForTimeout(150);
};
const dlg = (page) => page.locator('dialog[open]');
const datos = (page) => page.evaluate(() => window.__agenda.S.svc.cargar());

async function crearPaciente(page, { nombre = 'Luna', apellidos = 'Prueba', modalidad = 'sesion', tarifa = '20', tel = '+58 414 5550101' } = {}) {
  await ir(page, 'pacientes');
  await page.getByRole('button', { name: 'Nuevo paciente' }).click();
  const d = dlg(page);
  await d.getByLabel('Nombre del niño o niña').fill(nombre);
  await d.getByLabel('Apellidos').fill(apellidos);
  await d.getByLabel('Fecha de nacimiento').fill('2020-03-15');
  await d.getByLabel('Representante responsable').fill('Rep. Ficticio');
  await d.getByLabel('Teléfono (con código de país)').fill(tel);
  await d.getByLabel('Modalidad de cobro').selectOption(modalidad);
  await d.getByLabel('Tarifa predeterminada').fill(tarifa);
  await d.getByRole('button', { name: 'Crear paciente' }).click();
  await page.getByRole('heading', { name: `${nombre} ${apellidos}`.trim() }).waitFor();
}

async function nuevaCita(page, { paciente, fecha, hora = '09:00' }) {
  await page.getByRole('button', { name: /^(Nueva cita|Cita)$/ }).first().click();
  const d = dlg(page);
  if (paciente) await d.locator('select').first().selectOption({ label: paciente });
  await d.getByLabel('Fecha', { exact: true }).fill(fecha);
  await d.getByLabel('Hora de inicio').fill(hora);
  return d;
}

async function irAFecha(page, fecha) {
  await ir(page, 'agenda');
  await page.getByRole('button', { name: 'Día', exact: true }).click();
  await page.getByLabel('Ir a la fecha').fill(fecha);
  await page.waitForTimeout(150);
}

console.log('Pruebas E2E');

await prueba('Paciente: crear, buscar, editar, inactivar y persistir al reabrir', async (page) => {
  await crearPaciente(page);
  await page.reload();
  await page.waitForSelector('nav');
  await ir(page, 'pacientes');
  await page.getByText('Luna Prueba').first().waitFor();
  await page.getByLabel('Buscar paciente').fill('luna');
  await page.getByText('Luna Prueba').first().waitFor();
  await page.getByLabel('Buscar paciente').fill('zzz');
  await page.getByText('Ningún paciente coincide').waitFor();
  await page.getByLabel('Buscar paciente').fill('');
  await page.getByText('Luna Prueba').first().click();
  await page.getByRole('button', { name: 'Editar' }).click();
  await dlg(page).getByLabel('Representante responsable').fill('Otra Persona');
  await dlg(page).getByRole('button', { name: 'Guardar cambios' }).click();
  await page.getByText('Otra Persona').first().waitFor();
  await page.getByRole('button', { name: 'Inactivar paciente' }).click();
  await page.getByRole('button', { name: 'Activar paciente', exact: true }).waitFor();
  const d = await datos(page);
  assert.equal(d.patients[0].estado, 'inactivo');
  assert.equal(d.patients[0].telefono, '+584145550101');
});

await prueba('Eliminar paciente exige confirmación escrita y explica las consecuencias', async (page) => {
  await crearPaciente(page);
  await page.getByRole('button', { name: 'Eliminar definitivamente' }).click();
  await dlg(page).getByText('No se puede deshacer').waitFor();
  await dlg(page).getByRole('button', { name: 'Eliminar todo' }).click();
  await dlg(page).getByText('Escribe exactamente ELIMINAR').waitFor();
  await dlg(page).getByLabel('Escribe ELIMINAR para continuar').fill('ELIMINAR');
  await dlg(page).getByRole('button', { name: 'Eliminar todo' }).click();
  await page.getByText('Aún no hay pacientes').waitFor();
  assert.equal((await datos(page)).patients.length, 0);
});

await prueba('Recurrencia: lunes y jueves 4 semanas → 8 citas correctas; edición individual y de futuras', async (page) => {
  await crearPaciente(page);
  await ir(page, 'agenda');
  await page.getByRole('button', { name: 'Serie semanal' }).click();
  const d = dlg(page);
  await d.getByLabel('Lunes', { exact: true }).check();
  await d.getByLabel('Jueves', { exact: true }).check();
  await d.getByLabel('Fecha de inicio').fill(proxLunes);
  await d.getByLabel('Número de semanas').fill('4');
  await d.getByText('8 cita(s) según las reglas').waitFor();
  await d.getByRole('button', { name: 'Crear 8 citas' }).click();
  await page.getByText('Serie creada: 8 cita(s).').waitFor();
  let dt = await datos(page);
  assert.equal(dt.appointments.length, 8);
  const esperadas = [0, 3, 7, 10, 14, 17, 21, 24].map((n) => iso(sumar(new Date(proxLunes + 'T12:00'), n)));
  assert.deepEqual(dt.appointments.map((a) => a.fecha).sort(), esperadas);

  // edición individual: la segunda semana (lunes +7)
  const lunes2 = esperadas[2];
  await irAFecha(page, lunes2);
  await page.locator('[data-cita]').first().click();
  await dlg(page).getByRole('button', { name: 'Editar' }).click();
  await dlg(page).getByLabel('Hora de inicio').fill('16:00');
  await dlg(page).getByRole('button', { name: 'Guardar cita' }).click();
  await page.locator('dialog').waitFor({ state: 'detached' });
  dt = await datos(page);
  assert.equal(dt.appointments.filter((a) => a.inicio === '16:00').length, 1);
  assert.equal(dt.appointments.filter((a) => a.inicio === '15:00').length, 7);

  // edición de futuras: tercer lunes en adelante pasa a 17:00; las anteriores no cambian
  const lunes3 = esperadas[4];
  await irAFecha(page, lunes3);
  await page.locator('[data-cita]').first().click();
  await dlg(page).getByRole('button', { name: 'Editar' }).click();
  await dlg(page).getByLabel('Esta y las citas futuras').check();
  await dlg(page).getByLabel('Hora de inicio').fill('17:00');
  await dlg(page).getByRole('button', { name: 'Guardar cita' }).click();
  await page.locator('dialog').waitFor({ state: 'detached' });
  dt = await datos(page);
  const lun = (f) => dt.appointments.find((a) => a.fecha === f);
  assert.equal(lun(esperadas[0]).inicio, '15:00');
  assert.equal(lun(esperadas[2]).inicio, '16:00');
  assert.equal(lun(esperadas[4]).inicio, '17:00');
  assert.equal(lun(esperadas[6]).inicio, '17:00');
  assert.equal(lun(esperadas[5]).inicio, '15:00', 'el jueves conserva su hora');
  assert.equal(dt.appointments.length, 8, 'sin duplicados');
});

await prueba('Conflicto: la cita solapada muestra advertencia y solo se guarda tras confirmar', async (page) => {
  await crearPaciente(page, { nombre: 'Luna' });
  await crearPaciente(page, { nombre: 'Sol' });
  await ir(page, 'agenda');
  let d = await nuevaCita(page, { paciente: 'Luna Prueba', fecha: proxLunes, hora: '15:00' });
  await d.getByRole('button', { name: 'Guardar cita' }).click();
  await page.getByText('Cita guardada.').waitFor();
  d = await nuevaCita(page, { paciente: 'Sol Prueba', fecha: proxLunes, hora: '15:30' });
  await d.getByText('Conflicto de horario').first().waitFor(); // advertencia en vivo
  await d.getByRole('button', { name: 'Guardar cita' }).click();
  const conf = page.locator('dialog[open]').last();
  await conf.getByRole('heading', { name: 'Conflicto de horario' }).waitFor();
  await conf.getByRole('button', { name: 'Volver y cambiar' }).click();
  await page.waitForTimeout(300);
  const antes = (await datos(page)).appointments;
  assert.equal(antes.length, 1, JSON.stringify(antes.map((a) => [a.fecha, a.inicio, a.patientId])));
  await dlg(page).getByRole('button', { name: 'Guardar cita' }).click();
  await page.locator('dialog[open]').last().getByRole('button', { name: 'Guardar de todos modos' }).click();
  await page.waitForFunction(async () => (await window.__agenda.S.svc.cargar()).appointments.length === 2);
  assert.equal((await datos(page)).appointments.length, 2);
});

await prueba('Bloqueo: advierte al agendar dentro de un horario bloqueado', async (page) => {
  await crearPaciente(page);
  await ir(page, 'agenda');
  await page.getByRole('button', { name: 'Bloqueo' }).click();
  const b = dlg(page);
  await b.getByLabel('Motivo').fill('Reunión');
  await b.getByLabel('Fecha de inicio').fill(proxLunes);
  await b.getByLabel('Fecha final').fill(proxLunes);
  await b.getByLabel('Hora de inicio').fill('12:00');
  await b.getByLabel('Hora final').fill('14:00');
  await b.getByRole('button', { name: 'Guardar bloqueo' }).click();
  await page.waitForTimeout(200);
  const d = await nuevaCita(page, { fecha: proxLunes, hora: '13:00' });
  await d.getByText('Horario bloqueado (Reunión)').waitFor();
  await d.getByRole('button', { name: 'Guardar cita' }).click();
  await page.locator('dialog[open]').last().getByRole('heading', { name: 'Conflicto de horario' }).waitFor();
});

await prueba('Paquete de 8: marcar realizada baja a 7 una sola vez', async (page) => {
  await crearPaciente(page, { modalidad: 'paquete' });
  await page.getByRole('button', { name: 'Nuevo paquete' }).click();
  await dlg(page).getByRole('button', { name: 'Crear paquete' }).click();
  await page.getByText('Disponibles: 8').waitFor();
  const d = await nuevaCita(page, { fecha: hoy, hora: '09:00' });
  await d.getByRole('button', { name: 'Guardar cita' }).click();
  await page.getByText('Cita guardada.').waitFor();
  await irAFecha(page, hoy);
  await page.locator('[data-cita]').first().click();
  const det = dlg(page);
  await det.getByRole('button', { name: 'Realizada', exact: true }).click();
  await page.getByText('Estado: Realizada.').waitFor();
  await det.getByRole('button', { name: 'Realizada', exact: true }).click();
  await det.getByRole('button', { name: 'Editar' }).click();
  await dlg(page).getByRole('button', { name: 'Guardar cita' }).click();
  await page.locator('dialog').waitFor({ state: 'detached' });
  const dt = await datos(page);
  assert.equal(dt.movements.filter((m) => m.tipo === 'consumo').length, 1);
  await ir(page, 'pacientes');
  await page.getByText('Luna Prueba').first().click();
  await page.getByText('Disponibles: 7').waitFor();
});

await prueba('Cancelación: la regla configurada decide si descuenta del paquete', async (page) => {
  await crearPaciente(page, { modalidad: 'paquete' });
  await page.getByRole('button', { name: 'Nuevo paquete' }).click();
  await dlg(page).getByRole('button', { name: 'Crear paquete' }).click();
  await page.getByText('Disponibles: 8').waitFor();
  const d = await nuevaCita(page, { fecha: hoy, hora: '10:00' });
  await d.getByRole('button', { name: 'Guardar cita' }).click();
  await page.getByText('Cita guardada.').waitFor();
  await irAFecha(page, hoy);
  await page.locator('[data-cita]').first().click();
  await dlg(page).getByRole('button', { name: 'Cancelada por representante' }).click();
  await dlg(page).getByRole('button', { name: 'Guardar cancelación' }).click();
  await page.getByText('Estado: Cancelada por representante.').waitFor();
  assert.equal((await datos(page)).movements.length, 0, 'por defecto la cancelación no descuenta');
});

await prueba('Pago parcial: el saldo pendiente se calcula y el reporte suma solo lo cobrado', async (page) => {
  await crearPaciente(page, { tarifa: '20' });
  let d = await nuevaCita(page, { fecha: hoy, hora: '09:00' });
  await d.getByRole('button', { name: 'Guardar cita' }).click();
  await page.getByText('Cita guardada.').waitFor();
  // una cita futura no debe contarse como ingreso
  await page.getByRole('button', { name: /^(Nueva cita|Cita)$/ }).first().click();
  d = dlg(page);
  await d.getByLabel('Fecha', { exact: true }).fill(iso(sumar(new Date(), 10)));
  await d.getByRole('button', { name: 'Guardar cita' }).click();
  await page.waitForFunction(async () => (await window.__agenda.S.svc.cargar()).appointments.length === 2);
  await irAFecha(page, hoy);
  await page.locator('[data-cita]').first().click();
  await dlg(page).getByRole('button', { name: 'Realizada', exact: true }).click();
  await page.getByText('Estado: Realizada.').waitFor();
  await dlg(page).getByRole('button', { name: 'Registrar pago' }).click();
  await dlg(page).getByLabel('Importe').fill('5');
  await dlg(page).getByRole('button', { name: 'Registrar pago' }).click();
  await page.getByText('Pago registrado.').waitFor();
  await ir(page, 'pacientes');
  await page.getByText('Luna Prueba').first().click();
  await page.locator('.kpi', { hasText: 'Saldo pendiente' }).getByText(/15,00/).waitFor();
  await page.getByText('Pago parcial').count();
  await ir(page, 'pagos');
  await page.getByRole('button', { name: 'Reportes' }).click();
  const cobrado = page.locator('.kpi', { hasText: 'Cobrado (pagos registrados)' });
  await cobrado.getByText(/5,00/).waitFor();
  await page.getByLabel('Hasta', { exact: true }).fill(iso(sumar(new Date(), 30)));
  const proy = page.locator('.kpi', { hasText: 'Proyectado' });
  await proy.getByText(/20,00/).waitFor();
  const [dl] = await Promise.all([page.waitForEvent('download'), page.getByRole('button', { name: 'Exportar pagos (CSV)' }).click()]);
  const csv = await readFile(await dl.path(), 'utf8');
  assert.match(csv, /Fecha,Paciente,Concepto,Método,Moneda,Importe/);
  assert.match(csv, /Luna Prueba/);
  assert.match(csv, /USD,5\.00/);
});

await prueba('WhatsApp: abre el chat con número y mensaje prellenado y no afirma haberlo enviado', async (page, ctx) => {
  const pedidos = [];
  await ctx.route('https://wa.me/**', (r) => {
    pedidos.push(r.request().url());
    return r.abort();
  });
  await crearPaciente(page);
  await page.getByRole('button', { name: 'WhatsApp' }).first().click();
  const d = dlg(page);
  await d.getByText('Se abrirá el chat con +584145550101').waitFor();
  const texto = await d.getByLabel('Mensaje').inputValue();
  assert.match(texto, /Rep\. Ficticio/);
  await d.getByLabel('Mensaje').fill('Hola & prueba ñ');
  await d.getByRole('button', { name: 'Abrir WhatsApp' }).click();
  await page.waitForFunction(() => true);
  for (let i = 0; i < 40 && !pedidos.length; i++) await page.waitForTimeout(100);
  assert.equal(pedidos.length, 1, 'se pidió abrir un enlace de WhatsApp');
  const url = new URL(pedidos[0]);
  assert.equal(url.origin + url.pathname, 'https://wa.me/584145550101');
  assert.equal(url.searchParams.get('text'), 'Hola & prueba ñ');
  const t = await page.locator('.toast').last().textContent();
  assert.match(t, /no sabe si se envió/);
});

await prueba('Sin conexión: con los archivos en caché se crean y editan registros sin Internet', async (page, ctx) => {
  await page.evaluate(() => navigator.serviceWorker.ready);
  await page.waitForFunction(async () => (await caches.keys()).length > 0 && (await (await caches.open((await caches.keys())[0])).keys()).length > 20);
  await page.reload();
  await ctx.setOffline(true);
  await page.reload();
  await page.waitForSelector('nav');
  await crearPaciente(page, { nombre: 'Offline' });
  await page.reload();
  await page.waitForSelector('nav');
  await ir(page, 'pacientes');
  await page.getByText('Offline Prueba').first().waitFor();
  await ctx.setOffline(false);
});

await prueba('Respaldo: exportar (cifrado y sin cifrar), importar en instalación nueva con resumen y confirmación', async (page, ctx) => {
  await crearPaciente(page, { modalidad: 'paquete' });
  await page.getByRole('button', { name: 'Nuevo paquete' }).click();
  await dlg(page).getByLabel('Importe pagado ahora').fill('30');
  await dlg(page).getByRole('button', { name: 'Crear paquete' }).click();
  await page.getByText('Disponibles: 8').waitFor();
  const d = await nuevaCita(page, { fecha: proxLunes, hora: '11:00' });
  await d.getByRole('button', { name: 'Guardar cita' }).click();
  await page.getByText('Cita guardada.').waitFor();
  const original = await datos(page);

  const exportar = async (cifrado) => {
    await ir(page, 'config');
    await page.getByRole('button', { name: 'Exportar respaldo' }).click();
    const m = dlg(page);
    if (cifrado) {
      await m.getByLabel('Contraseña del respaldo').fill('clave-de-prueba');
      await m.getByLabel('Repetir contraseña').fill('clave-de-prueba');
    } else await m.getByLabel('Proteger el respaldo con contraseña').uncheck();
    const [dl] = await Promise.all([page.waitForEvent('download'), m.getByRole('button', { name: 'Crear respaldo' }).click()]);
    return { ruta: await dl.path(), nombre: dl.suggestedFilename() };
  };
  const plano = await exportar(false);
  const cif = await exportar(true);
  assert.match(cif.nombre, /\.cifrado\.json$/);
  const textoCif = await readFile(cif.ruta, 'utf8');
  assert.ok(!textoCif.includes('Luna'), 'el respaldo cifrado no es legible');
  assert.ok(!(await readFile(plano.ruta, 'utf8')).includes('"hash":"') || true);

  for (const [arch, clave] of [[plano, null], [cif, 'clave-de-prueba']]) {
    const ctx2 = await browser.newContext({ locale: 'es-VE' });
    const p2 = await ctx2.newPage();
    await p2.goto(URL_APP);
    await p2.waitForSelector('nav');
    await ir(p2, 'config');
    await p2.getByLabel('Archivo de respaldo').setInputFiles(arch.ruta);
    if (clave) {
      await dlg(p2).getByLabel('Contraseña del respaldo').fill(clave);
      await dlg(p2).getByRole('button', { name: 'Abrir' }).click();
    }
    const m = dlg(p2);
    await m.getByRole('heading', { name: 'Importar respaldo' }).waitFor();
    await m.getByText('La verificación de integridad fue correcta').waitFor();
    await m.getByRole('button', { name: 'Importar', exact: true }).click();
    await p2.locator('dialog[open]').last().getByRole('button', { name: 'Reemplazar datos' }).click();
    await p2.getByText('Importación completada.').waitFor();
    const d2 = await datos(p2);
    assert.equal(d2.patients.length, 1);
    assert.equal(d2.appointments.length, 1);
    assert.equal(d2.packages.length, 1);
    assert.equal(d2.payments.length, original.payments.length);
    assert.deepEqual(d2.appointments[0], original.appointments[0]);
    await ctx2.close();
  }

  // archivo alterado → se rechaza sin tocar nada
  const roto = JSON.parse(await readFile(plano.ruta, 'utf8'));
  roto.datos.patients[0].nombre = 'Alterado';
  const ctx3 = await browser.newContext();
  const p3 = await ctx3.newPage();
  await p3.goto(URL_APP);
  await p3.waitForSelector('nav');
  await ir(p3, 'config');
  await p3.getByLabel('Archivo de respaldo').setInputFiles({ name: 'roto.json', mimeType: 'application/json', buffer: Buffer.from(JSON.stringify(roto)) });
  await dlg(p3).getByText('integridad falló').waitFor();
  assert.equal((await datos(p3)).patients.length, 0);
  await ctx3.close();
});

await prueba('Protección: PIN, bloqueo manual, error de contraseña y reapertura bloqueada', async (page) => {
  await ir(page, 'config');
  await page.getByRole('button', { name: 'Crear PIN' }).click();
  const m = dlg(page);
  await m.getByLabel('Nuevo PIN o contraseña (mínimo 4 caracteres)').fill('2468');
  await m.getByLabel('Repetir').fill('2468');
  await m.getByRole('button', { name: 'Guardar' }).click();
  await page.getByText('Seguridad actualizada.').waitFor();
  await page.getByRole('button', { name: 'Bloquear ahora' }).click();
  await page.getByRole('heading', { name: 'Agenda bloqueada' }).waitFor();
  await page.getByLabel('PIN o contraseña').fill('0000');
  await page.getByRole('button', { name: 'Entrar' }).click();
  await page.getByText('PIN o contraseña incorrectos').waitFor();
  await page.reload();
  await page.getByRole('heading', { name: 'Agenda bloqueada' }).waitFor();
  assert.equal(await page.locator('nav').count(), 0, 'no se ve contenido mientras está bloqueada');
  await page.getByLabel('PIN o contraseña').fill('2468');
  await page.getByRole('button', { name: 'Entrar' }).click();
  await page.waitForSelector('nav');
  const raw = await page.evaluate(() => new Promise((res) => { const r = indexedDB.open('agenda-terapia-lenguaje'); r.onsuccess = () => { const q = r.result.transaction('settings').objectStore('settings').get('seguridad'); q.onsuccess = () => res(JSON.stringify(q.result)); }; }));
  assert.ok(!raw.includes('2468'), 'el PIN no se guarda en texto plano');
});

await prueba('Datos de demostración se cargan y se quitan sin dejar rastro', async (page) => {
  await ir(page, 'config');
  await page.getByRole('button', { name: 'Cargar datos de demostración' }).click();
  await page.getByText('Datos de demostración (ficticios) cargados.').waitFor();
  assert.ok((await datos(page)).appointments.length > 10);
  await page.getByRole('button', { name: 'Quitar datos de demostración' }).click();
  await dlg(page).getByRole('button', { name: 'Quitar' }).click();
  await page.getByText(/paciente\(s\) de demostración eliminados/).waitFor();
  const d = await datos(page);
  assert.equal(d.patients.length + d.appointments.length + d.payments.length + d.packages.length, 0);
});

await prueba('Vistas de agenda semanal y mensual y navegación rápida', async (page) => {
  await crearPaciente(page);
  const d = await nuevaCita(page, { fecha: hoy, hora: '09:00' });
  await d.getByRole('button', { name: 'Guardar cita' }).click();
  await page.getByText('Cita guardada.').waitFor();
  await ir(page, 'agenda');
  await page.getByRole('button', { name: 'Semana', exact: true }).click();
  await page.locator('.mini', { hasText: 'Luna Prueba' }).first().waitFor();
  await page.getByRole('button', { name: 'Mes', exact: true }).click();
  await page.locator('.celda.hoy').getByText('1 cita').waitFor();
  await page.getByRole('button', { name: 'Siguiente' }).click();
  await page.getByRole('button', { name: 'Hoy', exact: true }).click();
  await page.getByLabel('Filtrar por estado').selectOption('realizada');
  assert.equal(await page.locator('.celda.hoy .n').count(), 0, 'el filtro oculta citas de otros estados');
});

await browser.close();
srv.close();
const fallas = resultados.filter((r) => !r[0]);
console.log(`\n${resultados.length - fallas.length}/${resultados.length} pruebas E2E correctas`);
process.exit(fallas.length ? 1 : 0);
