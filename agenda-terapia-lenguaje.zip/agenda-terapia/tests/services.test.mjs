// Pruebas de integración con IndexedDB (en memoria): cubren los criterios de aceptación del brief.
import { test, describe, beforeEach } from 'node:test';
import assert from 'node:assert/strict';
import { IDBFactory, IDBKeyRange } from 'fake-indexeddb';
import { freshDB, mkPatient, LUN } from './helpers.mjs';
import { initStore, closeStore, getDB, loadAll, loadSettings, saveSettings } from '../js/core/store.js';
import { ConflictError, ValidationError, OverpayError, BackupError } from '../js/core/errors.js';
import {
  createAppointment, updateAppointment, setAppointmentStatus, rescheduleAppointment, deleteAppointment, createSeries,
  previewSeries, editSeriesFrom, editSeriesAll, endSeries, addSeriesPause, removeSeriesPause, extendOpenSeries, saveBlock,
} from '../js/domain/agenda.js';
import { savePatient, setPatientActive, patientUsage, deletePatientPermanently, findDuplicate } from '../js/domain/patients.js';
import { savePayment, voidPayment, correctPayment, reassignPayment, createPackage, adjustPackage, saveObligation, voidObligation } from '../js/domain/billing.js';
import { packageSummary } from '../js/domain/packages.js';
import { obligationSummary, incomeReport, balancesByCurrency } from '../js/domain/finance.js';
import { buildDashboard, buildReport } from '../js/domain/reports.js';
import {
  buildBackup, encryptBackup, parseBackupFile, planImport, restoreReplace, restoreMerge, revertLastRestore, checkIntegrity, BACKUP_FORMAT,
} from '../js/domain/backup.js';
import { setSecret, verifySecret, hasSecret, removeSecret } from '../js/domain/auth.js';
import { loadDemoData, deleteDemoData } from '../js/domain/demo.js';

const DIAS_LJ = [{ dow: 1, inicio: '15:00', duracion: 45 }, { dow: 4, inicio: '15:00', duracion: 45 }];
const citasDe = async (pid) => (await getDB().byIndex('appointments', 'patientId', pid)).sort((a, b) => (a.fecha + a.inicio < b.fecha + b.inicio ? -1 : 1));

beforeEach(freshDB);

describe('Paciente', () => {
  test('crear, editar, buscar, inactivar y conservar tras reabrir la base', async () => {
    const idb = new IDBFactory();
    closeStore();
    await initStore('persist-test', { indexedDB: idb, IDBKeyRange });
    const p = await mkPatient({ nombre: 'Luna', apellidos: 'Ficticia' });
    await savePatient({ ...p, representante: 'Otra Persona' });
    await setPatientActive(p.id, false);
    closeStore();
    await initStore('persist-test', { indexedDB: idb, IDBKeyRange }); // "reabrir la aplicación"
    const all = await getDB().all('patients');
    assert.equal(all.length, 1);
    assert.equal(all[0].representante, 'Otra Persona');
    assert.equal(all[0].estado, 'inactivo');
    assert.equal(all[0].id, p.id, 'el identificador es estable');
    assert.ok(!('edad' in all[0]), 'la edad nunca se guarda');
  });
  test('validaciones', async () => {
    await assert.rejects(() => mkPatient({ nombre: '' }), ValidationError);
    await assert.rejects(() => mkPatient({ fechaNacimiento: '2031-01-01' }), ValidationError);
    await assert.rejects(() => mkPatient({ telefono: '12' }), ValidationError);
    await assert.rejects(() => mkPatient({ modalidadCobro: 'otra' }), ValidationError);
  });
  test('detecta posibles duplicados', async () => {
    const p = await mkPatient();
    assert.equal((await findDuplicate({ nombre: 'niño', apellidos: 'PRUEBA', fechaNacimiento: p.fechaNacimiento }))?.id, p.id);
  });
  test('un paciente con historial se inactiva; la eliminación definitiva borra todo', async () => {
    const p = await mkPatient();
    const a = await createAppointment({ patientId: p.id, fecha: LUN, inicio: '15:00', duracion: 45 });
    await setPatientActive(p.id, false);
    assert.equal((await patientUsage(p.id)).citas, 1);
    await assert.rejects(() => createAppointment({ patientId: p.id, fecha: LUN, inicio: '10:00', duracion: 45 }), ValidationError, 'no se agendan citas a inactivos');
    const c = await deletePatientPermanently(p.id);
    assert.equal(c.citas, 1);
    assert.equal(await getDB().get('appointments', a.id), undefined);
  });
  test('inactivar puede quitar las citas futuras abiertas', async () => {
    const p = await mkPatient();
    await createSeries({ patientId: p.id, fechaInicio: '2099-01-04', dias: [DIAS_LJ[0]], repeticiones: 3 });
    const r = await setPatientActive(p.id, false, { quitarCitasFuturas: true });
    assert.equal(r.eliminadas, 3);
    assert.equal((await citasDe(p.id)).length, 0);
  });
});

describe('Recurrencia', () => {
  test('lunes y jueves durante cuatro semanas: fechas correctas y sin duplicados', async () => {
    const p = await mkPatient();
    const r = await createSeries({ patientId: p.id, fechaInicio: LUN, dias: DIAS_LJ, repeticiones: 4 });
    assert.equal(r.creadas, 8);
    const fechas = (await citasDe(p.id)).map((c) => c.fecha);
    assert.deepEqual(fechas, ['2026-11-02', '2026-11-05', '2026-11-09', '2026-11-12', '2026-11-16', '2026-11-19', '2026-11-23', '2026-11-26']);
    // volver a guardar la misma serie no duplica
    await assert.rejects(() => createSeries({ patientId: p.id, fechaInicio: LUN, dias: DIAS_LJ, repeticiones: 4 }), ValidationError);
    assert.equal((await citasDe(p.id)).length, 8);
    // reconstruir/ampliar tampoco duplica
    assert.equal((await removeSeriesPause(r.series.id, 'inexistente')).restauradas, 0);
    assert.equal(await extendOpenSeries('2026-11-01'), 0);
    assert.equal((await citasDe(p.id)).length, 8);
  });
  test('la vista previa marca conflictos y la serie respeta las exclusiones', async () => {
    const p = await mkPatient();
    const q = await mkPatient({ nombre: 'Otro' });
    await createAppointment({ patientId: q.id, fecha: '2026-11-09', inicio: '15:15', duracion: 45 });
    const prev = await previewSeries({ patientId: p.id, fechaInicio: LUN, dias: DIAS_LJ, repeticiones: 2 });
    assert.equal(prev.rows.length, 4);
    assert.equal(prev.rows.filter((r) => r.solapa).length, 1);
    assert.equal(prev.rows.find((r) => r.solapa).fecha, '2026-11-09');
    const r = await createSeries({ patientId: p.id, fechaInicio: LUN, dias: DIAS_LJ, repeticiones: 2 }, { excludeDates: ['2026-11-09'] });
    assert.equal(r.creadas, 3);
  });
  test('editar una cita individual no cambia las demás', async () => {
    const p = await mkPatient();
    const r = await createSeries({ patientId: p.id, fechaInicio: LUN, dias: DIAS_LJ, repeticiones: 4 });
    const antes = await citasDe(p.id);
    const objetivo = antes.find((c) => c.fecha === '2026-11-09');
    await updateAppointment(objetivo.id, { inicio: '16:00' });
    const despues = await citasDe(p.id);
    assert.equal(despues.find((c) => c.id === objetivo.id).inicio, '16:00');
    assert.ok(despues.find((c) => c.id === objetivo.id).editadaIndividual);
    for (const c of despues.filter((x) => x.id !== objetivo.id)) assert.equal(c.inicio, '15:00');
    assert.equal(despues.length, 8);
    assert.equal(despues.find((c) => c.id === objetivo.id).seriesId, r.series.id);
  });
  test('editar esta y las futuras no modifica las pasadas', async () => {
    const p = await mkPatient();
    const r = await createSeries({ patientId: p.id, fechaInicio: LUN, dias: DIAS_LJ, repeticiones: 4 });
    const pas = (await citasDe(p.id)).find((c) => c.fecha === '2026-11-02');
    await updateAppointment(pas.id, { inicio: '16:00' }); // edición individual previa, antes del corte
    const res = await editSeriesFrom(r.series.id, '2026-11-16', { dias: DIAS_LJ.map((d) => ({ ...d, inicio: '17:00' })) });
    assert.equal(res.creadas, 4);
    const todas = await citasDe(p.id);
    assert.equal(todas.length, 8, 'mismo número de citas');
    for (const c of todas.filter((x) => x.fecha < '2026-11-16')) assert.equal(c.inicio, c.id === pas.id ? '16:00' : '15:00');
    for (const c of todas.filter((x) => x.fecha >= '2026-11-16')) assert.equal(c.inicio, '17:00');
    const viejas = await getDB().get('series', r.series.id);
    assert.equal(viejas.fechaFin, '2026-11-15');
    assert.notEqual(res.series.id, r.series.id);
  });
  test('"esta y las futuras" conserva las citas futuras que ya tienen resultado', async () => {
    const p = await mkPatient();
    const r = await createSeries({ patientId: p.id, fechaInicio: '2026-01-05', dias: [DIAS_LJ[0]], repeticiones: 6 });
    const citas = await citasDe(p.id);
    await setAppointmentStatus(citas[3].id, 'realizada'); // 2 feb
    await editSeriesFrom(r.series.id, '2026-01-26', { dias: [{ dow: 2, inicio: '10:00', duracion: 30 }] });
    const todas = await citasDe(p.id);
    assert.ok(todas.some((c) => c.id === citas[3].id && c.estado === 'realizada'));
    assert.ok(todas.filter((c) => c.fecha >= '2026-01-26' && c.estado !== 'realizada').every((c) => c.inicio === '10:00'));
  });
  test('editar TODA la serie solo si es seguro', async () => {
    const p = await mkPatient();
    const r = await createSeries({ patientId: p.id, fechaInicio: '2026-01-05', dias: [DIAS_LJ[0]], repeticiones: 4 });
    const ok = await editSeriesAll(r.series.id, { dias: [{ dow: 1, inicio: '09:00', duracion: 45 }] });
    assert.equal(ok.creadas, 4);
    assert.ok((await citasDe(p.id)).every((c) => c.inicio === '09:00'));
    const una = (await citasDe(p.id))[0];
    await setAppointmentStatus(una.id, 'realizada');
    await assert.rejects(() => editSeriesAll(r.series.id, { dias: [{ dow: 1, inicio: '08:00', duracion: 45 }] }), /No es seguro/);
  });
  test('pausas por vacaciones y regreso', async () => {
    const p = await mkPatient();
    const r = await createSeries({ patientId: p.id, fechaInicio: LUN, dias: DIAS_LJ, repeticiones: 4 });
    const pa = await addSeriesPause(r.series.id, { desde: '2026-11-09', hasta: '2026-11-15', motivo: 'Vacaciones' });
    assert.equal(pa.eliminadas, 2);
    assert.equal((await citasDe(p.id)).length, 6);
    const back = await removeSeriesPause(r.series.id, pa.pausa.id);
    assert.equal(back.restauradas, 2);
    assert.equal((await citasDe(p.id)).length, 8);
  });
  test('eliminar una cita de la serie la excluye y no reaparece; terminar la serie', async () => {
    const p = await mkPatient();
    const r = await createSeries({ patientId: p.id, fechaInicio: LUN, dias: [DIAS_LJ[0]], repeticiones: 4 });
    const c = (await citasDe(p.id))[1];
    await deleteAppointment(c.id);
    await removeSeriesPause(r.series.id, 'x'); // fuerza re-materializar
    assert.equal((await citasDe(p.id)).length, 3);
    const e = await endSeries(r.series.id, '2026-11-16');
    assert.equal(e.eliminadas, 2);
    assert.equal((await citasDe(p.id)).length, 1);
  });
  test('serie abierta: se amplía hasta el horizonte sin duplicar', async () => {
    const p = await mkPatient();
    const r = await createSeries({ patientId: p.id, fechaInicio: LUN, dias: [DIAS_LJ[0]] });
    assert.ok(r.creadas >= 1);
    const antes = (await citasDe(p.id)).length;
    const n = await extendOpenSeries('2027-06-01');
    assert.ok(n > 0);
    const despues = (await citasDe(p.id)).length;
    assert.equal(despues, antes + n);
    assert.equal(await extendOpenSeries('2027-06-01'), 0);
  });
  test('citas variables: cambiar una no altera otras', async () => {
    const p = await mkPatient();
    const a = await createAppointment({ patientId: p.id, fecha: '2026-11-02', inicio: '10:00', duracion: 45 });
    const b = await createAppointment({ patientId: p.id, fecha: '2026-11-09', inicio: '10:00', duracion: 45 });
    await updateAppointment(a.id, { fecha: '2026-11-03', inicio: '11:00' });
    assert.equal((await getDB().get('appointments', b.id)).inicio, '10:00');
    assert.equal((await getDB().get('appointments', b.id)).fecha, '2026-11-09');
  });
});

describe('Conflictos y bloqueos', () => {
  test('citas solapadas muestran advertencia y solo se guardan con confirmación explícita', async () => {
    const p = await mkPatient();
    const q = await mkPatient({ nombre: 'Otro' });
    await createAppointment({ patientId: p.id, fecha: LUN, inicio: '15:00', duracion: 45 });
    await assert.rejects(() => createAppointment({ patientId: q.id, fecha: LUN, inicio: '15:30', duracion: 45 }), (e) => e instanceof ConflictError && e.conflicts.citas.length === 1);
    assert.equal((await getDB().all('appointments')).length, 1, 'no se guardó nada');
    await createAppointment({ patientId: q.id, fecha: LUN, inicio: '15:30', duracion: 45 }, { allowConflict: true });
    assert.equal((await getDB().all('appointments')).length, 2);
  });
  test('bloqueos: advierten, se pueden editar y eliminar', async () => {
    const p = await mkPatient();
    const b = await saveBlock({ fechaInicio: LUN, fechaFin: LUN, horaInicio: '12:00', horaFin: '14:00', motivo: 'Almuerzo' });
    await assert.rejects(() => createAppointment({ patientId: p.id, fecha: LUN, inicio: '13:00', duracion: 30 }), (e) => e instanceof ConflictError && e.conflicts.bloqueos.length === 1);
    await saveBlock({ ...b, horaFin: '12:30' }); // editar
    await createAppointment({ patientId: p.id, fecha: LUN, inicio: '13:00', duracion: 30 });
  });
  test('cambiar una cita a un horario ocupado también advierte', async () => {
    const p = await mkPatient();
    const a = await createAppointment({ patientId: p.id, fecha: LUN, inicio: '09:00', duracion: 45 });
    await createAppointment({ patientId: p.id, fecha: LUN, inicio: '11:00', duracion: 45 });
    await assert.rejects(() => updateAppointment(a.id, { inicio: '11:30' }), ConflictError);
  });
  test('fuera del horario de atención advierte', async () => {
    const p = await mkPatient();
    await assert.rejects(() => createAppointment({ patientId: p.id, fecha: '2026-11-07', inicio: '10:00', duracion: 45 }), (e) => e instanceof ConflictError && e.conflicts.fueraDeHorario);
  });
});

describe('Asistencia, cancelación y reprogramación', () => {
  test('marcar realizada no se cuenta dos veces (cobro por sesión)', async () => {
    const p = await mkPatient({ tarifa: 25 });
    const a = await createAppointment({ patientId: p.id, fecha: '2026-10-05', inicio: '09:00', duracion: 45 });
    await setAppointmentStatus(a.id, 'realizada');
    await setAppointmentStatus(a.id, 'realizada');
    await setAppointmentStatus(a.id, 'realizada');
    const obs = await getDB().all('plans');
    assert.equal(obs.length, 1);
    assert.equal(obs[0].importe, 25);
    const hist = (await getDB().get('appointments', a.id)).historial.filter((h) => h.tipo === 'estado');
    assert.equal(hist.length, 1, 'el historial no se llena con cambios repetidos');
  });
  test('no se puede marcar realizada una cita futura', async () => {
    const p = await mkPatient();
    const a = await createAppointment({ patientId: p.id, fecha: '2099-01-05', inicio: '09:00', duracion: 45 });
    await assert.rejects(() => setAppointmentStatus(a.id, 'realizada'), ValidationError);
    await setAppointmentStatus(a.id, 'confirmada');
  });
  test('cobro por sesión: cancelación e inasistencia no cobran por defecto, y pasar a otro estado anula el cobro', async () => {
    const p = await mkPatient();
    const a = await createAppointment({ patientId: p.id, fecha: '2026-10-05', inicio: '09:00', duracion: 45 });
    await setAppointmentStatus(a.id, 'inasistencia');
    assert.equal((await getDB().all('plans')).length, 0);
    await setAppointmentStatus(a.id, 'realizada');
    assert.equal((await getDB().all('plans'))[0].estado, 'activa');
    await setAppointmentStatus(a.id, 'cancelada_representante', { motivo: 'Enfermo' });
    assert.equal((await getDB().all('plans'))[0].estado, 'anulada');
    await setAppointmentStatus(a.id, 'realizada');
    const obs = await getDB().all('plans');
    assert.equal(obs.length, 1);
    assert.equal(obs[0].estado, 'activa');
  });
  test('regla configurable: la inasistencia puede cobrarse', async () => {
    const s = await loadSettings();
    s.reglasConsumo.inasistencia.cobra = true;
    await saveSettings(s);
    const p = await mkPatient();
    const a = await createAppointment({ patientId: p.id, fecha: '2026-10-05', inicio: '09:00', duracion: 45 });
    await setAppointmentStatus(a.id, 'inasistencia');
    assert.equal((await getDB().all('plans')).length, 1);
  });
  test('reprogramar vincula ambas citas y solo la nueva puede contar', async () => {
    const p = await mkPatient();
    const a = await createAppointment({ patientId: p.id, fecha: '2026-11-09', inicio: '09:00', duracion: 45 });
    await setAppointmentStatus(a.id, 'cancelada_terapeuta', { motivo: 'Congreso' });
    assert.ok((await getDB().get('appointments', a.id)).paraReprogramar);
    const r = await rescheduleAppointment(a.id, { fecha: '2026-11-12', inicio: '09:00' });
    assert.equal(r.original.estado, 'reprogramada');
    assert.equal(r.original.reprogramadaA, r.nueva.id);
    assert.equal(r.nueva.reprogramadaDe, a.id);
    assert.equal(r.nueva.estado, 'programada');
    await assert.rejects(() => setAppointmentStatus(a.id, 'realizada'), ValidationError, 'la original ya no puede contarse');
    await assert.rejects(() => rescheduleAppointment(a.id, { fecha: '2026-11-13', inicio: '09:00' }), ValidationError);
    // al eliminar la nueva, la original vuelve a su estado previo y pendiente de reprogramar
    await deleteAppointment(r.nueva.id);
    const o = await getDB().get('appointments', a.id);
    assert.equal(o.estado, 'cancelada_terapeuta');
    assert.ok(o.paraReprogramar);
  });
  test('reprogramar una cita realizada no se permite; eliminarla tampoco', async () => {
    const p = await mkPatient();
    const a = await createAppointment({ patientId: p.id, fecha: '2026-10-05', inicio: '09:00', duracion: 45 });
    await setAppointmentStatus(a.id, 'realizada');
    await assert.rejects(() => rescheduleAppointment(a.id, { fecha: '2026-10-07', inicio: '09:00' }), ValidationError);
    await assert.rejects(() => deleteAppointment(a.id), ValidationError);
  });
  test('reprogramar una cita que había consumido paquete devuelve la sesión', async () => {
    const s = await loadSettings();
    s.reglasConsumo.inasistencia.descuenta = true;
    await saveSettings(s);
    const p = await mkPatient({ modalidadCobro: 'paquete' });
    const { pkg } = await createPackage({ patientId: p.id, nombre: 'Paq', cantidadInicial: 8, precio: 100, moneda: 'USD', fechaCompra: '2026-10-01' });
    const a = await createAppointment({ patientId: p.id, fecha: '2026-10-05', inicio: '09:00', duracion: 45 });
    await setAppointmentStatus(a.id, 'inasistencia');
    const sum = async () => packageSummary(pkg, await getDB().all('movements'), '2026-10-10').disponibles;
    assert.equal(await sum(), 7);
    await rescheduleAppointment(a.id, { fecha: '2026-10-07', inicio: '09:00' });
    assert.equal(await sum(), 8);
  });
  test('la whatsappEstado se guarda manualmente', async () => {
    const { setWhatsAppState } = await import('../js/domain/agenda.js');
    const p = await mkPatient();
    const a = await createAppointment({ patientId: p.id, fecha: LUN, inicio: '10:00', duracion: 45 });
    assert.equal((await setWhatsAppState(a.id, 'contactado')).whatsappEstado, 'contactado');
    await assert.rejects(() => setWhatsAppState(a.id, 'enviado'), ValidationError);
  });
});

describe('Paquetes', () => {
  const setup = async (n = 8) => {
    const p = await mkPatient({ modalidadCobro: 'paquete' });
    const { pkg, obligacion } = await createPackage({ patientId: p.id, nombre: `Paquete de ${n}`, cantidadInicial: n, precio: 120, moneda: 'USD', fechaCompra: '2026-10-01' });
    const disp = async () => packageSummary(pkg, await getDB().all('movements'), '2026-10-30');
    return { p, pkg, obligacion, disp };
  };
  test('paquete de 8: una sesión realizada baja a 7 una sola vez', async () => {
    const { p, disp } = await setup();
    assert.equal((await disp()).disponibles, 8);
    const a = await createAppointment({ patientId: p.id, fecha: '2026-10-05', inicio: '09:00', duracion: 45 });
    await setAppointmentStatus(a.id, 'realizada');
    assert.equal((await disp()).disponibles, 7);
    await setAppointmentStatus(a.id, 'realizada');
    await updateAppointment(a.id, { notaAdministrativa: 'editada de nuevo' });
    await setAppointmentStatus(a.id, 'realizada');
    const s = await disp();
    assert.equal(s.disponibles, 7);
    assert.equal(s.consumidas, 1);
  });
  test('cancelaciones siguen la regla configurada; volver a un estado que no descuenta devuelve la sesión', async () => {
    const { p, disp } = await setup();
    const a = await createAppointment({ patientId: p.id, fecha: '2026-10-05', inicio: '09:00', duracion: 45 });
    const b = await createAppointment({ patientId: p.id, fecha: '2026-10-06', inicio: '09:00', duracion: 45 });
    await setAppointmentStatus(a.id, 'cancelada_representante');
    await setAppointmentStatus(b.id, 'inasistencia');
    assert.equal((await disp()).disponibles, 8, 'por defecto no descuentan');
    const s = await loadSettings();
    s.reglasConsumo.cancelada_representante.descuenta = true;
    await saveSettings(s);
    await setAppointmentStatus(a.id, 'cancelada_representante');
    assert.equal((await disp()).disponibles, 7);
    await setAppointmentStatus(a.id, 'cancelada_representante');
    assert.equal((await disp()).disponibles, 7, 'no se descuenta dos veces');
    await setAppointmentStatus(a.id, 'programada');
    assert.equal((await disp()).disponibles, 8, 'se devuelve');
  });
  test('sin sesiones disponibles: avisa y no descuenta', async () => {
    const { p, disp } = await setup(1);
    const a = await createAppointment({ patientId: p.id, fecha: '2026-10-05', inicio: '09:00', duracion: 45 });
    const b = await createAppointment({ patientId: p.id, fecha: '2026-10-06', inicio: '09:00', duracion: 45 });
    await setAppointmentStatus(a.id, 'realizada');
    const r = await setAppointmentStatus(b.id, 'realizada');
    assert.equal(r.avisos.length, 1);
    const s = await disp();
    assert.equal(s.disponibles, 0);
    assert.equal(s.estado, 'agotado');
  });
  test('ajuste manual con motivo; no puede dejar el saldo negativo', async () => {
    const { pkg, disp } = await setup();
    await assert.rejects(() => adjustPackage(pkg.id, 1, ''), ValidationError);
    await assert.rejects(() => adjustPackage(pkg.id, -9, 'x'), ValidationError);
    await adjustPackage(pkg.id, -2, 'Sesiones usadas antes de la agenda');
    assert.equal((await disp()).disponibles, 6);
  });
  test('el paquete crea una obligación y el pago inicial es opcional y explícito', async () => {
    const { obligacion } = await setup();
    assert.equal(obligacion.importe, 120);
    const pagos = await getDB().all('payments');
    assert.equal(pagos.length, 0, 'crear un paquete NO registra pagos solo');
    const p2 = await mkPatient({ nombre: 'Dos', modalidadCobro: 'paquete' });
    const r = await createPackage({ patientId: p2.id, nombre: 'P', cantidadInicial: 4, precio: 60, moneda: 'USD', fechaCompra: '2026-10-01' }, { fecha: '2026-10-01', importe: 30, metodo: 'Efectivo' });
    assert.equal(r.pago.importe, 30);
    const s = obligationSummary(r.obligacion, await getDB().all('payments'));
    assert.equal(s.pendiente, 30);
    assert.equal(s.estado, 'parcial');
  });
  test('un paquete vencido no se usa', async () => {
    const p = await mkPatient({ modalidadCobro: 'paquete' });
    await createPackage({ patientId: p.id, nombre: 'Corto', cantidadInicial: 4, precio: 60, moneda: 'USD', fechaCompra: '2026-09-01', vigencia: '2026-09-30' });
    const a = await createAppointment({ patientId: p.id, fecha: '2026-10-05', inicio: '09:00', duracion: 45 });
    const r = await setAppointmentStatus(a.id, 'realizada');
    assert.equal(r.avisos.length, 1);
    assert.equal((await getDB().all('movements')).length, 0);
  });
});

describe('Pagos, saldos e ingresos', () => {
  test('pago parcial: el saldo se calcula bien y no se marca saldada', async () => {
    const p = await mkPatient({ tarifa: 20 });
    const a = await createAppointment({ patientId: p.id, fecha: '2026-10-05', inicio: '09:00', duracion: 45 });
    await setAppointmentStatus(a.id, 'realizada');
    const ob = (await getDB().all('plans'))[0];
    await savePayment({ patientId: p.id, fecha: '2026-10-06', importe: 8, moneda: 'USD', metodo: 'Efectivo', concepto: 'Abono', obligacionId: ob.id });
    let s = obligationSummary(ob, await getDB().all('payments'));
    assert.deepEqual([s.pagado, s.pendiente, s.estado], [8, 12, 'parcial']);
    await savePayment({ patientId: p.id, fecha: '2026-10-07', importe: 12, moneda: 'USD', metodo: 'Efectivo', concepto: 'Resto', obligacionId: ob.id });
    s = obligationSummary(ob, await getDB().all('payments'));
    assert.deepEqual([s.pendiente, s.estado], [0, 'saldada']);
  });
  test('pagar de más requiere confirmación y deja saldo a favor', async () => {
    const p = await mkPatient({ tarifa: 20 });
    const a = await createAppointment({ patientId: p.id, fecha: '2026-10-05', inicio: '09:00', duracion: 45 });
    await setAppointmentStatus(a.id, 'realizada');
    const ob = (await getDB().all('plans'))[0];
    const inp = { patientId: p.id, fecha: '2026-10-06', importe: 25, moneda: 'USD', metodo: 'Efectivo', concepto: 'x', obligacionId: ob.id };
    await assert.rejects(() => savePayment(inp), OverpayError);
    await savePayment(inp, { allowOverpay: true });
    const b = balancesByCurrency(await getDB().all('plans'), await getDB().all('payments'));
    assert.equal(b.USD.aFavor, 5);
    assert.equal(b.USD.pendiente, 0);
  });
  test('validaciones de pago', async () => {
    const p = await mkPatient();
    const base = { patientId: p.id, fecha: '2026-10-06', importe: 10, moneda: 'USD', metodo: 'Efectivo', concepto: 'x' };
    for (const bad of [{ importe: 0 }, { importe: -5 }, { importe: 'abc' }, { importe: 1.234 }, { fecha: '2099-01-01' }, { metodo: '' }, { concepto: '' }]) {
      await assert.rejects(() => savePayment({ ...base, ...bad }), ValidationError, JSON.stringify(bad));
    }
  });
  test('los ingresos suman solo pagos registrados, no citas ni importes sin cobrar', async () => {
    const p = await mkPatient({ tarifa: 20 });
    await createSeries({ patientId: p.id, fechaInicio: LUN, dias: DIAS_LJ, repeticiones: 4 }); // 8 citas futuras
    const a = await createAppointment({ patientId: p.id, fecha: '2026-10-05', inicio: '09:00', duracion: 45 });
    await setAppointmentStatus(a.id, 'realizada'); // 20 USD adeudados, 0 cobrados
    let data = await loadAll();
    assert.deepEqual(incomeReport(data.payments, '2026-10-01', '2026-12-31'), {}, 'sin pagos no hay ingresos');
    assert.equal(buildReport(data, { from: '2026-10-01', to: '2026-12-31' }).estimado.USD, 160, 'lo programado se muestra aparte como estimado');
    assert.equal(buildDashboard(data, '2026-10-20').saldos.USD.pendiente, 20);
    await savePayment({ patientId: p.id, fecha: '2026-10-06', importe: 20, moneda: 'USD', metodo: 'Efectivo', concepto: 'Sesión', obligacionId: `ob_ses_${a.id}` });
    data = await loadAll();
    assert.equal(incomeReport(data.payments, '2026-10-01', '2026-12-31').USD.total, 20);
    assert.equal(buildReport(data, { from: '2026-10-01', to: '2026-12-31' }).ingresos.USD.total, 20);
  });
  test('correcciones explícitas: anular, corregir y reasignar dejan historial; nada se edita en silencio', async () => {
    const p = await mkPatient();
    const pay = await savePayment({ patientId: p.id, fecha: '2026-10-06', importe: 10, moneda: 'USD', metodo: 'Efectivo', concepto: 'Abono' });
    await assert.rejects(() => voidPayment(pay.id, ''), ValidationError);
    const { anulado, nuevo } = await correctPayment(pay.id, { importe: 12 }, 'Error al digitar');
    assert.equal(anulado.estado, 'anulado');
    assert.equal(nuevo.corrigeA, pay.id);
    assert.equal(nuevo.importe, 12);
    assert.equal((await getDB().get('payments', pay.id)).importe, 10, 'el original conserva su importe');
    const inc = incomeReport(await getDB().all('payments'), '2026-10-01', '2026-10-31');
    assert.equal(inc.USD.total, 12);
    await voidPayment(nuevo.id, 'Duplicado');
    assert.deepEqual(incomeReport(await getDB().all('payments'), '2026-10-01', '2026-10-31'), {});
    await assert.rejects(() => voidPayment(nuevo.id, 'otra vez'), ValidationError);
  });
  test('pago sin obligación queda a favor y puede reasignarse con motivo', async () => {
    const p = await mkPatient();
    const ob = await saveObligation({ patientId: p.id, concepto: 'Mensualidad', importe: 100, moneda: 'USD', periodoTipo: 'mensual' });
    const pay = await savePayment({ patientId: p.id, fecha: '2026-10-06', importe: 40, moneda: 'USD', metodo: 'Efectivo', concepto: 'Adelanto' });
    let b = balancesByCurrency(await getDB().all('plans'), await getDB().all('payments'));
    assert.equal(b.USD.aFavor, 40);
    assert.equal(b.USD.pendiente, 100);
    await reassignPayment(pay.id, ob.id, 'Era de la mensualidad');
    b = balancesByCurrency(await getDB().all('plans'), await getDB().all('payments'));
    assert.equal(b.USD.aFavor, 0);
    assert.equal(b.USD.pendiente, 60);
    const r = await voidObligation(ob.id, 'Error');
    assert.equal(r.pagosQuedanAFavor, 1);
  });
  test('monedas separadas: un pago en otra moneda no se asocia', async () => {
    const p = await mkPatient();
    const ob = await saveObligation({ patientId: p.id, concepto: 'M', importe: 100, moneda: 'USD' });
    const pay = await savePayment({ patientId: p.id, fecha: '2026-10-06', importe: 500, moneda: 'VES', metodo: 'Pago móvil', concepto: 'x' });
    await assert.rejects(() => reassignPayment(pay.id, ob.id, 'x'), /monedas/);
    const b = balancesByCurrency(await getDB().all('plans'), await getDB().all('payments'));
    assert.equal(b.USD.pendiente, 100);
    assert.equal(b.VES.cobrado, 500);
  });
  test('cobro por período con abonos', async () => {
    const p = await mkPatient({ modalidadCobro: 'periodo', periodoTipo: 'mensual', tarifa: 160 });
    const ob = await saveObligation({ patientId: p.id, concepto: 'Noviembre', importe: 160, moneda: 'USD', periodoTipo: 'mensual', fechaInicio: '2026-11-01', fechaFin: '2026-11-30' });
    await savePayment({ patientId: p.id, fecha: '2026-11-02', importe: 80, moneda: 'USD', metodo: 'Efectivo', concepto: 'Abono 1', obligacionId: ob.id });
    await savePayment({ patientId: p.id, fecha: '2026-11-15', importe: 50, moneda: 'USD', metodo: 'Transferencia', concepto: 'Abono 2', obligacionId: ob.id });
    const s = obligationSummary(ob, await getDB().all('payments'));
    assert.deepEqual([s.pagado, s.pendiente, s.estado], [130, 30, 'parcial']);
    // marcar sesiones realizadas NO genera cobros extra en esta modalidad
    const a = await createAppointment({ patientId: p.id, fecha: '2026-10-05', inicio: '09:00', duracion: 45 });
    await setAppointmentStatus(a.id, 'realizada');
    assert.equal((await getDB().all('plans')).length, 1);
  });
});

describe('Respaldo y restauración', () => {
  const poblar = async () => {
    const p = await mkPatient({ tarifa: 20 });
    const q = await mkPatient({ nombre: 'Sofía', modalidadCobro: 'paquete' });
    const r = await createSeries({ patientId: p.id, fechaInicio: LUN, dias: DIAS_LJ, repeticiones: 2 });
    const a = (await citasDe(p.id))[0];
    await setAppointmentStatus(a.id, 'realizada');
    await savePayment({ patientId: p.id, fecha: '2026-10-06', importe: 20, moneda: 'USD', metodo: 'Efectivo', concepto: 'x', obligacionId: `ob_ses_${a.id}` });
    await createPackage({ patientId: q.id, nombre: 'P8', cantidadInicial: 8, precio: 100, moneda: 'USD', fechaCompra: '2026-10-01' }, { fecha: '2026-10-01', importe: 100, metodo: 'Efectivo' });
    await saveBlock({ fechaInicio: '2026-12-01', fechaFin: '2026-12-05', todoElDia: true, motivo: 'Vacaciones' });
    const s = await loadSettings();
    s.consultorio.nombre = 'Consultorio de Prueba';
    await saveSettings(s);
    return { p, q, r };
  };
  const backupToText = async (password) => {
    const b = await buildBackup();
    return password ? JSON.stringify(await encryptBackup(b, password)) : JSON.stringify(b);
  };

  test('exportar e importar en una instalación de prueba conserva datos y relaciones', async () => {
    await poblar();
    const original = await loadAll();
    const text = await backupToText();
    await freshDB(); // otra instalación
    const backup = await parseBackupFile(text);
    const plan = planImport(await loadAll(), backup);
    assert.ok(plan.actualVacia);
    assert.equal(plan.contadoresRespaldo.patients, 2);
    await restoreReplace(backup);
    const restored = await loadAll();
    for (const k of ['patients', 'appointments', 'series', 'blocks', 'payments', 'plans', 'packages', 'movements']) {
      assert.deepEqual(restored[k].sort((a, b) => (a.id < b.id ? -1 : 1)), original[k].sort((a, b) => (a.id < b.id ? -1 : 1)), k);
    }
    assert.equal(restored.settings.consultorio.nombre, 'Consultorio de Prueba');
    assert.deepEqual(checkIntegrity(restored), []);
    // los cálculos coinciden tras restaurar
    const b2 = balancesByCurrency(restored.plans, restored.payments);
    const b1 = balancesByCurrency(original.plans, original.payments);
    assert.deepEqual(b2, b1);
  });
  test('respaldo cifrado: contraseña correcta, incorrecta y archivo alterado', async () => {
    await poblar();
    const text = await backupToText('clave-segura-123');
    assert.ok(!text.includes('Prueba'), 'el contenido no es legible dentro del archivo cifrado');
    await assert.rejects(() => parseBackupFile(text), (e) => e instanceof BackupError && e.code === 'falta_password');
    await assert.rejects(() => parseBackupFile(text, 'mala-clave-999'), (e) => e instanceof BackupError && e.code === 'password');
    const ok = await parseBackupFile(text, 'clave-segura-123');
    assert.equal(ok.formato, BACKUP_FORMAT);
    const env = JSON.parse(text);
    env.datos = env.datos.slice(0, 20) + (env.datos[20] === 'A' ? 'B' : 'A') + env.datos.slice(21);
    await assert.rejects(() => parseBackupFile(JSON.stringify(env), 'clave-segura-123'), (e) => e.code === 'password');
    const b = await buildBackup();
    await assert.rejects(() => encryptBackup(b, 'corta'), BackupError);
  });
  test('validación: archivo ilegible, formato ajeno, versión nueva, checksum y relaciones', async () => {
    await poblar();
    const good = JSON.parse(await backupToText());
    await assert.rejects(() => parseBackupFile('esto no es json'), (e) => e.code === 'formato');
    await assert.rejects(() => parseBackupFile(JSON.stringify({ hola: 1 })), (e) => e.code === 'formato');
    await assert.rejects(() => parseBackupFile(JSON.stringify({ ...good, version: 99 })), (e) => e.code === 'version');
    const tampered = JSON.parse(JSON.stringify(good));
    tampered.datos.payments[0].importe = 9999;
    await assert.rejects(() => parseBackupFile(JSON.stringify(tampered)), (e) => e.code === 'checksum');
    const { sha256Hex } = await import('../js/core/bytes.js');
    const roto = JSON.parse(JSON.stringify(good));
    roto.datos.appointments[0].patientId = 'inexistente';
    roto.checksum = await sha256Hex(JSON.stringify({ datos: roto.datos, configuracion: roto.configuracion }));
    await assert.rejects(() => parseBackupFile(JSON.stringify(roto)), (e) => e.code === 'integridad');
    const sinSeccion = JSON.parse(JSON.stringify(good));
    delete sinSeccion.datos.payments;
    await assert.rejects(() => parseBackupFile(JSON.stringify(sinSeccion)), (e) => e.code === 'formato');
  });
  test('un archivo inválido no modifica la base local', async () => {
    await poblar();
    const antes = await loadAll();
    await assert.rejects(() => parseBackupFile('{"formato":"x"}'));
    assert.deepEqual(await loadAll(), antes);
  });
  test('combinar: sin duplicar, con resumen y conflictos resueltos por elección explícita', async () => {
    const { p } = await poblar();
    const text = await backupToText();
    const backup = await parseBackupFile(text);
    // 1) combinar con la misma base: todo idéntico, nada se duplica
    let plan = planImport(await loadAll(), backup);
    assert.equal(plan.totalNuevos, 0);
    assert.equal(plan.totalConflictos, 0);
    const antes = await loadAll();
    await restoreMerge(backup, antes);
    assert.deepEqual((await loadAll()).appointments.length, antes.appointments.length);
    // 2) cambia algo localmente → conflicto
    await savePatient({ ...(await getDB().get('patients', p.id)), representante: 'Cambiado localmente' });
    plan = planImport(await loadAll(), backup);
    assert.equal(plan.stores.patients.conflictos.length, 1);
    await restoreMerge(backup, await loadAll(), { enConflicto: 'local' });
    assert.equal((await getDB().get('patients', p.id)).representante, 'Cambiado localmente');
    await restoreMerge(backup, await loadAll(), { enConflicto: 'respaldo' });
    assert.equal((await getDB().get('patients', p.id)).representante, 'Representante Prueba');
    // 3) registros nuevos se agregan una sola vez
    await freshDB();
    plan = planImport(await loadAll(), backup);
    assert.equal(plan.totalNuevos, Object.values(backup.contadores).reduce((a, b) => a + b, 0));
    await restoreMerge(backup, await loadAll());
    await restoreMerge(backup, await loadAll());
    assert.equal((await loadAll()).patients.length, 2);
  });
  test('antes de restaurar se guarda una copia y se puede revertir', async () => {
    await poblar();
    const text = await backupToText();
    await freshDB();
    await mkPatient({ nombre: 'Solo local' });
    const backup = await parseBackupFile(text);
    await restoreReplace(backup);
    assert.equal((await loadAll()).patients.some((x) => x.nombre === 'Solo local'), false);
    await revertLastRestore();
    const after = await loadAll();
    assert.equal(after.patients.length, 1);
    assert.equal(after.patients[0].nombre, 'Solo local');
  });
});

describe('Protección de acceso', () => {
  test('PIN: se guarda con hash, valida, limita intentos y se puede quitar', async () => {
    assert.equal(await hasSecret(), false);
    await assert.rejects(() => setSecret('12'), /al menos 4/);
    await assert.rejects(() => setSecret('1234'), /fácil/);
    await setSecret('mi-clave-7391');
    assert.equal(await hasSecret(), true);
    const meta = await getDB().get('meta', 'auth');
    assert.ok(!JSON.stringify(meta).includes('mi-clave-7391'), 'nunca en texto plano');
    assert.ok(meta.value.hash && meta.value.salt);
    assert.equal((await verifySecret('mi-clave-7391')).ok, true);
    const ahora = 1_000_000;
    for (let i = 1; i <= 4; i++) {
      const r = await verifySecret('mala', ahora);
      assert.equal(r.ok, false);
      assert.equal(r.intentosRestantes, 5 - i);
    }
    const quinto = await verifySecret('mala', ahora);
    assert.ok(quinto.esperaSegundos >= 30, 'espera tras 5 fallos');
    const bloqueado = await verifySecret('mi-clave-7391', ahora + 1000);
    assert.equal(bloqueado.ok, false, 'aun con la clave correcta mientras dura la espera');
    assert.equal((await verifySecret('mi-clave-7391', ahora + 60_000)).ok, true);
    await assert.rejects(() => removeSecret('incorrecta'), /no es correcta/);
    await removeSecret('mi-clave-7391');
    assert.equal(await hasSecret(), false);
  });
});

describe('Datos de demostración', () => {
  test('se cargan con los mismos servicios, son coherentes y se eliminan sin tocar datos reales', async () => {
    const real = await mkPatient({ nombre: 'Real', apellidos: 'Persona' });
    await createAppointment({ patientId: real.id, fecha: '2026-11-16', inicio: '09:00', duracion: 45 });
    await loadDemoData('2026-11-10');
    const data = await loadAll();
    assert.equal(data.patients.filter((p) => p.demo).length, 5);
    assert.deepEqual(checkIntegrity(data), []);
    assert.ok(data.payments.length > 0 && data.packages.length === 1);
    await assert.rejects(() => loadDemoData('2026-11-10'), /Ya hay/);
    await deleteDemoData();
    const after = await loadAll();
    assert.equal(after.patients.length, 1);
    assert.equal(after.appointments.length, 1);
    assert.equal(after.blocks.length, 0);
    assert.equal(after.payments.length, 0);
  });
});

describe('Tablero', () => {
  test('resumen de hoy, próximas, por confirmar, cancelaciones y paquetes', async () => {
    const p = await mkPatient();
    const hoy = '2026-11-10';
    await createAppointment({ patientId: p.id, fecha: hoy, inicio: '09:00', duracion: 45 });
    await createAppointment({ patientId: p.id, fecha: '2026-11-12', inicio: '09:00', duracion: 45 });
    const c = await createAppointment({ patientId: p.id, fecha: '2026-11-05', inicio: '09:00', duracion: 45 });
    await setAppointmentStatus(c.id, 'cancelada_terapeuta', { motivo: 'x' });
    const d = buildDashboard(await loadAll(), hoy);
    assert.equal(d.hoy.length, 1);
    assert.equal(d.proximas.length, 1);
    assert.equal(d.porConfirmar.length, 2);
    assert.equal(d.recientes.length, 1);
    assert.equal(d.porReprogramar.length, 1);
  });
});
